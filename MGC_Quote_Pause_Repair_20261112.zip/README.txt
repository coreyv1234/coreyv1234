MGC SIM17 protected quote-pause repair — SIM101 ONLY

Nov12: four contracts filled and both brackets reported 4/4. The bridge halted
33 minutes later because ONE bid/ask receipt aged over five seconds. That rule
confused entry quote freshness with an existing protected position's health.

An unchanged bid or ask no longer causes that immediate emergency exit.
Existing brackets remain active through brief quote interruptions. New entries
and stop amendments still require the same fresh quotes and original deadlines.
Actual local LAST, BID or ASK receipts establish stream activity. If ALL three
streams are silent for more than 30 seconds, native safety halt/close remains.
Missing full stop/target coverage still triggers the original protection check
after its original three-second fill grace, even during a quote interruption.
Heartbeat, entry acknowledgement, callback, account reserve and 15:55 close rules
remain unchanged. No strategy thresholds, stops, targets or position sizes change.

QUOTE_PAUSED and QUOTE_RECOVERED are notified once per transition, not every poll.
Hourly, entry, exit, win/loss, halt and connection notifications are retained.
No private webhook or launcher is included, replaced or uploaded by this repair.
No balance, ledger, floor, trade count or historical statistics are reset.

INSTALL over SIM16:
Stop Python, disable strategy, verify Sim101 flat/no working orders.
Extract into existing MGC_Bot_With_Setup. Run py .\Repair_MGC_Quote_Pause.py.
Type QUOTES. Reopen changed strategy source and F5 with ZERO compile errors.
Press Enter in repair terminal. Enable SAME SovereignMgcResearchSimBridgeV3 only
after Startup file written. Keep the same chart, bridge directory and Sim101.
Startup should print Native SIM17. Native build is 20261112SIM17.

Validation executes actual extracted production C# helpers in a standalone test
harness. It covers repeated quiet one-sided quotes, LAST-only activity, 5–30s
complete pauses, recovery, genuine total silence, missing protection, and prior
partial-fill exit recovery. This is not a NinjaTrader SDK/runtime certification.
Check actual Orders/Positions on the next Sim101 fill and exit.
