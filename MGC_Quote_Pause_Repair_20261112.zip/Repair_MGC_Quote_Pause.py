"""Install SIM17 quote-pause handling without editing strategy or account state."""
import hashlib
import json
import os
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile


def sha(body):
    return hashlib.sha256(body).hexdigest()


def save_incident(root, bridge=None):
    """Save only public execution diagnostics locally; never send or upload."""
    if bridge is None:
        local = os.environ.get('LOCALAPPDATA')
        if not local:
            return None
        bridge = Path(local) / 'SovereignMGC' / 'ExecutionBridge'
    folders = [p for p in Path(bridge).glob('run_*')
               if p.is_dir() and re.fullmatch(r'run_[a-f0-9]{32}', p.name)]
    folders = sorted(folders, key=lambda p: (p / 'state.txt').stat().st_mtime
                     if (p / 'state.txt').exists() else p.stat().st_mtime, reverse=True)[:3]
    if not folders:
        return None
    target = Path(root) / ('MGC_Quote_Incident_' + datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f') + '.zip')
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
        for folder in folders:
            for name in ('executions.csv', 'state.txt', 'bar_delivery.csv', 'decisions.jsonl', 'controller_health.json'):
                path = folder / name
                if not path.is_file():
                    continue
                with path.open(encoding='utf-8-sig') as stream:
                    header = stream.readline()
                    tail = ''.join(deque(stream, maxlen=6000))
                archive.writestr(folder.name + '/' + name, header + tail)
    return target


def apply(root):
    root = Path(root)
    payload = root / 'quote_pause_repair'
    spec = json.loads((payload / 'PATCH.json').read_text())
    manifest_path = root / 'MANIFEST.json'
    manifest = json.loads(manifest_path.read_text())
    for name, digest in manifest.items():
        relative = Path(name)
        if relative.is_absolute() or '..' in relative.parts:
            raise RuntimeError('Unsafe manifest path')
        if sha((root / name).read_bytes()) != digest:
            raise RuntimeError('Existing public file changed: ' + name + '; no repair applied.')
    for name, item in spec['files'].items():
        relative = Path(name)
        if relative.is_absolute() or '..' in relative.parts:
            raise RuntimeError('Unsafe repair path')
        if sha((payload / 'files' / name).read_bytes()) != item['new_sha256']:
            raise RuntimeError('Repair payload verification failed')
        current = sha((root / name).read_bytes()) if (root / name).exists() else None
        if current not in item['allowed_old_sha256'] + [item['new_sha256']]:
            raise RuntimeError('Unsupported version: ' + name + '; install the SIM16 protection repair first.')
    if all(sha((root / n).read_bytes()) == v['new_sha256'] for n, v in spec['files'].items()):
        print('SIM17 already installed. Native copy and compilation can be retried.')
        return
    backup = Path(tempfile.mkdtemp(prefix='quote_pause_backup_', dir=str(root)))
    shutil.copyfile(manifest_path, backup / 'MANIFEST.json')
    for name in spec['files']:
        saved = backup / name
        saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(root / name, saved)
    try:
        for name, item in spec['files'].items():
            target = root / name
            temporary = target.with_name(target.name + '.repair_tmp')
            temporary.write_bytes((payload / 'files' / name).read_bytes())
            temporary.replace(target)
            manifest[name] = item['new_sha256']
        temporary = manifest_path.with_name('MANIFEST.json.repair_tmp')
        temporary.write_text(json.dumps(manifest, indent=2) + '\n')
        temporary.replace(manifest_path)
    except OSError:
        for name in spec['files']:
            shutil.copyfile(backup / name, root / name)
        shutil.copyfile(backup / 'MANIFEST.json', manifest_path)
        raise
    print('SIM17 quote-pause handling installed. Strategy, risk limits, account ledger and private Discord launcher preserved.')


def main():
    root = Path(__file__).resolve().parent
    if sys.platform != 'win32' or not (root / 'RunSim101.py').is_file():
        raise RuntimeError('Run this repair from the existing Windows MGC_Bot_With_Setup folder.')
    print('Stop Python. Disable the NinjaTrader strategy. Confirm Sim101 is flat with no working orders.')
    print('This repair does not close an active trade, reconcile balances, or reset the ledger.')
    if input('Type QUOTES after completing those checks: ').strip() != 'QUOTES':
        raise RuntimeError('Canceled; no changes applied.')
    try:
        incident = save_incident(root)
        if incident:
            print('Saved execution diagnostics locally (nothing uploaded): ' + str(incident))
    except OSError:
        print('Could not save optional diagnostics; existing run files remain untouched.')
    apply(root)
    subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File',
                    str(root / 'INSTALL_SIM_BRIDGE.ps1')], cwd=root, check=True)
    print('Reopen SovereignMgcResearchSimBridgeV3 in NinjaScript Editor, accept reload, press F5.')
    print('Resolve every compile error. Keep the strategy disabled until Python writes its startup file.')
    input('Press Enter AFTER compilation succeeds: ')
    launcher = root / 'Start_MGC_Private.py'
    if not launcher.is_file():
        raise RuntimeError('Your existing private launcher is missing; it has not been changed.')
    raise SystemExit(subprocess.run([sys.executable, str(launcher)], cwd=root).returncode)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('Stopped. Check NinjaTrader Orders/Positions.')
        raise SystemExit(1)
    except (OSError, RuntimeError, ValueError, subprocess.CalledProcessError) as error:
        print('Quote-pause repair stopped: ' + str(error))
        raise SystemExit(1)
