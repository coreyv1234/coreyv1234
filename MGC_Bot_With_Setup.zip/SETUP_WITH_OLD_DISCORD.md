# Setup from VS Code with your existing Discord webhook

Extract the whole ZIP. Open its folder in VS Code and run `py Setup_MGC.py` in the integrated terminal. Python 3.12 including the Python launcher must already be installed; the script installs the bot dependencies through the existing launcher.

Choose the old bot .py file containing the literal Discord webhook. The helper parses strings only: it does not import/run the old bot, print the URL, store it in a new file, or send it to GitHub. If several different URLs exist, it asks you to choose by source line number without displaying them. Environment-variable references alone do not contain the secret; select the original file that actually stores it. The selected webhook is passed only to the controller child process. The existing controller requires successful Discord startup delivery.

The script verifies package hashes, installs the native bridge with its existing backup behavior, then pauses for you to compile F5 and load the chart. It launches dependencies, Discord and the Python controller; follow its terminal instructions to enable the V3 strategy on Sim101. It does not install NinjaTrader or automate compilation/chart configuration/account selection.

Four helper tests passed using fake webhook strings with no real network delivery. Actual Windows installation remains unverified. The trading controller, strategy, native bridge and model files are unchanged. Sim101 only; current risk limits and mid-session behavior remain as documented in SETUP.md. No webhook or old bot source is included in this published package.
