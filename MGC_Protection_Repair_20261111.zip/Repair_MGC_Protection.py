"""One repair command; trading logic and private launcher are preserved."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def sha(body):return hashlib.sha256(body).hexdigest()


def apply(root):
    root=Path(root);payload=root/'protection_repair'
    spec=json.loads((payload/'PATCH.json').read_text())
    manifest_path=root/'MANIFEST.json'
    manifest=json.loads(manifest_path.read_text())
    for name,digest in manifest.items():
        relative=Path(name)
        if relative.is_absolute() or '..' in relative.parts:raise RuntimeError('Unsafe manifest path')
        if sha((root/name).read_bytes())!=digest:raise RuntimeError('Existing public package file changed: '+name+'; no repair applied.')
    for name,item in spec['files'].items():
        relative=Path(name)
        if relative.is_absolute() or '..' in relative.parts:raise RuntimeError('Unsafe repair path')
        body=(payload/'files'/name).read_bytes()
        if sha(body)!=item['new_sha256']:raise RuntimeError('Repair payload verification failed')
        current=sha((root/name).read_bytes()) if (root/name).exists() else None
        if current not in item['allowed_old_sha256']+[item['new_sha256']]:
            raise RuntimeError('Unsupported existing version: '+name+'; no repair applied.')
    if all((root/n).exists() and sha((root/n).read_bytes())==v['new_sha256'] for n,v in spec['files'].items()):
        print('Protection/acknowledgement repair already applied. Native installation/compilation can be retried.');return
    backup=Path(tempfile.mkdtemp(prefix='protection_backup_',dir=str(root)))
    shutil.copyfile(manifest_path,backup/'MANIFEST.json')
    for name in spec['files']:
        if (root/name).exists():
            saved=backup/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,saved)
    for name,item in spec['files'].items():
        target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
        temporary=target.with_name(target.name+'.repair_tmp')
        temporary.write_bytes((payload/'files'/name).read_bytes());temporary.replace(target)
        manifest[name]=item['new_sha256']
    temporary=manifest_path.with_name('MANIFEST.json.repair_tmp')
    temporary.write_text(json.dumps(manifest,indent=2)+'\n');temporary.replace(manifest_path)
    print('SIM16 acknowledgement and partial-exit repair installed. Strategy and risk settings unchanged. Reviewed manual-exit ledger reconciliation is separate.')


def main():
    root=Path(__file__).resolve().parent
    if not (root/'RunSim101.py').is_file():raise RuntimeError('Run this file from the existing extracted bot folder.')
    if sys.platform!='win32':raise RuntimeError('Run this repair on your Windows NinjaTrader computer.')
    print('Stop the old Python controller with Ctrl+C. Disable the NinjaTrader strategy.')
    print('Confirm Sim101 is flat with no working orders.')
    # Import only the checksum-verified reconciliation helper from this payload.
    import importlib.util
    module_path=root/'protection_repair'/'files'/'gc_research'/'mgc_incident_reconcile_v16.py'
    specification=json.loads((root/'protection_repair'/'PATCH.json').read_text())
    if sha(module_path.read_bytes())!=specification['files']['gc_research/mgc_incident_reconcile_v16.py']['new_sha256']:
        raise RuntimeError('Reconciliation helper verification failed')
    loader=importlib.util.spec_from_file_location('reviewed_incident_reconcile',module_path)
    reconcile=importlib.util.module_from_spec(loader);loader.loader.exec_module(reconcile)
    ledger_path=reconcile.windows_ledger_path();review=reconcile.preview(ledger_path)
    print('Reviewed SIMULATION ledger reconciliation (manual exit after strategy disabled):')
    print(json.dumps({k:v for k,v in review.items() if k not in ('old_body','new_body')},indent=2))
    print('Native positions must be flat. This does not change your broker account balance or reset loss limits.')
    if input('Type PROTECTION after completing those checks: ').strip()!='PROTECTION':raise RuntimeError('Canceled; no changes applied.')
    apply(root)
    receipt=reconcile.apply_reviewed(ledger_path,review)
    print('Simulation ledger reviewed: '+receipt['action'])
    subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(root/'INSTALL_SIM_BRIDGE.ps1')],cwd=root,check=True)
    print('\nIn NinjaTrader: reopen the changed strategy source, accept reload if prompted, and press F5.')
    print('There must be zero compile errors. Keep the strategy disabled until Python writes its startup file.')
    input('Press Enter AFTER F5 compilation succeeds: ')
    private=root/'Start_MGC_Private.py'
    if not private.is_file():raise RuntimeError('Your private launcher is missing. Place Start_MGC_Private.py beside RunSim101.py; do not upload it.')
    print('Starting your existing private launcher. Enable the strategy only after Startup file written.')
    result=subprocess.run([sys.executable,str(private)],cwd=root)
    raise SystemExit(result.returncode)


if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:
        print('Stopped. Confirm actual Orders/Positions in NinjaTrader.');raise SystemExit(1)
    except (OSError,RuntimeError,ValueError,subprocess.CalledProcessError) as error:
        print('Protection repair stopped: '+str(error));raise SystemExit(1)
