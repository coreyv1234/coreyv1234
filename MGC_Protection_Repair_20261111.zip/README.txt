MGC acknowledgement + protective-order recovery repair — native SIM16

Observed Nov11 incident (Chicago): ENTER prepared07:21:00.764, native request01.726,
Submitted06.830, Python-requested halt07.269, first2fills07.908. Brackets for2were
accepted08.732/08.798. Remaining5entryfill11.312 overlapped BridgeFlat market exit;
NinjaTrader logged Set() ignored under internal order handling. Only2closed. Five
remained without brackets until manual Close at12:19:53, fully flat per platform log.

Fixes:
1. Track a SPECIFIC submitted source/run/quantity for up to10seconds awaiting native
   acknowledgement. This matches native entry acknowledgement/fill timeout. It is a
   no-new-order wait, not a flat resync; does not replay sources, extend the5second
   initial-entry deadline, adopt foreign positions, or clear a native halt.
2. Native emergency close tests outstanding orders and pending execution callbacks,
   rather than a permanent flattenRequested latch. A completed2-contract close cannot
   prevent a new5-contract close for late entry fills. Unknown/working exits cannot
   duplicate. Missing close acknowledgement times out explicitly and marks uncertainty.
3. SetStopLoss/SetProfitTarget remain attached BEFORE every entry submission, per
   entry execution. Accepted/working coverage for FULLfilledquantity is checked;
   PROTECTION_CONFIRMED is journalled. Healthy protected trades are not emergency closed.
   True missing protection/risk/callback failures still halt and request a full close.
4. Notification tracker accepts nativeSIM16. Existing hourly/trade/fill alerts remain;
   routine resync Discord notifications remain muted. Strategy and risk/target model
   unchanged. This is Sim101 ONLY, not an evaluation/live-account release.

INSTALL (requires the previous fast-entry/quiet-resync version):
Stop Python, disable strategy, confirm actual Sim101 flat and no working orders.
Extract ZIP into existing MGC_Bot_With_Setup folder; run:
  py .\Repair_MGC_Protection.py
The installer previews an EXACT reviewed simulation ledger recovery from the manual
exit. Recorded7entry and7exit contracts give total net+$2474.40 under assumed$2.80RT
fees; ledger cash becomes$51,089.40. Previous highwater$50,015, sessionopen$48,615,
sessiondate/tradecount/risklimits are preserved; unresolved flag clears only for this
checksum-verified incident. Any different current ledger is REFUSED, never reset.
Type PROTECTION only after reviewing that preview and confirming flat/no orders.

Source is copied into NinjaTrader's existing strategy file. Reopen it, accept reload
and press F5. Resolve ALL compile errors, then press Enter in repair terminal. Existing
private launcher starts. Enable SAME SovereignMgcResearchSimBridgeV3 on Sim101 only
after Startup file written. Existing LocalAppData bridge path and chart setup unchanged.

The simulated manual profit is NOT a strategy-target exit. Its daily profit budget may
block more entries for that CME session; normal session rollover retains the gain and
updates the EOD highwater under existing rules. Old incomplete journal statistics are
not rewritten as a bot win. The financial backup/receipt stays beside the native ledger.

Validation: actual production C# helpers compiled/executed in a standalone harness,
707 assertions,90partial-entry cases in both directions, plus protection/duplicate
checks. Known submitted command delay/recovery and wrong-ID/timeout tests pass.
These are NOT NinjaTrader SDK execution tests. F5 and observed Sim101 partial/full
fills with accepted full-quantity stop/target coverage are still required. No orders,
live Discord messages or brokerage connections were sent from this cloud workspace.
