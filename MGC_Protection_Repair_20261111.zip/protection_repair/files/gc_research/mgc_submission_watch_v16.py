"""Wait for one known submitted order; do not mistake its ack latency for flat loss."""
from .mgc_snapshot_wait_v13 import FlatSnapshotWait
from .mgc_flat_resync_v9 import require_flat_resync
from .mgc_sim_execution_v3 import BridgeError


class SubmissionWatch(FlatSnapshotWait):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.pending=None

    def submitted(self,row,state,now):
        if self.pending is not None:raise BridgeError('An entry is already awaiting native acknowledgement')
        self.pending=dict(run_id=state['run_id'],account=state['account'],instrument=state['instrument'],
            model_id=row['model_id'],command_id=row['command_id'],quantity=row['quantity'],
            sent=self.clock(),issued_utc=now,processed_seen_at=None)

    def inspect(self,state,now,*,read_error=False,pending_commands=False,recent_entry=False,command_processed=False):
        p=self.pending
        if p is None:return super().inspect(state,now,read_error=read_error,pending_commands=pending_commands,recent_entry=recent_entry)
        if any(state[k]!=p[k] for k in ('run_id','account','instrument')):
            raise BridgeError('Native identity changed during submitted entry acknowledgement')
        if state['blocked'] or state['ledger_uncertain']:raise BridgeError('Native halted/uncertain during entry acknowledgement')
        age=(now-state['updated_utc']).total_seconds()
        if age<0:raise BridgeError('Native snapshot future-dated during entry acknowledgement')
        fresh=not read_error and age<=5
        if fresh and state['active_id'] not in ('',p['model_id']):raise BridgeError('Unexpected native source identity during entry acknowledgement')
        if fresh and state['active_id']==p['model_id']:
            if state['submitted_quantity']!=p['quantity']:raise BridgeError('Native submitted quantity differs from entry command')
            self.pending=None
            return dict(action='ENTRY_ACKNOWLEDGED',orders_allowed=False,model_id=p['model_id'])
        if command_processed and p['processed_seen_at'] is None:p['processed_seen_at']=now
        if fresh and p['processed_seen_at'] is not None and state['updated_utc']>p['processed_seen_at']:
            try:require_flat_resync(state,pending_commands=pending_commands)
            except BridgeError:pass
            else:
                self.pending=None
                return dict(action='ENTRY_TERMINAL_FLAT',orders_allowed=False,model_id=p['model_id'])
        elapsed=self.clock()-p['sent']
        if elapsed>=10:raise BridgeError('Submitted entry acknowledgement unavailable for10seconds; native protection/reconciliation required')
        return dict(action='WAIT_ENTRY_ACK',wait_seconds=round(elapsed,3),snapshot_age_seconds=round(age,3),
            orders_allowed=False,notice=elapsed<.5,model_id=p['model_id'])
