"""Exact, reviewed Sim101 manual-exit reconciliation; refuses unrelated ledgers."""
from contextlib import contextmanager
from datetime import datetime,timezone
from decimal import Decimal as D
import base64
import hashlib
import json
import os
from pathlib import Path
import shutil

POLICY='MGC_RED_CONTEXT800_SIM_20261106'
RECONCILED_CASH=D('51089.40')
OLD_CASH=D('48593.97142857143')


def digest(text):return hashlib.sha256(text.encode('utf-8')).hexdigest()


def windows_ledger_path():
    import ctypes
    folder=ctypes.create_unicode_buffer(32768)
    if ctypes.windll.shell32.SHGetFolderPathW(None,5,None,0,folder)!=0:raise RuntimeError('Cannot locate NinjaTrader Documents directory')
    return Path(folder.value)/'NinjaTrader 8'/'SovereignAccountState'/(digest('Sim101')[:32]+'.research_sim800.ledger')


def preview(path):
    lines=Path(path).read_text(encoding='utf-8-sig').splitlines()
    if len(lines)!=2 or digest(lines[0])!=lines[1]:raise RuntimeError('Simulation ledger checksum mismatch; no reconciliation allowed')
    values=lines[0].split(';')
    if len(values)!=12 or values[0]!='2' or values[1]!=POLICY or base64.b64decode(values[2]).decode()!='Sim101':raise RuntimeError('Not the reviewed Sim101 ledger')
    if values[9]!='10' or D(values[10])!=D('2.8'):raise RuntimeError('Simulation contract/fee policy changed; review required')
    if abs(D(values[4])-RECONCILED_CASH)<D('.005') and values[8]=='1':
        return dict(action='ALREADY_RECONCILED',old_body=lines[0],new_body=lines[0],cash=str(RECONCILED_CASH))
    if (values[3]!='2026-11-11' or abs(D(values[4])-OLD_CASH)>D('.005') or D(values[5])!=D('48615')
            or D(values[6])!=D('50015') or values[7]!='1' or values[8]!='0' or values[11]!='0'):
        raise RuntimeError('Ledger differs from the supplied incident; no financial state was reset. Review current ledger separately.')
    new=values.copy();new[4]='51089.4';new[8]='1'
    return dict(action='RECONCILE_REVIEWED_MANUAL_EXIT',account='Sim101',old_body=lines[0],new_body=';'.join(new),
        old_simulated_cash=str(D(values[4])),new_simulated_cash=str(RECONCILED_CASH),
        session_open_preserved=values[5],highwater_preserved=values[6],trade_count_preserved=values[7],
        calculation='Recorded7entry contracts +2native exit contracts +5manual close contracts; $2.80 RT/MGC assumed fees. Total session net+$2474.40.',
        manual_executions=['4fabd405cb784c5792684bb080bdac11','9109238d24a7406298eea93d45e3b0d4'],
        requirement='Actual Sim101 must be flat with no working orders and strategy disabled. This is a simulation ledger, not broker cash.')


@contextmanager
def native_ledger_lock(path):
    # Native holds this same lock file with FileShare.None while enabled.
    # Opening it here fails if the strategy is still active; it also prevents
    # the native strategy acquiring its exclusive lock during this write.
    lock=Path(path).with_name(digest('Sim101')[:32]+'.lock')
    with lock.open('a+b') as stream:
        if os.name=='nt':
            import msvcrt
            stream.seek(0);stream.write(b'\0');stream.flush();stream.seek(0)
            msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
        try:yield
        finally:
            if os.name=='nt':
                import msvcrt
                stream.seek(0);msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)


def apply_reviewed(path,review):
    path=Path(path)
    with native_ledger_lock(path):
        current=preview(path)
        if current['old_body']!=review['old_body']:raise RuntimeError('Ledger changed after preview; no update applied')
        if current['action']=='ALREADY_RECONCILED':return current
        backup=path.with_name(path.name+'.manual_exit_backup_'+datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f'))
        shutil.copyfile(path,backup)
        body=current['new_body'];temporary=path.with_name(path.name+'.reconcile_tmp.'+str(os.getpid()))
        with temporary.open('w',encoding='utf-8',newline='') as stream:
            stream.write(body+'\n'+digest(body)+'\n');stream.flush();os.fsync(stream.fileno())
        os.replace(temporary,path)
        receipt={k:v for k,v in current.items() if k not in ('old_body','new_body')}
        receipt.update(backup=str(backup),new_sha256=digest(body))
        path.with_name(path.name+'.manual_exit_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
        return receipt
