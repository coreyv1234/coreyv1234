$ErrorActionPreference='Stop'
$bridge=Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'NinjaTrader 8\SovereignResearchSimV3'
$id=(Get-Content (Join-Path $bridge 'active_run.txt') -Raw).Trim()
if ($id -notmatch '\A[a-f0-9]{32}\z') { throw 'Invalid run identity.' }
$run=Join-Path $bridge ('run_'+$id)
$output=Join-Path $PSScriptRoot ('Sim101_logs_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.zip')
Compress-Archive -LiteralPath $run -DestinationPath $output
Write-Host "Saved $output"
