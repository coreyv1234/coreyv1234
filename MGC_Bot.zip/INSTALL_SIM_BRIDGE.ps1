$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
$manifest=Get-Content (Join-Path $PSScriptRoot 'MANIFEST.json') -Raw | ConvertFrom-Json
$name='ninjatrader/SovereignMgcResearchSimBridgeV3.cs'
$source=Join-Path $PSScriptRoot 'ninjatrader\SovereignMgcResearchSimBridgeV3.cs'
$expected=$manifest.PSObject.Properties[$name].Value
if ((Get-FileHash $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected) { throw 'Source hash mismatch; extract a fresh ZIP.' }
$nt=Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'NinjaTrader 8'
$strategies=Join-Path $nt 'bin\Custom\Strategies'
if (!(Test-Path $strategies)) { throw "NinjaTrader Strategies folder not found at $strategies. Open NinjaTrader once; check your user-data location." }
$target=Join-Path $strategies 'SovereignMgcResearchSimBridgeV3.cs'
if (Test-Path $target) {
    if ((Get-FileHash $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected) {
        $backups=Join-Path $nt 'SovereignResearchSimV3\source_backups'
        New-Item -ItemType Directory -Force -Path $backups | Out-Null
        Copy-Item $target (Join-Path $backups ('SimBridge_'+[Guid]::NewGuid().ToString('N')+'.cs.bak'))
    }
}
Copy-Item -LiteralPath $source -Destination $target -Force
if ((Get-FileHash $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected) { throw 'Installed source hash mismatch.' }
Write-Host 'Source installed. This does not compile or enable it.'
Write-Host 'NinjaTrader -> New -> NinjaScript Editor -> F5. Resolve every compile error.'
Write-Host 'Then start START_SIM.cmd and follow SETUP.md before enabling SovereignMgcResearchSimBridgeV3 on Sim101.'
