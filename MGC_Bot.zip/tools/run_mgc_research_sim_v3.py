"""Current red-context strategy, real native Sim101 fills, no evaluation access."""
import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import time

import pandas as pd

from gc_research.backtest import RiskConfig
from gc_research.execution_notifications import ExecutionNotifications
from gc_research.market import Bar,CT
from gc_research.mgc_day_precision import day_features
from gc_research.mgc_execution import BridgeError,ID,atomic_text,utc,validate_chart_rows
from gc_research.mgc_live_research_planner_v3 import LiveResearchPlannerV3 as LiveResearchPlanner
from gc_research.mgc_live_signals import latest_source,normalized_minutes
from gc_research.mgc_sim_execution_v3 import ExecutionConfig,parse_state,healthy_state,protective_stop,write_command,command
from tools.run_mgc_range_execution import Heartbeat,read_complete_csv,combine_history,load_brain,verify_release,NativeJournalNotifications,write_startup

BUILD='20261106SIM3'


class SimJournalNotifications(NativeJournalNotifications):
    def poll(self,account):
        if not self.path.exists():return
        rows=read_complete_csv(self.path).fillna('').to_dict('records')
        for row in rows[self.seen:]:
            if row['event'] in self.EVENTS:
                cash=50000.+float(row['cumulative_net'])
                self.notifications.publish(f"Sim101 | {row['event']} | qty {row['quantity']} | price {row['price']} | simulation ledger ${cash:.2f} | test PnL ${cash-48615.:.2f} (assumed fees) | {row['detail']}")
        self.seen=len(rows)


def bridge_directory():
    from tools.run_mgc_range_execution import default_bridge_directory
    return default_bridge_directory().parent/'SovereignResearchSimV3'


def settings(path):
    value=json.loads(Path(path).read_text())
    if value.get('expected_account')!='Sim101' or value.get('account_mode')!='simulation':
        raise BridgeError('This release only supports Sim101')
    cfg=ExecutionConfig('Sim101','simulation',10)
    if (value.get('max_contracts')!=10 or value.get('initial_cash')!=48615
            or value.get('initial_session_cash')!=48615 or value.get('firm_trailing_threshold')!=48015
            or value.get('reconcile_at_startup') is not False):
        raise BridgeError('Use the reviewed600-cushion simulation settings; do not silently reconcile/reset a ledger')
    now=datetime.now(timezone.utc).astimezone(CT)
    from datetime import timedelta
    value['initial_session']=(now.date()+timedelta(days=int(now.hour>=17))).isoformat()
    return value,cfg


def as_bars(frame):
    return [Bar(t.to_pydatetime(),str(r.instrument),float(r.open),float(r.high),float(r.low),float(r.close),float(r.volume)) for t,r in frame.iterrows()]


def check_recent_history(current,session,holidays,overnight=False):
    from datetime import date,timedelta
    day=date.fromisoformat(session);required=[]
    while len(required)<4:
        day-=timedelta(days=1)
        if day.weekday()<5 and day.isoformat() not in holidays:required.append(day.isoformat())
    counts=current.groupby('session_date').size().to_dict()
    missing=[d for d in required if counts.get(d,0)<1000]
    if missing:raise BridgeError('Recent ETH history incomplete (need1000minutes per prior session): '+','.join(missing))
    if overnight:
        cutoff=pd.Timestamp(session+' 02:00:00',tz=CT).tz_convert('UTC')
        night=current.loc[(current.session_date==session)&(current.index<=cutoff)]
        if len(night)<480:raise BridgeError('Current pre02 overnight history incomplete; need480of540minute bars')


def load_native(bridge,cfg):
    run_id=(bridge/'active_run.txt').read_text().strip()
    if not ID.fullmatch(run_id):raise BridgeError('Invalid native run ID')
    folder=bridge/('run_'+run_id)
    state=parse_state((folder/'state.txt').read_text(encoding='utf-8-sig'),cfg)
    if state['run_id']!=run_id:raise BridgeError('Run identity mismatch')
    return folder,state


def status(root,bridge,config):
    _,cfg=settings(config)
    try:folder,state=load_native(bridge,cfg)
    except FileNotFoundError:
        print(json.dumps(dict(connected=False,reason='No current Sim bridge snapshot; start launcher, compile and enable the named bridge.',orders_sent=False)))
        return
    ready=True;reason='Quote/snapshot checks passed'
    try:healthy_state(state,datetime.now(timezone.utc),cfg)
    except BridgeError as e:ready=False;reason=str(e)
    events=read_complete_csv(folder/'executions.csv').fillna('').to_dict('records')
    created=[r for r in events if r['event']=='CREATED']
    build_ok=len(created)==1 and str(created[0]['detail']).startswith('build='+BUILD+'|')
    if not build_ok:ready=False;reason='Wrong native source build'
    print(json.dumps(dict(connected=True,quote_ready=ready,reason=reason,account=state['account'],
        policy=state['policy_id'],simulated_ledger_balance=50000+state['realized_net'],
        firm_floor=state['highwater']-2000,usable_reserved_room=50000+state['realized_net']-(state['highwater']-1950),
        quantity=state['quantity'],stop=state['stop'],target=state['target'],unlimited_simulation_stage=bool(state['goal_reached']),
        native_reason=state['reason'],native_build_verified=build_ok,
        entry_fill_callbacks=sum(r['event']=='ENTRY_FILL' for r in events),
        exit_fill_callbacks=sum(r['event']=='EXIT_FILL' for r in events),
        pending_exit_callbacks=state['pending_exit_callbacks'],ledger_uncertain=bool(state['ledger_uncertain']),
        actual_first_fill_utc=state['first_fill_utc'].isoformat(),account_signed_quantity=state['account_signed_quantity'],orders_sent=False),indent=2))


def run(root,bridge,config,notifications):
    verify_release(root)
    value,cfg=settings(config);write_startup(bridge,value,cfg)
    print('Sim101 only | current red-context model | recovery ledger48615/floor48015 | OnBarClose |02:00-12:00CT entries |15:55flat',flush=True)
    print('Startup file written. Enable SovereignMgcResearchSimBridgeV3 after compilation. Waiting for native REALTIME...',flush=True)
    while True:
        try:
            folder,state=load_native(bridge,cfg)
            if state['phase']=='REALTIME':
                try:
                    healthy_state(state,datetime.now(timezone.utc),cfg)
                    break
                except BridgeError:pass
        except FileNotFoundError:pass
        time.sleep(.5)
    created=[r for r in read_complete_csv(folder/'executions.csv').fillna('').to_dict('records') if r['event']=='CREATED']
    if len(created)!=1 or not str(created[0]['detail']).startswith('build='+BUILD+'|'):
        raise BridgeError('Wrong native source build; use only this release source')
    if any(state[k] for k in ('quantity','entry_working','orders_working','active_id','blocked')):
        raise BridgeError('Attach from a flat, reconciled Sim101 run')
    local=datetime.now(timezone.utc).astimezone(CT)
    if 120<=local.hour*60+local.minute<720:
        raise BridgeError('Start this first simulation before02:00 or after12:00CT so source/OR attempts are not reconstructed from guessed trades')
    lock=folder/'controller.lock'
    with lock.open('x') as f:f.write('Sim101 current-model controller\n')
    heartbeat=None
    try:
        journal=SimJournalNotifications(folder,notifications,'simulation')
        warm=normalized_minutes(pd.read_csv(root/'data/native_minutes.csv'))
        brain=load_brain(root/'sovereign_recovered_math.py')
        models=json.loads((root/'data/tree_day_models.json').read_text())
        forests=json.loads((root/'data/forest_models.json').read_text())
        holidays=json.loads((root/'data/holidays.json').read_text())
        gaps=[tuple(utc(t) for t in g) for g in json.loads((root/'data/zero_trade_gaps.json').read_text())]
        risk=RiskConfig(starting_balance=48615.,risk_per_trade=800,max_contracts=10,max_trades_per_session=20,
            entry_start_ct=120,entry_end_ct=720,flatten_ct=955,daily_loss_limit=900,drawdown_reserve=50,
            max_drawdown=2000,account_trailing_mode='end_of_day',trailing_highwater_cap=52000,
            commission_round_trip=state['fee'],slippage_ticks_per_side=1)
        for attempt in range(3):
            active,fresh=load_native(bridge,cfg)
            if active!=folder:raise BridgeError('Native run changed during initialization')
            state=fresh
            chart=read_complete_csv(folder/'minutes.csv')
            chart=chart.loc[pd.to_datetime(chart.time_utc,utc=True)<=state['last_bar_utc']]
            frame=combine_history(warm,chart)
            symbol=state['instrument'];current=frame.loc[frame.instrument==symbol]
            if len(current)<1200 or len(current.session_date.unique())<5:
                raise BridgeError('Need at least1200actual-expiry minute bars across five sessions; load60chartdays with DoNotMerge')
            check_recent_history(current,state['session'],holidays)
            if frame.index[-1]!=state['last_bar_utc']:raise BridgeError('Native chart and warmup end differ')
            planner=LiveResearchPlanner(risk,{},models=models,features={},trade_models=forests,blocked_dates=holidays,zero_trade_gaps=gaps,goal_lock=False,entry_policy='confirmed')
            planner.seed(as_bars(current.tail(241)))
            active,check=load_native(bridge,cfg)
            if active!=folder:raise BridgeError('Native run changed during seeding')
            if check['last_bar_utc']==state['last_bar_utc']:break
        else:raise BridgeError('Could not establish a stable current closed-bar seed')
        if any(check[k] for k in ('blocked','quantity','entry_working','orders_working','active_id')):
            raise BridgeError('Account became active or halted during initialization')
        heartbeat=Heartbeat(folder,state['run_id'])
        cursor=state['last_bar_utc'];run_id=state['run_id'];cached_day=None
        cursor_file=folder/'controller_cursor.json'
        if cursor_file.exists():raise BridgeError('Never replay a consumed native run; re-enable a new flat run')
        atomic_text(cursor_file,json.dumps(dict(last_bar_utc=cursor.isoformat(),run_id=run_id)))
        print('Connected. Historical candles seeded; no historical orders submitted. Waiting for next closed minute.',flush=True)
        while True:
            heartbeat.progress=time.monotonic()
            active,state=load_native(bridge,cfg)
            if active!=folder:raise BridgeError('Native run changed')
            journal.poll('Sim101')
            if state['blocked']:raise BridgeError('Native halt: '+state['reason'])
            now=datetime.now(timezone.utc)
            if (now-state['updated_utc']).total_seconds()>5:raise BridgeError('Native snapshot stopped')
            stamp=state['last_bar_utc']
            if stamp<cursor:raise BridgeError('Native clock moved backwards')
            if stamp>cursor:
                chart=read_complete_csv(folder/'minutes.csv')
                chart=chart.loc[pd.to_datetime(chart.time_utc,utc=True)<=stamp]
                rows=chart.to_dict('records');validate_chart_rows(rows,symbol)
                frame=combine_history(warm,chart);current=frame.loc[frame.instrument==symbol]
                if frame.index[-1]!=stamp:raise BridgeError('Closed-chart state mismatch')
                bar=as_bars(current.tail(1))[0]
                if stamp-cursor!=pd.Timedelta(minutes=1):raise BridgeError('Missed live minute; no historical catch-up entry')
                atomic_text(cursor_file,json.dumps(dict(last_bar_utc=stamp.isoformat(),run_id=run_id)));cursor=stamp
                if cached_day!=state['session']:
                    planner.daily_features=day_features(current)
                    if state['session'] in planner.daily_features and utc(planner.daily_features[state['session']]['available_at'])<=stamp:
                        check_recent_history(current,state['session'],holidays,overnight=True)
                        cached_day=state['session']
                sources=latest_source(brain,frame,stamp,symbol) if stamp.minute%5==0 else []
                # Source generation may be expensive; actual account/quote state
                # is refreshed before shared model observation or any command.
                _,state=load_native(bridge,cfg);now=datetime.now(timezone.utc)
                if state['last_bar_utc']!=stamp:raise BridgeError('Processing fell behind the native closed-bar clock')
                planner.observe(bar,state,sources)
                row=None
                try:
                    healthy_state(state,now,cfg)
                    row=protective_stop(state,bar,now,cfg) if state['quantity'] else planner.prepare_entry(state,now,cfg)
                except BridgeError as e:
                    print('No command: '+str(e),flush=True)
                if row is not None:
                    if (datetime.now(timezone.utc)-now).total_seconds()>1:raise BridgeError('Command preparation expired')
                    write_command(folder,row)
                decision=dict(event='CLOSED_MINUTE',time=stamp.isoformat(),sources=len(sources),
                    decision=row['kind'] if row else 'NO_COMMAND',account='Sim101',ledger_cash=50000+state['realized_net'],
                    proposal_waiting=planner.limit_order is not None,
                    family=planner.native_signal.family if row and row['kind']=='ENTER' else None,
                    day_gate=planner.day_decisions.get(state['session']),rejections=dict(planner.rejections),
                    native_model_id=state['active_id'],actual_first_fill_utc=state['first_fill_utc'].isoformat(),
                    native_quantity=state['quantity'],account_signed_quantity=state['account_signed_quantity'],
                    entry_executed=state['entry_executed'],exit_executed=state['exit_executed'],
                    pending_exit_callbacks=state['pending_exit_callbacks'])
                with (folder/'decisions.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(decision)+'\n')
                print(json.dumps(decision),flush=True)
            time.sleep(.25)
    except BaseException:
        try:
            _,latest=load_native(bridge,cfg)
            if latest['run_id']==state['run_id']:
                ident=latest['active_id'] if ID.fullmatch(latest['active_id']) else '0'*32
                write_command(folder,command(latest,'FLATTEN',ident,datetime.now(timezone.utc)))
        except Exception:pass
        raise
    finally:
        if heartbeat is not None:heartbeat.close()
        lock.unlink(missing_ok=True)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    p.add_argument('--bridge',type=Path,default=bridge_directory())
    mode=p.add_mutually_exclusive_group();mode.add_argument('--status',action='store_true');mode.add_argument('--audit',action='store_true')
    p.add_argument('--discord',action='store_true');a=p.parse_args()
    cfg=a.root/'sim_config.json'
    notifier=ExecutionNotifications.from_environment(a.discord and not (a.status or a.audit))
    try:
        if a.audit:
            from tools.audit_mgc_sim_run_v3 import audit,read_journal
            verify_release(a.root);settings(cfg)
            run_id=(a.bridge/'active_run.txt').read_text().strip()
            if not ID.fullmatch(run_id):raise BridgeError('Invalid native run identity')
            folder=a.bridge/('run_'+run_id)
            report=audit(read_journal(folder/'executions.csv'))
            (folder/'execution_audit.json').write_text(json.dumps(report,indent=2)+'\n')
            print(json.dumps(report,indent=2))
        elif a.status:status(a.root,a.bridge,cfg)
        else:run(a.root,a.bridge,cfg,notifier)
    except KeyboardInterrupt:
        print('Controller stopped. Check NinjaTrader Orders/Positions for native flatten completion.',flush=True)
    except (BridgeError,OSError,ValueError) as e:
        print('Controller stopped: '+str(e),flush=True);raise SystemExit(1)
    finally:notifier.close()


if __name__=='__main__':main()
