"""Audit booked native fills after a Sim101 run; acknowledgements are not fills."""
import argparse
import csv
from decimal import Decimal as D
import json
from pathlib import Path


def read_journal(path):
    raw=Path(path).read_text(encoding='utf-8-sig')
    if not raw.endswith('\n'):
        raise ValueError('Journal has an incomplete final record; stop and collect a complete journal')
    # Keep price/cash strings intact. A dataframe float conversion would lose
    # decimal precision before the independent accounting calculation begins.
    return list(csv.DictReader(raw.splitlines()))


def detail(value):
    return dict(p.split('=',1) for p in value.split('|') if '=' in p)


def audit(records):
    created=[r for r in records if r['event']=='CREATED']
    if len(created)!=1 or not created[0]['detail'].startswith('build=20261106SIM3|'):
        raise ValueError('Expected exactly one SIM3 CREATED record')
    fee=D(created[0]['price']);initial=50000+D(created[0]['cumulative_net'])
    cash=initial;quantity=0;average=D(0);active=None;plans={};executions=set();fees=D(0)
    fills=closed=0;incidents=[];halts=[];rejections=[];acknowledged={};booked={}
    entry_ticks=D(0);entry_contracts=0;worst_entry_ticks=D(0)
    for row in records:
        event=row['event'];meta=detail(row['detail']);model=row['model_id'];q=int(row['quantity']);price=D(row['price'])
        if event=='ENTRY_REQUEST':
            if model in plans or quantity:raise ValueError('Duplicate/overlapping source request')
            direction=int(meta['direction'])
            if direction not in (-1,1) or not 1<=q<=10:raise ValueError('Invalid source direction/size')
            plans[model]=dict(direction=direction,submitted=q,entered=0,exited=0,estimate=price)
        elif event in ('ENTRY_FILL','EXIT_FILL'):
            if model not in plans:raise ValueError('Fill without a recorded source request')
            key=(meta.get('order'),meta.get('exec'))
            if not all(key) or key in executions:raise ValueError('Missing/duplicate actual execution identity')
            executions.add(key);plan=plans[model];d=int(meta['direction'])
            booked[meta['order']]=booked.get(meta['order'],0)+q
            if d!=plan['direction'] or q<=0:raise ValueError('Execution side/quantity mismatch')
            if event=='ENTRY_FILL':
                if quantity and active!=model:raise ValueError('Source overlapped another position')
                if plan['exited']:incidents.append(dict(event='ENTRY_AFTER_EXIT',model_id=model,execution=meta['exec']))
                plan['entered']+=q
                if plan['entered']>plan['submitted']:raise ValueError('Executed more contracts than submitted')
                ticks=d*(price-plan['estimate'])*10
                entry_ticks+=ticks*q;entry_contracts+=q;worst_entry_ticks=max(worst_entry_ticks,ticks)
                average=(average*quantity+price*q)/(quantity+q)
                quantity+=q;active=model;cash-=fee*q/2
            else:
                if active!=model or q>quantity:raise ValueError('Exit exceeds/mismatches booked position')
                cash+=(d*(price-average)*10-fee/2)*q
                quantity-=q;plan['exited']+=q
                if quantity==0:average=D(0);active=None
            fees+=fee*q/2;fills+=1
        elif event=='TRADE_CLOSED':
            if quantity:raise ValueError('Trade marked closed before actual exit callbacks')
            closed+=1
        elif event=='HALTED':halts.append(row['detail'])
        elif event=='COMMAND_REJECTED':rejections.append(row['detail'])
        elif event=='ORDER' and meta.get('order'):
            acknowledged[meta['order']]=max(acknowledged.get(meta['order'],0),int(meta.get('filled',0)))
        observed=50000+D(row['cumulative_net'])
        if abs(observed-cash)>D('.00001'):
            raise ValueError('Native ledger cash does not reconcile with actual fills: '+event)
    pending=sum(max(0,count-booked.get(order,0)) for order,count in acknowledged.items())
    return dict(accounting_passed=True,starting_ledger_cash=float(initial),ending_ledger_cash=float(cash),
        realized_cash_change=float(cash-initial),fees=float(fees),actual_execution_callbacks=fills,
        flat_at_end=quantity==0 and pending==0,booked_open_quantity=quantity,
        pending_acknowledged_execution_quantity=pending,closed_trade_records=closed,
        entry_ticks_vs_native_estimate_weighted_mean=float(entry_ticks/entry_contracts) if entry_contracts else None,
        worst_adverse_entry_ticks_vs_native_estimate=float(worst_entry_ticks),
        callback_incidents=incidents,native_halts=halts,native_rejections=rejections,
        native_oco_runtime_verified=False,
        limits='Audits the native journal arithmetic and identities; not broker statements, open-position PnL, queue fills, OCO completeness or future profitability. ORDER acknowledgements never book a fill.')


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',type=Path,required=True);a=p.parse_args()
    report=audit(read_journal(a.run/'executions.csv'))
    (a.run/'execution_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
