"""Run the unchanged fixed400 range-target model against its exact-account bridge."""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import threading
import time
from datetime import datetime, timezone
import math

import pandas as pd

from gc_research.execution_notifications import ExecutionNotifications
from gc_research.market import Bar
from gc_research.mgc_day_precision import day_features
from gc_research.mgc_execution import BridgeError, ID, atomic_text, utc
from gc_research.mgc_range_execution import (ExecutionConfig, command, healthy_state,
    parse_state as parse_native_state, plan_entry, protective_stop, write_command)
from gc_research.mgc_live_signals import normalized_minutes, latest_source

STARTUP_FIELDS=('version','account','mode','max_contracts','cash','session_cash','highwater','session','reconcile')
NATIVE_BUILD='20261029R1'


def parse_state(text,cfg):
    state=parse_native_state(text,cfg)
    if state['quantity'] and (state['average_entry']<=0 or state['stop']<=0 or state['target']<=0 or
                             state['initial_risk']<=0 or not ID.fullmatch(state['active_id'])):
        raise BridgeError('Native filled-position state is incomplete; no protective request can be prepared')
    return state


def verify_native_build(folder):
    rows=read_complete_csv(Path(folder)/'executions.csv').fillna('').to_dict('records')
    created=[r for r in rows if r['event']=='CREATED']
    if len(created)!=1 or not str(created[0]['detail']).startswith('build='+NATIVE_BUILD+'|'):
        raise BridgeError('Native bridge is outdated; compile the final SovereignMgcRangeExecutionBridge source from this package')


def load_settings(path):
    settings=json.loads(Path(path).read_text())
    required={'expected_account','account_mode','max_contracts','initial_cash','initial_session_cash',
              'firm_trailing_threshold','initial_session','reconcile_at_startup'}
    if set(settings)!=required:raise BridgeError('Account configuration has missing or unsupported settings')
    if not isinstance(settings['expected_account'],str):raise BridgeError('Expected one exact account name as text')
    cfg=ExecutionConfig(settings['expected_account'],settings['account_mode'],settings['max_contracts'])
    for k in ('initial_cash','initial_session_cash','firm_trailing_threshold'):
        v=settings[k]
        if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<=0:
            raise BridgeError('Invalid account capital: '+k)
    if not 48000<=settings['firm_trailing_threshold']<=50000:
        raise BridgeError('Expected the stated50000 Select Daily EOD drawdown floor48000..50000')
    if settings['initial_cash']<=settings['firm_trailing_threshold']:
        raise BridgeError('Configured balance is at/below the firm trailing floor')
    if settings['reconcile_at_startup'] is not False:
        raise BridgeError('Keep reconcile_at_startup false. Use explicit --reconcile-account with updated dashboard values when reconciliation is required.')
    datetime.strptime(settings['initial_session'],'%Y-%m-%d')
    return settings,cfg


def write_startup(bridge,settings,cfg):
    bridge=Path(bridge);bridge.mkdir(parents=True,exist_ok=True)
    values=['2',cfg.expected_account,cfg.account_mode,str(cfg.max_contracts),str(settings['initial_cash']),
            str(settings['initial_session_cash']),str(settings['firm_trailing_threshold']+2000),
            settings['initial_session'],'1' if settings['reconcile_at_startup'] else '0']
    if any(any(c in v for c in ';\r\n') for v in values):raise BridgeError('Invalid startup account field')
    atomic_text(bridge/'startup_account.txt',';'.join(STARTUP_FIELDS)+'\n'+';'.join(values)+'\n')


def default_bridge_directory():
    if os.name == 'nt':
        import ctypes
        buffer = ctypes.create_unicode_buffer(32768)
        if ctypes.windll.shell32.SHGetFolderPathW(None,5,None,0,buffer) == 0:
            return Path(buffer.value)/'NinjaTrader 8'/'SovereignRangeExecution'
    return Path.home()/'Documents'/'NinjaTrader 8'/'SovereignRangeExecution'


class Heartbeat:
    """Independent IO with a deadline on progress of the main controller loop."""
    def __init__(self, folder, run_id):
        self.folder, self.run_id = folder, run_id
        self.progress = time.monotonic()
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self.work, daemon=True, name="mgc-heartbeat")
        self.thread.start()

    def work(self):
        while not self.stop.is_set():
            if time.monotonic()-self.progress < 10:
                try:
                    atomic_text(self.folder/"heartbeat.txt", self.run_id+";"+datetime.now(timezone.utc).isoformat()+"\n")
                except OSError:
                    pass  # Native deadline, not this thread, owns loss-of-controller protection.
            self.stop.wait(1)

    def close(self):
        self.stop.set()
        self.thread.join(timeout=2)
        # Remove the heartbeat so native timeout begins from its last received timestamp.
        try:
            (self.folder/"heartbeat.txt").unlink(missing_ok=True)
        except OSError:
            pass


def read_complete_csv(path):
    text = Path(path).read_text(encoding="utf-8-sig")
    # NT appends; an incomplete final write is not a closed observation.
    text = text[:text.rfind("\n")+1]
    return pd.read_csv(io.StringIO(text))


def combine_history(warm, chart):
    """The actual-expiry chart owns new OHLCV; overlapping revisions fail closed."""
    chart = normalized_minutes(chart)
    if len(chart) == 0:
        raise BridgeError("Chart history is empty")
    overlap = warm.index.intersection(chart.index)
    # Back-month chart history may legitimately overlap older front-contract
    # warmup timestamps. Compare revisions only within the SAME actual expiry;
    # the current chart owns cross-expiry overlap for its own instrument.
    if len(overlap):
        same_symbol=(warm.loc[overlap,'instrument'].astype(str).to_numpy()==chart.loc[overlap,'instrument'].astype(str).to_numpy())
        overlap=overlap[same_symbol]
    if len(overlap):
        for field in ("instrument", "open", "high", "low", "close", "volume"):
            if field == "instrument":
                same = (warm.loc[overlap,field].astype(str).to_numpy()==chart.loc[overlap,field].astype(str).to_numpy()).all()
            else:
                same = (abs(warm.loc[overlap,field].to_numpy(float)-chart.loc[overlap,field].to_numpy(float)) < 1e-7).all()
            if not same:
                raise BridgeError("Chart history conflicts with saved warmup; use DoNotMerge and reconcile the history")
    # Keep reviewed historical classification; quote flow is unknown on new chart bars.
    replace_times=chart.index.difference(overlap)
    return pd.concat([warm.loc[~warm.index.isin(replace_times)],chart.loc[~chart.index.isin(overlap)]]).sort_index()


def load_brain(path):
    spec = importlib.util.spec_from_file_location("sovereign_recovered_math", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def verify_release(root):
    manifest = json.loads((root/"MANIFEST.json").read_text())
    for name, expected in manifest.items():
        relative = Path(name)
        if relative.is_absolute() or ".." in relative.parts:
            raise BridgeError("Unsafe release path")
        if hashlib.sha256((root/relative).read_bytes()).hexdigest() != expected:
            raise BridgeError("Execution release changed: "+name)


class NativeJournalNotifications:
    EVENTS = {"ENTRY_FILL", "EXIT_FILL", "HALTED", "TRADE_CLOSED", "REALTIME", "FLATTEN_REQUEST", "COMMAND_REJECTED", "GOAL_REACHED"}

    def __init__(self, folder, notifications, mode):
        self.mode = mode
        self.path = folder/"executions.csv"
        self.notifications = notifications
        # Controller restart must not announce old fills again.
        self.seen = len(read_complete_csv(self.path)) if self.path.exists() else 0

    def poll(self, account):
        if not self.path.exists():
            return
        rows = read_complete_csv(self.path).fillna("").to_dict("records")
        for row in rows[self.seen:]:
            if row["event"] in self.EVENTS:
                self.notifications.publish(f"MGC {self.mode.upper()} | {account} | {row['event']} | qty {row['quantity']} | price {row['price']} | cumulative net ${row['cumulative_net']:.2f} (assumed fees) | {row['detail']}")
        self.seen = len(rows)


def run(root, bridge, notifications, config_path, reconcile_account=False):
    verify_release(root)
    settings, cfg = load_settings(config_path)
    settings['reconcile_at_startup']=bool(reconcile_account)
    write_startup(bridge, settings, cfg)
    print("Fixed400 independent range targets | "+cfg.account_mode+" | exact account "+cfg.expected_account, flush=True)
    warm = normalized_minutes(pd.read_csv(root/"data/native_minutes.csv"))
    days = json.loads((root/"data/tree_day_models.json").read_text())
    forests = json.loads((root/"data/forest_models.json").read_text())
    holidays = json.loads((root/"data/holidays.json").read_text())
    brain = load_brain(root/"sovereign_recovered_math.py")
    zero_gaps = [tuple(utc(t) for t in g) for g in json.loads((root/"data/zero_trade_gaps.json").read_text())]
    print("Waiting for SovereignMgcRangeExecutionBridge on "+cfg.expected_account+". Startup configuration written to "+str(bridge), flush=True)
    folder = None
    while folder is None:
        try:
            run_id = (bridge/"active_run.txt").read_text().strip()
            if not ID.fullmatch(run_id):
                raise BridgeError("Invalid active run identity")
            candidate = bridge/("run_"+run_id)
            state = parse_state((candidate/"state.txt").read_text(encoding="utf-8-sig"),cfg)
            age = (datetime.now(timezone.utc)-state["updated_utc"]).total_seconds()
            if state["run_id"] == run_id and state["phase"] == "REALTIME" and 0 <= age < 3:
                folder = candidate
            else:
                time.sleep(.5)
        except FileNotFoundError:
            time.sleep(.5)
    lock = folder/"controller.lock"
    verify_native_build(folder)
    # A stale lock intentionally requires reconciliation/new native run; never auto-adopt unknown exposure.
    descriptor = os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    os.write(descriptor,str(os.getpid()).encode()); os.close(descriptor)
    heartbeat = None
    try:
        if state["blocked"] or state["quantity"] or state["entry_working"] or state["orders_working"] or state["active_id"]:
            raise BridgeError("Start controller from a reconciled flat run; resolve orders before restarting")
        heartbeat = Heartbeat(folder, run_id)
        journal = NativeJournalNotifications(folder, notifications, cfg.account_mode)
        cursor_file = folder/"controller_cursor.json"
        if cursor_file.exists():
            raise BridgeError("This native run already had a controller; resolve flat and enable a fresh strategy run")
        # Never issue a historical entry on startup or on reattachment.
        cursor = state["last_bar_utc"]
        atomic_text(cursor_file,json.dumps({"last_bar_utc":cursor.isoformat(),"run_id":run_id}))
        notifications.publish("MGC "+cfg.account_mode+" connected | "+cfg.expected_account+" |400total planned cap, max "+str(cfg.max_contracts)+"MGC. Native ledger and protective orders; fees assumed.")
        print("Connected to "+str(folder)+". Waiting for the next closed minute.",flush=True)
        print("Ledger cash: "+str(50000+state['realized_net'])+" | firm trailing floor: "+str(state['highwater']-2000)+
              " | source strategy risk cap400; native account/day limits bind.",flush=True)
        cached_day = None; features = {}
        last_message = ""; notification_failures = 0
        while True:
            heartbeat.progress = time.monotonic()
            if (bridge/"active_run.txt").read_text().strip() != run_id:
                raise BridgeError("Native run changed; old controller will not attach to the new run")
            state = parse_state((folder/"state.txt").read_text(encoding="utf-8-sig"),cfg)
            now = datetime.now(timezone.utc)
            if state["run_id"] != run_id:
                raise BridgeError("Snapshot run identity changed")
            journal.poll(state["account"])
            if state["goal_reached"]:
                print("Ledger reached53000; entries stopped. Verify actual account/provider evaluation status.",flush=True)
                return
            if notifications.failed != notification_failures:
                notification_failures = notifications.failed
                print(f"Discord delivery failures: {notification_failures}. Native order protection continues.",flush=True)
            if state["blocked"]:
                raise BridgeError("Native bridge halted: "+state["reason"])
            if (now-state["updated_utc"]).total_seconds() > 5:
                raise BridgeError("Native bridge snapshot stopped updating")
            try:
                healthy_state(state,now,cfg)
                last_message = ""
            except BridgeError as exc:
                message = str(exc)
                if message != last_message:
                    print("Waiting: "+message,flush=True); last_message = message
                time.sleep(.25)
                continue
            stamp = state["last_bar_utc"]
            if stamp < cursor:
                raise BridgeError("Native closed-bar clock moved backwards")
            if stamp > cursor:
                chart = read_complete_csv(folder/"minutes.csv")
                # Validate the chart stream through the same strict OHLCV parser used by old-data replay.
                # A stable snapshot can precede the next append; future rows are not used for this decision.
                chart = chart.loc[pd.to_datetime(chart.time_utc,utc=True)<=stamp]
                if chart.empty or utc(chart.time_utc.iloc[-1]) != stamp:
                    raise BridgeError("Chart export and native closed-bar snapshot disagree")
                # Validate geometry and off-tick values without writing another growing file.
                rows = chart.to_dict("records")
                from gc_research.mgc_execution import validate_chart_rows
                validate_chart_rows(rows,state["instrument"])
                frame = combine_history(warm,chart)
                if frame.index[-1] != stamp:
                    raise BridgeError("Warmup contains future bars relative to the native stream")
                b = rows[-1]
                bar = Bar(stamp,b["instrument"],float(b["open"]),float(b["high"]),float(b["low"]),float(b["close"]),float(b["volume"]))
                # Consume BEFORE emitting the command, so a crash cannot replay an ambiguous decision.
                atomic_text(cursor_file,json.dumps({"last_bar_utc":stamp.isoformat(),"run_id":run_id}))
                cursor = stamp
                # CSV/history processing can take time. Refresh actual fills and
                # quotes before preparing a protective request, just as for an
                # entry. A newer native bar is processed on the next loop.
                state=parse_state((folder/"state.txt").read_text(encoding="utf-8-sig"),cfg)
                now=datetime.now(timezone.utc)
                if state['last_bar_utc']!=stamp:
                    continue
                row = protective_stop(state,bar,now,cfg) if state["quantity"] else None
                if not state["quantity"] and stamp.minute%5 == 0:
                    source = latest_source(brain,frame,stamp,state["instrument"])
                    if cached_day != state["session"]:
                        features = day_features(frame.loc[frame.instrument==state['instrument']])
                        feature = features.get(state["session"])
                        cached_day = state["session"] if feature and utc(feature["available_at"]) <= stamp else None
                    # Quote and fill state may have changed during indicator computation.
                    state = parse_state((folder/"state.txt").read_text(encoding="utf-8-sig"),cfg)
                    now = datetime.now(timezone.utc)
                    context = [Bar(t.to_pydatetime(),str(v.instrument),float(v.open),float(v.high),float(v.low),float(v.close),float(v.volume))
                               for t,v in frame.loc[frame.instrument==state["instrument"]].tail(241).iterrows()]
                    row = plan_entry(state,stamp,source,features,days,forests,holidays,now,
                                     bars=context,config=cfg,zero_gaps=zero_gaps)
                    print(json.dumps(dict(event='CLOSED_BAR_EVALUATED',time=stamp.isoformat(),source_candidates=len(source),
                        day_context_ready=state['session'] in features,decision='ENTER' if row is not None else 'NO_ENTRY',
                        ledger_cash=50000+state['realized_net'])),flush=True)
                if row is not None:
                    healthy_state(state,datetime.now(timezone.utc),cfg)
                    if (datetime.now(timezone.utc)-now).total_seconds() > 1:
                        raise BridgeError("Command preparation missed its freshness deadline")
                    write_command(folder,row)
                    print(json.dumps({"event":"COMMAND_WRITTEN","kind":row["kind"],"model_id":row["model_id"],
                        "quantity":row["quantity"],"stop":row["stop"],"target":row["target"]}),flush=True)
                heartbeat.progress = time.monotonic()
            time.sleep(.25)
    except BaseException:
        # Best-effort native flatten, never a fabricated exit fill. Independent native heartbeat timeout is the fallback.
        try:
            state = parse_state((folder/"state.txt").read_text(encoding="utf-8-sig"),cfg)
            if state["run_id"] == run_id:
                model_id = state["active_id"] if ID.fullmatch(state["active_id"]) else "0"*32
                write_command(folder,command(state,"FLATTEN",model_id,datetime.now(timezone.utc)))
        except Exception:
            pass
        notifications.publish("MGC controller stopped. Native flatten requested; check NinjaTrader Orders and Positions for actual completion.")
        raise
    finally:
        if heartbeat is not None:
            heartbeat.close()
        lock.unlink(missing_ok=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root",type=Path,default=Path(__file__).resolve().parents[1],help="Verified extracted execution release")
    p.add_argument("--bridge",type=Path,default=default_bridge_directory())
    p.add_argument("--discord",action="store_true",help="Enable notifications using DISCORD_WEBHOOK_URL; no webhook value on command line")
    p.add_argument("--config",type=Path,default=None,help="Account settings JSON; defaults to execution_config.json in release")
    p.add_argument("--reconcile-account",action="store_true",help="One-time ledger reconciliation using updated dashboard values; account must be flat")
    a = p.parse_args()
    notifier = ExecutionNotifications.from_environment(a.discord)
    try:
        run(a.root,a.bridge,notifier,a.config or a.root/"execution_config.json",a.reconcile_account)
    except KeyboardInterrupt:
        print("Controller stopped. Check native Orders/Positions for flatten completion.",flush=True)
    except (BridgeError,OSError,ValueError) as exc:
        print("Controller stopped: "+str(exc),file=sys.stderr)
        raise SystemExit(1)
    finally:
        notifier.close()


if __name__ == "__main__":
    main()
