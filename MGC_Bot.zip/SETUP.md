# MGC Sim101 — mid-session startup and Discord

The Python controller is revision SIM4. It uses the SAME SovereignMgcResearchSimBridgeV3 native source, build 20261106SIM3 and version-3 wire protocol. Strategy math, risk limits and the published SIM3 ZIP are unchanged. Start the new Python controller only; never run the older controller concurrently.

## Visual Studio Code

Extract the WHOLE ZIP into a new folder and open that folder in VS Code. Use the integrated terminal (not the Debug Console) with 64-bit Python 3.12:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe RunSim101.py
```

Discord is ON and required by default for trading. If DISCORD_WEBHOOK_URL is not set locally, the Python launcher prompts for it with hidden input in the terminal. Do not put a webhook in source, sim_config.json or chat. It is not saved by this package. A successful HTTP delivery must print `Discord enabled: startup delivery confirmed.` BEFORE the controller arms. Missing, invalid or undeliverable configuration stops startup. This startup check is a real Discord message when YOU run it locally; all cloud notification tests used mocks and no message was sent here.

Alternatively double-click START_SIM_WITH_DISCORD.cmd (or START_SIM.cmd). PowerShell prompts for a hidden webhook, creates the local Python environment and starts the same required-notification controller. CHECK_STATUS.cmd and AUDIT_RUN.cmd send no notifications and need no webhook.

## NinjaTrader and starting mid-session

1. Disable other Sim101 bots and close the older Python controller. Confirm Sim101 is flat with no working orders. Existing manual positions or uncertain ledger state cannot be adopted.
2. If the V3 native source has not been installed, run INSTALL_SIM_BRIDGE.cmd and press F5 in NinjaScript Editor. If the identical V3 source is already installed and compiled, the Python change needs no native source replacement. NinjaTrader API compilation remains unverified in cloud.
3. Connect the futures feed. Open the actual active MGC expiry (MGC 12-26 for this release), 1 Minute ETH chart, DoNotMerge, 60 days of history. The same recent-history and overnight-coverage checks apply. This package cannot supply missing chart history.
4. Start RunSim101.py or START_SIM_WITH_DISCORD.cmd, complete the Discord startup check, then enable SovereignMgcResearchSimBridgeV3 on Sim101 with Calculate=On bar close, maximum contracts=10, CloseAtNoon=false and the evaluation switch=false. Enable Read launcher startup configuration.
5. Startup is allowed during the 02:00–12:00 Chicago entry window. It seeds indicators from already-closed candles, loads the native persisted cash/daily/trailing state and records a cutoff in startup_context.json. It waits for a NEW closed minute after that cutoff. It never submits earlier signals, infers earlier fills or resets session risk.
6. If the local cutoff is later than 02:15 on the current session date, the early opening-range family is skipped for that session. This avoids reusing an unknown earlier attempt. Other fresh eligible families remain available. An evening start does not consume the next morning's opening-range opportunity. A start by 02:15 can use the fully loaded range as it completes normally.
7. Starting after noon is allowed for preparation, but it does not extend entry hours: no new entries after noon. Existing stops/targets can work until the 15:55 safety close. The strategy does not resume an interrupted active run; a restart needs a fresh native run from a reconciled flat state, preserving its ledger.

The first successful connection prints JOINED_SESSION and `Connected. Historical candles seeded; no historical orders submitted.` Discord then queues a connection/armed message. Check actual Orders/Positions for execution and accepted protection; a Python signal or Discord alert is not a fill.

## Discord events and health

Entry fills, exit fills, trade closes, native halts, flatten requests, rejected commands, realtime startup and goal events are forwarded from the native execution journal. They include the SIMULATION ledger and assumed fees. The $48,615 start / $48,015 initial floor are simulation settings, not a live account reconciliation.

The controller writes notification_status.json with enabled, startup_delivery_confirmed, sent, failed, dropped and pending counts. CHECK_STATUS.cmd includes this information for the current run. Later delivery failures or queue drops print a visible warning; native stop/target protection continues. Startup confirms one delivery, not uninterrupted Discord availability. A Discord outage cannot guarantee that every notification arrives.

## Validation and limitations

803 Python tests pass, including 11 new mid-session/Discord tests with mocked delivery. The same 183 full-model and 40 recovery entry commands match unchanged order preparation. This parity does not predict PnL from joining late. Earlier missed opportunities and skipped opening-range entries mean a late-start day's results can differ from the full-session backtest.

This package is Sim101-only. Native API compilation, actual Windows callbacks, bracket/OCO coverage and reconnect/flatten remain unverified. Tick validation of the reported June–October profits is still pending missing raw MGC files. No new profitability result is claimed. PowerShell launchers have not been executed on Windows here.

The model retains its global $800 risk ceiling, 10-contract maximum, source caps and existing account/daily limits. With the requested $600 initial firm cushion, the reserve leaves $550 initial usable room. Existing ledger files win over startup defaults; relaunching does not erase PnL. Actual Sim101 platform cash may need manual alignment if you want its UI to match the virtual ledger.

## Audit and logs

Once flat and stopped, run AUDIT_RUN.cmd and COLLECT_LOGS.cmd. Logs remain under the actual NinjaTrader user-data Documents folder, SovereignResearchSimV3/run_<id>. They now include startup_context.json and notification_status.json; no webhook is written there. If Documents is redirected, supply START_SIM.ps1 -Bridge '<actual user-data folder>\SovereignResearchSimV3'.
