from tools.run_mgc_research_sim_v4 import main
if __name__ == "__main__": main()
