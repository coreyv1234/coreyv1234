from __future__ import annotations
import math,dataclasses
from collections import Counter,defaultdict
from statistics import NormalDist
from typing import Any,Iterable
from zoneinfo import ZoneInfo
import numpy as np
import pandas as pd
CENTRAL = ZoneInfo('America/Chicago')
MGC_TICK_SIZE = 0.1
MGC_POINT_VALUE = 10.0
BASE_COST_PER_CONTRACT = 4.8
START_BALANCE = 50000.0
MAX_PLANNED_RISK_DOLLARS = 1000.0
MAX_CONTRACTS = 10
CORE_RISK_DOLLARS = 500.0
QUALITY_RISK_DOLLARS = 300.0
PROBE_RISK_DOLLARS = 100.0
PROBE_TARGET_R = 0.7
PROBE_MAX_HOLD_BARS = 3
ENTRY_START_MINUTE_CT = 2 * 60
ENTRY_END_MINUTE_CT = 12 * 60 + 30
FRIDAY_NO_NEW_ENTRY_UTC_HOUR = 17
MAX_TRADES_PER_CT_DATE = 20
BUFFER_UNLOCK_BALANCE = 52100.0
PRE_BUFFER_DAILY_LOSS_DOLLARS = 1500.0
POST_BUFFER_DAILY_LOSS_DOLLARS = 1850.0
PRE_BUFFER_MAX_CONTRACTS = 8
MIN_MINUTES_BETWEEN_TRADES = 0
MIN_STOP_POINTS = 1.2
MAX_STOP_POINTS = 8.0
EPS = 1e-12

@dataclasses.dataclass(frozen=True)
class EventRule:
    name: str
    family: str
    strictness: str
    direction_mode: str
    min_pattern_strength: float
    max_directional_cusum: float
    adx_min: float
    adx_max: float
    volume_min: float
    body_atr_min: float
    close_location_min: float
    slope20_min: float
    slope50_min: float
    vwap_buffer_atr: float
    break_buffer_atr: float
    sweep_buffer_atr: float
    reclaim_buffer_atr: float
    compression_min_atr: float
    compression_max_atr: float
    stop_atr_floor: float
    structure_lookback: int
    min_quality_score: float
    min_direction_margin: float
    max_extension_atr: float
    min_target_space_r: float
    max_entry_gap_atr: float
    atr_ratio_min: float
    atr_ratio_max: float
    confirmation_buffer_atr: float
    min_efficiency: float
    min_momentum_atr: float
    max_setup_age_bars: int
    min_kalman_slope_atr: float
    min_directional_cusum: float
    vr4_min: float
    vr4_max: float
    vr12_min: float
    vr12_max: float
    yz_ratio_min: float
    yz_ratio_max: float
    min_robust_volume_z: float
    min_fvg_size_atr: float

@dataclasses.dataclass(frozen=True)
class ExitProfile:
    name: str
    tp1_r: float
    tp2_r: float
    partial_fraction: float
    post_tp1_stop_r: float
    no_progress_bars: int
    no_progress_min_mfe_r: float
    max_hold_bars: int
    trail_after_r: float
    trail_lookback: int
    giveback_trigger_r: float
    giveback_floor_r: float

    @property
    def single_target(self) -> bool:
        return abs(self.tp1_r - self.tp2_r) < 1e-12

@dataclasses.dataclass(frozen=True)
class StrategyConfig:
    event_rule: EventRule
    exit_profile: ExitProfile

    @property
    def name(self) -> str:
        return f'{self.event_rule.name}__{self.exit_profile.name}'

def event_rules() -> list[EventRule]:
    """
    One scaled SHORT-only VWAP reclaim family. The signal itself is always a
    causal bearish close back below session VWAP with next-bar entry. Risk is
    assigned from information available on the completed signal bar:

    CORE    : ADX >= 20, bearish body >= 0.10 ATR, Kalman >= -0.05 -> $500 max
    QUALITY : ADX >= 20, bearish body >= 0.06 ATR, Kalman >= -0.15 -> $300 max
    Signals below QUALITY are rejected. This increases opportunity count over V9 while refusing the weak FLOW tier that failed the later regime. Maximum position is ten MGC contracts.
    """
    common = dict(family='VWAP_RECLAIM_ONLY', strictness='TIERED_RAW_BAR_EVIDENCE', direction_mode='SHORT_ONLY', min_pattern_strength=0.0, max_directional_cusum=50.0, adx_max=68.0, volume_min=0.0, body_atr_min=0.06, close_location_min=0.0, slope20_min=-0.22, slope50_min=-0.2, vwap_buffer_atr=0.0, break_buffer_atr=0.0, sweep_buffer_atr=0.0, reclaim_buffer_atr=0.0, compression_min_atr=0.0, compression_max_atr=9.0, stop_atr_floor=0.62, structure_lookback=4, min_quality_score=0.0, min_direction_margin=0.0, max_extension_atr=3.2, min_target_space_r=0.0, max_entry_gap_atr=0.34, atr_ratio_min=0.28, atr_ratio_max=3.2, confirmation_buffer_atr=0.0, min_efficiency=0.0, min_momentum_atr=-9.0, max_setup_age_bars=1, min_kalman_slope_atr=-0.15, min_directional_cusum=0.0, vr4_min=0.0, vr4_max=9.0, vr12_min=0.0, vr12_max=9.0, yz_ratio_min=0.28, yz_ratio_max=3.2, min_robust_volume_z=-9.0, min_fvg_size_atr=0.0)
    return [EventRule(name='VWAP_TREND_SHORT_TIERED', adx_min=12.0, **common)]

def exit_profiles() -> list[ExitProfile]:
    return [ExitProfile(name='CLEAN_SINGLE_0.90R_12', tp1_r=0.9, tp2_r=0.9, partial_fraction=1.0, post_tp1_stop_r=0.0, no_progress_bars=99, no_progress_min_mfe_r=-99.0, max_hold_bars=12, trail_after_r=99.0, trail_lookback=1, giveback_trigger_r=99.0, giveback_floor_r=-99.0)]

def strategy_configs() -> list[StrategyConfig]:
    return [StrategyConfig(rule, profile) for rule in event_rules() for profile in exit_profiles()]

def utc_timestamp(value: Any) -> pd.Timestamp:
    stamp = pd.Timestamp(value)
    if stamp.tzinfo is None:
        return stamp.tz_localize('UTC')
    return stamp.tz_convert('UTC')

def round_to_tick(price: float) -> float:
    return round(round(float(price) / MGC_TICK_SIZE) * MGC_TICK_SIZE, 10)

def entry_session_open(value: Any) -> bool:
    local = utc_timestamp(value).tz_convert(CENTRAL)
    minute = int(local.hour) * 60 + int(local.minute)
    return local.weekday() < 5 and ENTRY_START_MINUTE_CT <= minute < ENTRY_END_MINUTE_CT

def friday_entry_block(value: Any) -> bool:
    stamp = utc_timestamp(value)
    return stamp.weekday() == 4 and stamp.hour >= FRIDAY_NO_NEW_ENTRY_UTC_HOUR

def direction_stop(direction: str, entry: float, stop_distance: float) -> float:
    if direction == 'LONG':
        return round_to_tick(entry - stop_distance)
    return round_to_tick(entry + stop_distance)

def direction_target(direction: str, entry: float, stop_distance: float, multiple: float) -> float:
    if direction == 'LONG':
        return round_to_tick(entry + multiple * stop_distance)
    return round_to_tick(entry - multiple * stop_distance)

def stop_is_valid(direction: str, entry: float, stop: float) -> bool:
    if direction == 'LONG':
        return stop < entry
    return stop > entry

def quantity_for_stop(stop_distance: float, risk_budget_dollars: float | None=None) -> int:
    risk_per_contract = float(stop_distance) * MGC_POINT_VALUE
    if risk_per_contract <= 0.0:
        return 0
    budget = min(MAX_PLANNED_RISK_DOLLARS, float(risk_budget_dollars or MAX_PLANNED_RISK_DOLLARS))
    risk_limited = int(math.floor(budget / risk_per_contract))
    return max(0, min(MAX_CONTRACTS, risk_limited))

def split_quantity(quantity: int, partial_fraction: float, single_target: bool) -> tuple[int, int]:
    quantity = int(quantity)
    if quantity <= 0:
        return (0, 0)
    if quantity == 1 or single_target:
        return (quantity, 0)
    first = int(math.ceil(quantity * partial_fraction))
    first = min(quantity - 1, max(1, first))
    return (first, quantity - first)

def gross_pnl(direction: str, entry: float, exit_price: float, quantity: int) -> float:
    points = float(exit_price) - float(entry) if direction == 'LONG' else float(entry) - float(exit_price)
    return points * MGC_POINT_VALUE * int(quantity)

def _rolling_prior_robust_z(series: pd.Series, window: int, min_periods: int) -> pd.Series:
    """Median/MAD z-score against the distribution known before this bar."""
    prior_median = series.rolling(window, min_periods=min_periods).median().shift(1)
    abs_dev = (series - prior_median).abs()
    prior_mad = abs_dev.rolling(window, min_periods=min_periods).median().shift(1)
    robust_sigma = 1.4826 * prior_mad
    fallback = series.rolling(window, min_periods=min_periods).std(ddof=1).shift(1)
    scale = robust_sigma.where(robust_sigma > 1e-12, fallback).replace(0.0, np.nan)
    return (series - prior_median) / scale

def _yang_zhang_volatility(open_: pd.Series, high: pd.Series, low: pd.Series, close: pd.Series, window: int=20) -> pd.Series:
    """Rolling Yang-Zhang log-volatility using only OHLC known at each bar."""
    safe_o = open_.clip(lower=1e-12)
    safe_h = high.clip(lower=1e-12)
    safe_l = low.clip(lower=1e-12)
    safe_c = close.clip(lower=1e-12)
    prev_c = safe_c.shift(1)
    overnight = np.log(safe_o / prev_c)
    open_close = np.log(safe_c / safe_o)
    rs = np.log(safe_h / safe_o) * np.log(safe_h / safe_c) + np.log(safe_l / safe_o) * np.log(safe_l / safe_c)
    n = float(window)
    k = 0.34 / (1.34 + (n + 1.0) / max(n - 1.0, 1.0))
    overnight_var = overnight.rolling(window, min_periods=window).var(ddof=1)
    open_close_var = open_close.rolling(window, min_periods=window).var(ddof=1)
    rs_var = rs.rolling(window, min_periods=window).mean()
    yz_var = overnight_var + k * open_close_var + (1.0 - k) * rs_var
    return np.sqrt(yz_var.clip(lower=0.0))

def _kalman_local_linear(log_price: pd.Series) -> tuple[pd.Series, pd.Series, pd.Series]:
    """Causal two-state local-linear Kalman filter: hidden level and trend."""
    values = log_price.to_numpy(float)
    n = len(values)
    levels = np.full(n, np.nan)
    slopes = np.full(n, np.nan)
    innovations = np.full(n, np.nan)
    if n == 0:
        return (pd.Series(levels, index=log_price.index), pd.Series(slopes, index=log_price.index), pd.Series(innovations, index=log_price.index))
    finite = np.flatnonzero(np.isfinite(values))
    if len(finite) == 0:
        return (pd.Series(levels, index=log_price.index), pd.Series(slopes, index=log_price.index), pd.Series(innovations, index=log_price.index))
    start = int(finite[0])
    x = np.array([values[start], 0.0], dtype=float)
    p = np.array([[0.001, 0.0], [0.0, 0.0001]], dtype=float)
    f = np.array([[1.0, 1.0], [0.0, 1.0]], dtype=float)
    h = np.array([[1.0, 0.0]], dtype=float)
    identity = np.eye(2)
    recent_returns: list[float] = []
    previous_value = values[start]
    for i in range(start, n):
        z = values[i]
        if not np.isfinite(z):
            continue
        if i > start and np.isfinite(previous_value):
            recent_returns.append(float(z - previous_value))
            if len(recent_returns) > 80:
                recent_returns.pop(0)
        previous_value = z
        if len(recent_returns) >= 20:
            rv = float(np.var(recent_returns, ddof=1))
        else:
            rv = 1e-07
        measurement_var = max(rv, 1e-09)
        q_level = max(0.08 * measurement_var, 1e-10)
        q_slope = max(0.008 * measurement_var, 1e-11)
        q = np.array([[q_level, 0.0], [0.0, q_slope]], dtype=float)
        x_pred = f @ x
        p_pred = f @ p @ f.T + q
        innovation = float(z - (h @ x_pred)[0])
        innovation_var = float((h @ p_pred @ h.T)[0, 0] + measurement_var)
        gain = p_pred @ h.T / max(innovation_var, 1e-12)
        x = x_pred + gain[:, 0] * innovation
        p = (identity - gain @ h) @ p_pred
        levels[i] = x[0]
        slopes[i] = x[1]
        innovations[i] = innovation / math.sqrt(max(innovation_var, 1e-12))
    return (pd.Series(levels, index=log_price.index), pd.Series(slopes, index=log_price.index), pd.Series(innovations, index=log_price.index))

def _rolling_variance_ratio(log_price: pd.Series, horizon: int, window: int=72) -> pd.Series:
    one = log_price.diff()
    multi = log_price.diff(horizon)
    one_var = one.rolling(window, min_periods=max(30, window // 2)).var(ddof=1)
    multi_var = multi.rolling(window, min_periods=max(30, window // 2)).var(ddof=1)
    return multi_var / (float(horizon) * one_var.replace(0.0, np.nan))

def _directional_cusum(normalized_returns: pd.Series, drift: float=0.05) -> tuple[pd.Series, pd.Series]:
    pos = np.zeros(len(normalized_returns), dtype=float)
    neg = np.zeros(len(normalized_returns), dtype=float)
    p = 0.0
    n = 0.0
    for i, raw in enumerate(normalized_returns.fillna(0.0).to_numpy(float)):
        clipped = float(np.clip(raw, -4.0, 4.0))
        p = max(0.0, p + clipped - drift)
        n = min(0.0, n + clipped + drift)
        pos[i] = p
        neg[i] = -n
    return (pd.Series(pos, index=normalized_returns.index), pd.Series(neg, index=normalized_returns.index))

def build_indicators(segment: pd.DataFrame) -> pd.DataFrame:
    """
    Build only causal, completed-bar features. Every rolling structure level is
    shifted before use. Robust-z baselines are also shifted so the signal bar
    cannot edit its own historical distribution.
    """
    out = segment.copy()
    o = out['open'].astype(float)
    h = out['high'].astype(float)
    l = out['low'].astype(float)
    c = out['close'].astype(float)
    v = out['volume'].astype(float)
    previous_close = c.shift(1)
    true_range = pd.concat([h - l, (h - previous_close).abs(), (l - previous_close).abs()], axis=1).max(axis=1)
    atr = true_range.ewm(alpha=1.0 / 14.0, adjust=False, min_periods=14).mean()
    out['atr14'] = atr
    out['atr_ratio100'] = atr / atr.rolling(100, min_periods=60).median().shift(1).replace(0.0, np.nan)
    log_c = np.log(c.clip(lower=1e-12))
    log_return = log_c.diff()
    yz_vol = _yang_zhang_volatility(o, h, l, c, window=20)
    out['yz_vol20'] = yz_vol
    out['yz_vol_points'] = yz_vol * c
    out['yz_vol_atr'] = out['yz_vol_points'] / atr.replace(0.0, np.nan)
    out['yz_vol_ratio100'] = yz_vol / yz_vol.rolling(100, min_periods=60).median().shift(1).replace(0.0, np.nan)
    kalman_level_log, kalman_slope_log, kalman_innovation_z = _kalman_local_linear(log_c)
    out['kalman_level'] = np.exp(kalman_level_log)
    out['kalman_slope_atr'] = kalman_slope_log * c / atr.replace(0.0, np.nan)
    out['kalman_innovation_z'] = kalman_innovation_z
    out['variance_ratio4'] = _rolling_variance_ratio(log_c, 4, window=72)
    out['variance_ratio12'] = _rolling_variance_ratio(log_c, 12, window=96)
    return_sigma = log_return.rolling(48, min_periods=24).std(ddof=1).shift(1).replace(0.0, np.nan)
    normalized_return = log_return / return_sigma
    cusum_pos, cusum_neg = _directional_cusum(normalized_return)
    out['cusum_pos'] = cusum_pos
    out['cusum_neg'] = cusum_neg
    out['ema9'] = c.ewm(span=9, adjust=False, min_periods=9).mean()
    out['ema21'] = c.ewm(span=21, adjust=False, min_periods=21).mean()
    out['ema55'] = c.ewm(span=55, adjust=False, min_periods=55).mean()
    out['ema200'] = c.ewm(span=200, adjust=False, min_periods=200).mean()
    out['ema20'] = out['ema21']
    out['ema50'] = out['ema55']
    out['ema20_slope6_atr'] = (out['ema21'] - out['ema21'].shift(6)) / atr.replace(0.0, np.nan)
    out['ema50_slope12_atr'] = (out['ema55'] - out['ema55'].shift(12)) / atr.replace(0.0, np.nan)
    up_move = h.diff()
    down_move = -l.diff()
    plus_dm = pd.Series(np.where((up_move > down_move) & (up_move > 0.0), up_move, 0.0), index=out.index)
    minus_dm = pd.Series(np.where((down_move > up_move) & (down_move > 0.0), down_move, 0.0), index=out.index)
    plus_di = 100.0 * plus_dm.ewm(alpha=1.0 / 14.0, adjust=False, min_periods=14).mean() / atr.replace(0.0, np.nan)
    minus_di = 100.0 * minus_dm.ewm(alpha=1.0 / 14.0, adjust=False, min_periods=14).mean() / atr.replace(0.0, np.nan)
    dx = 100.0 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0.0, np.nan)
    out['plus_di'] = plus_di
    out['minus_di'] = minus_di
    out['adx14'] = dx.ewm(alpha=1.0 / 14.0, adjust=False, min_periods=14).mean()
    delta = c.diff()
    gains = delta.clip(lower=0.0).ewm(alpha=1.0 / 14.0, adjust=False, min_periods=14).mean()
    losses = (-delta.clip(upper=0.0)).ewm(alpha=1.0 / 14.0, adjust=False, min_periods=14).mean()
    rs = gains / losses.replace(0.0, np.nan)
    out['rsi14'] = 100.0 - 100.0 / (1.0 + rs)
    local_index = out.index.tz_convert(CENTRAL)
    session_date = pd.Series(local_index.date, index=out.index)
    local_minute_series = pd.Series(local_index.hour * 60 + local_index.minute, index=out.index)
    out['session_date'] = session_date
    out['local_minute'] = local_minute_series
    out['session_open'] = o.groupby(session_date).transform('first')
    typical = (h + l + c) / 3.0
    cumulative_pv = (typical * v).groupby(session_date).cumsum()
    cumulative_volume = v.groupby(session_date).cumsum()
    out['session_vwap'] = cumulative_pv / cumulative_volume.replace(0.0, np.nan)
    session_summary = pd.DataFrame({'session_date': session_date, 'high': h, 'low': l}, index=out.index).groupby('session_date').agg(session_high=('high', 'max'), session_low=('low', 'min'))
    out['prior_session_high'] = session_date.map(session_summary['session_high'].shift(1))
    out['prior_session_low'] = session_date.map(session_summary['session_low'].shift(1))
    session_high_running = h.groupby(session_date).cummax()
    session_low_running = l.groupby(session_date).cummin()
    out['session_high_prior'] = session_high_running.groupby(session_date).shift(1)
    out['session_low_prior'] = session_low_running.groupby(session_date).shift(1)
    out['volume_ratio20'] = v / v.rolling(20, min_periods=20).median().shift(1).replace(0.0, np.nan)
    out['volume_ratio5'] = v / v.rolling(5, min_periods=5).median().shift(1).replace(0.0, np.nan)
    out['robust_volume_z60'] = _rolling_prior_robust_z(np.log1p(v), 60, 30)
    for lookback in (6, 12, 24, 48):
        out[f'prior_high{lookback}'] = h.rolling(lookback, min_periods=lookback).max().shift(1)
        out[f'prior_low{lookback}'] = l.rolling(lookback, min_periods=lookback).min().shift(1)
    out['range8_atr'] = (h.rolling(8, min_periods=8).max().shift(1) - l.rolling(8, min_periods=8).min().shift(1)) / atr.replace(0.0, np.nan)
    out['range12_atr'] = (h.rolling(12, min_periods=12).max().shift(1) - l.rolling(12, min_periods=12).min().shift(1)) / atr.replace(0.0, np.nan)
    out['compression6_atr'] = (h.rolling(6, min_periods=6).max().shift(1) - l.rolling(6, min_periods=6).min().shift(1)) / atr.replace(0.0, np.nan)
    candle_range = (h - l).replace(0.0, np.nan)
    out['body_atr'] = (c - o) / atr.replace(0.0, np.nan)
    out['body_abs_atr'] = (c - o).abs() / atr.replace(0.0, np.nan)
    out['range_atr'] = candle_range / atr.replace(0.0, np.nan)
    out['close_location'] = (c - l) / candle_range
    out['extension_atr'] = (c - out['ema21']) / atr.replace(0.0, np.nan)
    out['upper_wick_atr'] = (h - pd.concat([o, c], axis=1).max(axis=1)) / atr.replace(0.0, np.nan)
    out['lower_wick_atr'] = (pd.concat([o, c], axis=1).min(axis=1) - l) / atr.replace(0.0, np.nan)
    out['momentum3_atr'] = (c - c.shift(3)) / atr.replace(0.0, np.nan)
    out['momentum1_atr'] = (c - c.shift(1)) / atr.replace(0.0, np.nan)
    out['robust_momentum_z60'] = _rolling_prior_robust_z(out['momentum3_atr'], 60, 30)
    out['robust_range_z60'] = _rolling_prior_robust_z(out['range_atr'], 60, 30)
    out['ema9_slope3_atr'] = (out['ema9'] - out['ema9'].shift(3)) / atr.replace(0.0, np.nan)
    out['adx_slope3'] = out['adx14'] - out['adx14'].shift(3)
    out['rsi_slope3'] = out['rsi14'] - out['rsi14'].shift(3)
    out['distance_vwap_atr'] = (c - out['session_vwap']) / atr.replace(0.0, np.nan)
    path_length20 = c.diff().abs().rolling(20, min_periods=20).sum()
    out['efficiency20'] = (c - c.shift(20)).abs() / path_length20.replace(0.0, np.nan)
    out['bull_fvg_size_atr'] = (l - h.shift(2)).clip(lower=0.0) / atr.replace(0.0, np.nan)
    out['bear_fvg_size_atr'] = (l.shift(2) - h).clip(lower=0.0) / atr.replace(0.0, np.nan)
    out['bull_fvg_lower'] = h.shift(2).where(out['bull_fvg_size_atr'] > 0.0)
    out['bull_fvg_upper'] = l.where(out['bull_fvg_size_atr'] > 0.0)
    out['bear_fvg_lower'] = h.where(out['bear_fvg_size_atr'] > 0.0)
    out['bear_fvg_upper'] = l.shift(2).where(out['bear_fvg_size_atr'] > 0.0)
    out['bar_seq'] = np.arange(len(out), dtype=int)
    return out.replace([np.inf, -np.inf], np.nan)
NEEDED_INDICATORS = ['atr14', 'atr_ratio100', 'yz_vol_ratio100', 'yz_vol_atr', 'ema9', 'ema21', 'ema55', 'ema200', 'ema20_slope6_atr', 'ema50_slope12_atr', 'ema9_slope3_atr', 'kalman_slope_atr', 'kalman_innovation_z', 'variance_ratio4', 'variance_ratio12', 'cusum_pos', 'cusum_neg', 'adx14', 'adx_slope3', 'plus_di', 'minus_di', 'rsi14', 'rsi_slope3', 'session_vwap', 'distance_vwap_atr', 'volume_ratio20', 'volume_ratio5', 'robust_volume_z60', 'robust_momentum_z60', 'robust_range_z60', 'prior_high6', 'prior_low6', 'prior_high12', 'prior_low12', 'prior_high24', 'prior_low24', 'prior_high48', 'prior_low48', 'body_atr', 'body_abs_atr', 'close_location', 'extension_atr', 'momentum1_atr', 'momentum3_atr', 'efficiency20', 'bull_fvg_size_atr', 'bear_fvg_size_atr', 'session_high_prior', 'session_low_prior']

def _finite(value: Any) -> bool:
    try:
        return bool(np.isfinite(float(value)))
    except Exception:
        return False

def _directional_value(direction: str, value: float) -> float:
    return float(value) if direction == 'LONG' else -float(value)

def _trend_alignment(row: pd.Series, direction: str) -> tuple[bool, bool]:
    is_long = direction == 'LONG'
    close = float(row['close'])
    ema9 = float(row['ema9'])
    ema21 = float(row['ema21'])
    ema55 = float(row['ema55'])
    ema200 = float(row['ema200'])
    plus_di = float(row['plus_di'])
    minus_di = float(row['minus_di'])
    slope20 = float(row['ema20_slope6_atr'])
    slope50 = float(row['ema50_slope12_atr'])
    kalman = float(row['kalman_slope_atr'])
    if is_long:
        strong = close > ema200 and ema9 > ema21 > ema55 and (slope20 > -0.01) and (slope50 > -0.04) and (kalman > -0.01) and (plus_di >= minus_di)
        supportive = close > ema55 and ema21 >= ema55 and (slope20 > -0.1) and (kalman > -0.1)
    else:
        strong = close < ema200 and ema9 < ema21 < ema55 and (slope20 < 0.01) and (slope50 < 0.04) and (kalman < 0.01) and (minus_di >= plus_di)
        supportive = close < ema55 and ema21 <= ema55 and (slope20 < 0.1) and (kalman < 0.1)
    return (bool(strong), bool(supportive))

def _nearest_target_space(row: pd.Series, direction: str, close: float, atr: float) -> float:
    if direction == 'LONG':
        names = ('session_high_prior', 'prior_high12', 'prior_high24', 'prior_high48', 'prior_session_high')
        spaces = [float(row[name]) - close for name in names if name in row and _finite(row[name]) and (float(row[name]) > close)]
    else:
        names = ('session_low_prior', 'prior_low12', 'prior_low24', 'prior_low48', 'prior_session_low')
        spaces = [close - float(row[name]) for name in names if name in row and _finite(row[name]) and (float(row[name]) < close)]
    return min(spaces) if spaces else 3.0 * atr
_REJECTION_AUDIT: dict[str, Counter] = defaultdict(Counter)

def _audit(rule: EventRule | str, reason: str, amount: int=1) -> None:
    name = rule if isinstance(rule, str) else rule.name
    _REJECTION_AUDIT[str(name)][str(reason)] += int(amount)

def _soft_band(value: float, low: float, high: float, shoulder: float=0.35) -> float:
    if not np.isfinite(value):
        return -0.5
    if low <= value <= high:
        center = 0.5 * (low + high)
        half = max(0.5 * (high - low), 1e-09)
        return 1.0 - 0.25 * abs(value - center) / half
    distance = low - value if value < low else value - high
    scale = max((high - low) * shoulder, 0.1)
    return max(-1.0, 1.0 - distance / scale)

def quality_score(direction: str, row: pd.Series, rule: EventRule, family: str, event_bonus: float, trend_aligned: bool, supportive_trend: bool, pattern_strength: float, target_space_r: float) -> float:
    """Weighted evidence score. Quant features mostly vote; structure remains mandatory."""
    adx = float(row['adx14'])
    adx_slope = float(row['adx_slope3'])
    volume_ratio = min(float(row['volume_ratio20']), float(row['volume_ratio5']))
    volume_z = float(row['robust_volume_z60'])
    momentum_z = _directional_value(direction, float(row['robust_momentum_z60']))
    body = abs(float(row['body_atr']))
    location = float(row['close_location']) if direction == 'LONG' else 1.0 - float(row['close_location'])
    efficiency = float(row['efficiency20'])
    extension = abs(float(row['extension_atr']))
    atr_ratio = float(row['atr_ratio100'])
    yz_ratio = float(row['yz_vol_ratio100'])
    momentum = _directional_value(direction, float(row['momentum3_atr']))
    kalman = _directional_value(direction, float(row['kalman_slope_atr']))
    innovation = _directional_value(direction, float(row['kalman_innovation_z']))
    cusum = float(row['cusum_pos'] if direction == 'LONG' else row['cusum_neg'])
    vr4 = float(row['variance_ratio4'])
    vr12 = float(row['variance_ratio12'])
    fvg = float(row['bull_fvg_size_atr'] if direction == 'LONG' else row['bear_fvg_size_atr'])
    vwap_distance = _directional_value(direction, float(row['distance_vwap_atr']))
    if family in {'BREAK_RETEST_CONFIRMED', 'FVG_PULLBACK_CONFIRMED'}:
        regime_fit = 0.55 * _soft_band(vr4, 0.72, 1.95) + 0.45 * _soft_band(vr12, 0.68, 1.85)
    else:
        regime_fit = 0.55 * _soft_band(vr4, 0.35, 1.42) + 0.45 * _soft_band(vr12, 0.35, 1.52)
    score = float(event_bonus)
    score += 0.95 if trend_aligned else 0.42 if supportive_trend else -0.1
    score += 0.42 * _soft_band(adx, 9.0, 48.0)
    score += min(0.28, max(-0.18, adx_slope / 14.0))
    score += min(0.48, max(-0.35, (volume_ratio - 0.65) * 0.65))
    score += min(0.3, max(-0.25, (volume_z + 0.45) * 0.16))
    score += min(0.62, max(-0.2, (body - 0.08) * 1.3))
    score += min(0.45, max(-0.2, (location - 0.5) * 1.45))
    score += min(0.42, max(-0.22, (efficiency - 0.06) * 1.1))
    score += min(0.5, max(-0.35, (momentum + 0.04) * 1.15))
    score += min(0.3, max(-0.25, (momentum_z + 0.35) * 0.14))
    score += min(0.58, max(-0.42, (kalman + 0.08) * 1.7))
    score += min(0.36, max(-0.25, (cusum - 0.05) * 0.14))
    score += 0.42 * regime_fit
    score += min(0.28, max(-0.2, (innovation + 0.35) * 0.1))
    score += min(0.72, max(0.0, target_space_r - 0.9) * 0.34)
    score += min(1.05, max(0.0, pattern_strength))
    score += min(0.3, max(0.0, fvg) * 1.7)
    score += min(0.28, max(-0.25, (vwap_distance + 0.2) * 0.22))
    score += 0.22 * _soft_band(atr_ratio, 0.55, 2.2)
    score += 0.22 * _soft_band(yz_ratio, 0.55, 2.2)
    score -= max(0.0, extension - 1.65) * 0.34
    score -= max(0.0, abs(innovation) - 3.8) * 0.08
    return float(score)

def _finalize_candidate(row: pd.Series, direction: str, rule: EventRule, family: str, invalidation_price: float, failure_level: float, event_bonus: float, pattern_strength: float, trend_aligned: bool, supportive_trend: bool, setup_age_bars: int, confirmation_strength: float) -> dict[str, Any] | None:
    close = float(row['close'])
    atr = float(row['atr14'])
    if direction == 'LONG':
        floor_stop = close - rule.stop_atr_floor * atr
        invalidation = min(float(invalidation_price), floor_stop)
        stop_distance = close - invalidation
    else:
        floor_stop = close + rule.stop_atr_floor * atr
        invalidation = max(float(invalidation_price), floor_stop)
        stop_distance = invalidation - close
    stop_distance = round_to_tick(stop_distance)
    invalidation = round_to_tick(invalidation)
    failure_level = round_to_tick(failure_level)
    if not MIN_STOP_POINTS <= stop_distance <= MAX_STOP_POINTS:
        _audit(rule, 'invalid_structural_stop')
        return None
    target_space = _nearest_target_space(row, direction, close, atr)
    target_space_r = target_space / max(stop_distance, MGC_TICK_SIZE)
    if target_space_r + 1e-09 < rule.min_target_space_r:
        _audit(rule, 'insufficient_target_space')
        return None
    if float(pattern_strength) + 1e-12 < rule.min_pattern_strength:
        _audit(rule, 'pattern_strength')
        return None
    volume_ratio = min(float(row['volume_ratio20']), float(row['volume_ratio5']))
    if volume_ratio + 1e-12 < rule.volume_min:
        _audit(rule, 'volume_floor')
        return None
    _audit(rule, 'quality_candidates')
    score = quality_score(direction, row, rule, family, event_bonus, trend_aligned, supportive_trend, pattern_strength + 0.25 * confirmation_strength, target_space_r)
    if score < rule.min_quality_score:
        _audit(rule, 'quality_score_too_low')
        return None
    return {'direction': direction, 'event_family': family, 'event_rule': rule.name, 'strictness': rule.strictness, 'quality_score': float(score), 'signal_close': close, 'signal_stop_distance': float(stop_distance), 'invalidation_price': float(invalidation), 'failure_level': float(failure_level), 'atr': atr, 'target_space_r': float(target_space_r), 'pattern_strength': float(pattern_strength), 'confirmation_strength': float(confirmation_strength), 'setup_age_bars': int(setup_age_bars), 'adx': float(row['adx14']), 'volume_ratio': float(min(row['volume_ratio20'], row['volume_ratio5'])), 'trend_aligned': bool(trend_aligned), 'supportive_trend': bool(supportive_trend), 'kalman_slope_atr': float(_directional_value(direction, row['kalman_slope_atr'])), 'kalman_innovation_z': float(_directional_value(direction, row['kalman_innovation_z'])), 'directional_cusum': float(row['cusum_pos'] if direction == 'LONG' else row['cusum_neg']), 'variance_ratio4': float(row['variance_ratio4']), 'variance_ratio12': float(row['variance_ratio12']), 'yz_vol_ratio100': float(row['yz_vol_ratio100']), 'robust_volume_z60': float(row['robust_volume_z60']), 'robust_momentum_z60': float(_directional_value(direction, row['robust_momentum_z60'])), 'fvg_size_atr': float(row['bull_fvg_size_atr'] if direction == 'LONG' else row['bear_fvg_size_atr'])}

def _broken_level(impulse: pd.Series, direction: str, buffer: float) -> float | None:
    is_long = direction == 'LONG'
    names = ('prior_high6', 'prior_high12', 'prior_high24') if is_long else ('prior_low6', 'prior_low12', 'prior_low24')
    close = float(impulse['close'])
    atr = float(impulse['atr14'])
    levels = [float(impulse[name]) for name in names if name in impulse and _finite(impulse[name])]
    broken = [level for level in levels if close >= level + buffer * atr] if is_long else [level for level in levels if close <= level - buffer * atr]
    if not broken:
        return None
    return max(broken) if is_long else min(broken)

def detect_direction_event(frame: pd.DataFrame, signal_i: int, direction: str, rule: EventRule) -> dict[str, Any] | None:
    _audit(rule, 'direction_checks')
    if rule.direction_mode == 'SHORT_ONLY' and direction != 'SHORT':
        _audit(rule, 'direction_mode')
        return None
    if rule.direction_mode == 'LONG_ONLY' and direction != 'LONG':
        _audit(rule, 'direction_mode')
        return None
    if signal_i < 225 or signal_i >= len(frame):
        return None
    row = frame.iloc[signal_i]
    previous = frame.iloc[signal_i - 1]
    if any((pd.isna(row.get(column)) for column in NEEDED_INDICATORS)):
        _audit(rule, 'missing_indicators')
        return None
    atr = float(row['atr14'])
    atr_ratio = float(row['atr_ratio100'])
    yz_ratio = float(row['yz_vol_ratio100'])
    if not np.isfinite(atr) or atr <= 0.0 or (not 0.22 <= atr_ratio <= 3.6) or (not 0.22 <= yz_ratio <= 3.6):
        _audit(rule, 'hard_volatility')
        return None
    if not rule.atr_ratio_min <= atr_ratio <= rule.atr_ratio_max or not rule.yz_ratio_min <= yz_ratio <= rule.yz_ratio_max:
        _audit(rule, 'rule_volatility')
        return None
    close = float(row['close'])
    signed_body = _directional_value(direction, float(row['body_atr']))
    signed_momentum = _directional_value(direction, float(row['momentum3_atr']))
    signed_slope20 = _directional_value(direction, float(row['ema20_slope6_atr']))
    signed_slope50 = _directional_value(direction, float(row['ema50_slope12_atr']))
    directional_cusum = float(row['cusum_pos'] if direction == 'LONG' else row['cusum_neg'])
    if directional_cusum > rule.max_directional_cusum:
        _audit(rule, 'quant_exhaustion')
        return None
    location = float(row['close_location']) if direction == 'LONG' else 1.0 - float(row['close_location'])
    volume_ratio = min(float(row['volume_ratio20']), float(row['volume_ratio5']))
    extension = abs(float(row['extension_atr']))
    is_long = direction == 'LONG'
    if extension > rule.max_extension_atr or float(row['range_atr']) > 4.25:
        _audit(rule, 'extreme_bar_or_extension')
        return None
    trend_aligned, supportive_trend = _trend_alignment(row, direction)
    if rule.family == 'VWAP_RECLAIM_ONLY':
        adx = float(row['adx14'])
        previous_vwap = float(previous['session_vwap'])
        current_vwap = float(row['session_vwap'])
        directional_kalman = _directional_value(direction, float(row['kalman_slope_atr']))
        crossed = _finite(previous_vwap) and _finite(current_vwap) and (float(previous['close']) >= previous_vwap) and (close < current_vwap)
        if not crossed:
            _audit(rule, 'no_completed_pattern')
            return None
        if not rule.adx_min <= adx <= rule.adx_max:
            _audit(rule, 'adx_regime')
            return None
        is_core = adx >= 20.0 and signed_body >= 0.1 and (directional_kalman >= -0.05)
        is_quality = adx >= 20.0 and signed_body >= 0.06 and (directional_kalman >= -0.15)
        if is_core:
            risk_tier = 'CORE'
            risk_budget = CORE_RISK_DOLLARS
            tier_bonus = 0.35
        elif is_quality:
            risk_tier = 'QUALITY'
            risk_budget = QUALITY_RISK_DOLLARS
            tier_bonus = 0.18
        else:
            _audit(rule, 'tier_rejected')
            return None
        recent = frame.iloc[max(0, signal_i - rule.structure_lookback + 1):signal_i + 1]
        recent_high = float(recent['high'].max())
        invalidation = max(recent_high, close + rule.stop_atr_floor * atr) + 0.05 * atr
        reclaim_depth = max(0.0, (current_vwap - close) / atr)
        pattern_strength = min(1.4, 0.35 + 0.5 * abs(signed_body) + 0.4 * reclaim_depth)
        _audit(rule, 'completed_structure_candidates')
        candidate = _finalize_candidate(row=row, direction=direction, rule=rule, family='VWAP_TREND_RECLAIM_CONFIRMED', invalidation_price=invalidation, failure_level=invalidation, event_bonus=7.25 + tier_bonus, pattern_strength=pattern_strength, trend_aligned=trend_aligned, supportive_trend=supportive_trend, setup_age_bars=1, confirmation_strength=reclaim_depth + max(0.0, signed_body))
        if candidate is not None:
            candidate['risk_tier'] = risk_tier
            candidate['risk_budget_dollars'] = float(risk_budget)
        return candidate
    candidates: list[dict[str, Any]] = []
    allow_break = rule.family in {'BREAK_RETEST_ONLY', 'ALL'}
    allow_sweep = rule.family in {'SWEEP_ONLY', 'ALL'}
    allow_fvg = rule.family in {'FVG_PULLBACK_ONLY', 'ALL'}
    if allow_break and (trend_aligned or supportive_trend or signed_slope20 > -0.04):
        for impulse_i in range(signal_i - 2, max(220, signal_i - rule.max_setup_age_bars - 1), -1):
            impulse = frame.iloc[impulse_i]
            if any((pd.isna(impulse.get(name)) for name in ('atr14', 'body_atr', 'close_location', 'volume_ratio20'))):
                continue
            impulse_atr = float(impulse['atr14'])
            if impulse_atr <= 0.0:
                continue
            break_level = _broken_level(impulse, direction, rule.break_buffer_atr)
            if break_level is None:
                continue
            impulse_body = _directional_value(direction, float(impulse['body_atr']))
            impulse_location = float(impulse['close_location']) if is_long else 1.0 - float(impulse['close_location'])
            impulse_volume = float(impulse['volume_ratio20'])
            impulse_fvg = float(impulse['bull_fvg_size_atr'] if is_long else impulse['bear_fvg_size_atr'])
            if impulse_body < max(0.14, 0.75 * rule.body_atr_min) or impulse_location < max(0.58, rule.close_location_min - 0.04) or impulse_volume < 0.55:
                continue
            pullback = frame.iloc[impulse_i + 1:signal_i]
            if pullback.empty:
                continue
            if is_long:
                extreme = float(pullback['low'].min())
                fvg_lower = float(impulse.get('bull_fvg_lower', np.nan))
                fvg_upper = float(impulse.get('bull_fvg_upper', np.nan))
                touched = extreme <= break_level + 0.46 * atr or (_finite(fvg_upper) and extreme <= fvg_upper + 0.1 * atr)
                held = float(pullback['close'].min()) >= min(break_level, fvg_lower if _finite(fvg_lower) else break_level) - 0.34 * atr
                confirmation_level = max(float(previous['high']), break_level)
                confirmed = close >= confirmation_level + rule.confirmation_buffer_atr * atr
                invalidation = extreme - 0.08 * atr
                failure_level = break_level - 0.18 * atr
                retrace_atr = (float(impulse['close']) - extreme) / atr
            else:
                extreme = float(pullback['high'].max())
                fvg_lower = float(impulse.get('bear_fvg_lower', np.nan))
                fvg_upper = float(impulse.get('bear_fvg_upper', np.nan))
                touched = extreme >= break_level - 0.46 * atr or (_finite(fvg_lower) and extreme >= fvg_lower - 0.1 * atr)
                held = float(pullback['close'].max()) <= max(break_level, fvg_upper if _finite(fvg_upper) else break_level) + 0.34 * atr
                confirmation_level = min(float(previous['low']), break_level)
                confirmed = close <= confirmation_level - rule.confirmation_buffer_atr * atr
                invalidation = extreme + 0.08 * atr
                failure_level = break_level + 0.18 * atr
                retrace_atr = (extreme - float(impulse['close'])) / atr
            if touched and held and confirmed and (0.03 <= retrace_atr <= 1.85) and (signed_body >= rule.body_atr_min) and (location >= rule.close_location_min):
                _audit(rule, 'completed_structure_candidates')
                candidate = _finalize_candidate(row, direction, rule, 'BREAK_RETEST_CONFIRMED', invalidation, failure_level, 3.7, min(1.35, 0.38 + 0.34 * retrace_atr + 1.4 * max(0.0, impulse_fvg)), trend_aligned, supportive_trend, signal_i - impulse_i, max(0.0, abs(close - confirmation_level) / atr) + max(0.0, signed_body))
                if candidate is not None:
                    candidates.append(candidate)
                break
    if allow_sweep:
        for setup_i in range(signal_i - 1, max(220, signal_i - rule.max_setup_age_bars - 1), -1):
            setup = frame.iloc[setup_i]
            if any((pd.isna(setup.get(name)) for name in ('atr14', 'rsi14', 'extension_atr', 'close_location'))):
                continue
            setup_atr = float(setup['atr14'])
            level_names = ('prior_low6', 'prior_low12', 'prior_low24', 'prior_session_low', 'session_low_prior') if is_long else ('prior_high6', 'prior_high12', 'prior_high24', 'prior_session_high', 'session_high_prior')
            best = None
            for name in level_names:
                if name not in setup or not _finite(setup[name]):
                    continue
                level = float(setup[name])
                extreme = float(setup['low'] if is_long else setup['high'])
                penetration = (level - extreme) / setup_atr if is_long else (extreme - level) / setup_atr
                reclaimed = float(setup['close']) >= level + 0.5 * rule.reclaim_buffer_atr * setup_atr if is_long else float(setup['close']) <= level - 0.5 * rule.reclaim_buffer_atr * setup_atr
                if max(0.018, 0.65 * rule.sweep_buffer_atr) <= penetration <= 1.35 and reclaimed:
                    if best is None or penetration > best[2]:
                        best = (level, penetration, extreme)
            if best is None:
                continue
            level, penetration, extreme = best
            confirm_level = max(float(previous['high']), level) if is_long else min(float(previous['low']), level)
            confirmed = close >= confirm_level + rule.confirmation_buffer_atr * atr if is_long else close <= confirm_level - rule.confirmation_buffer_atr * atr
            wick = float(setup['lower_wick_atr'] if is_long else setup['upper_wick_atr'])
            setup_extension = float(setup['extension_atr'])
            setup_rsi = float(setup['rsi14'])
            exhaustion = setup_extension <= -0.3 or setup_rsi <= 46.0 if is_long else setup_extension >= 0.3 or setup_rsi >= 54.0
            reversal_power = signed_body >= max(0.1, rule.body_atr_min) and location >= max(0.55, rule.close_location_min) and (volume_ratio >= 0.55)
            context_ok = supportive_trend or exhaustion or reversal_power or (signed_momentum > 0.05)
            if confirmed and context_ok and (wick >= 0.045) and (signed_body >= rule.body_atr_min) and (location >= rule.close_location_min):
                _audit(rule, 'completed_structure_candidates')
                confirmation_fvg = float(row['bull_fvg_size_atr'] if is_long else row['bear_fvg_size_atr'])
                candidate = _finalize_candidate(row, direction, rule, 'SWEEP_RECLAIM_CONFIRMED', extreme - 0.08 * atr if is_long else extreme + 0.08 * atr, level - 0.12 * atr if is_long else level + 0.12 * atr, 3.82, min(1.4, 0.34 + penetration + 0.3 * wick + 1.2 * confirmation_fvg), trend_aligned, supportive_trend, signal_i - setup_i, max(0.0, abs(close - confirm_level) / atr) + max(0.0, wick) + penetration)
                if candidate is not None:
                    candidates.append(candidate)
                break
    if allow_fvg and (supportive_trend or signed_momentum > 0.02 or signed_slope20 > -0.08):
        for impulse_i in range(signal_i - 2, max(220, signal_i - rule.max_setup_age_bars - 1), -1):
            impulse = frame.iloc[impulse_i]
            fvg_size = float(impulse['bull_fvg_size_atr'] if is_long else impulse['bear_fvg_size_atr'])
            if not np.isfinite(fvg_size) or fvg_size < max(0.006, rule.min_fvg_size_atr):
                continue
            impulse_body = _directional_value(direction, float(impulse['body_atr']))
            impulse_location = float(impulse['close_location']) if is_long else 1.0 - float(impulse['close_location'])
            displacement = impulse_body >= 0.16 and impulse_location >= 0.59
            if not displacement:
                continue
            pullback = frame.iloc[impulse_i + 1:signal_i]
            if pullback.empty:
                continue
            if is_long:
                lower = float(impulse['bull_fvg_lower'])
                upper = float(impulse['bull_fvg_upper'])
                extreme = float(pullback['low'].min())
                touched = extreme <= upper + 0.12 * atr and float(pullback['high'].max()) >= lower
                held = float(pullback['close'].min()) >= lower - 0.24 * atr
                confirm_level = float(previous['high'])
                confirmed = close >= confirm_level + rule.confirmation_buffer_atr * atr
                invalidation = extreme - 0.08 * atr
                failure_level = lower - 0.16 * atr
            else:
                lower = float(impulse['bear_fvg_lower'])
                upper = float(impulse['bear_fvg_upper'])
                extreme = float(pullback['high'].max())
                touched = extreme >= lower - 0.12 * atr and float(pullback['low'].min()) <= upper
                held = float(pullback['close'].max()) <= upper + 0.24 * atr
                confirm_level = float(previous['low'])
                confirmed = close <= confirm_level - rule.confirmation_buffer_atr * atr
                invalidation = extreme + 0.08 * atr
                failure_level = upper + 0.16 * atr
            if touched and held and confirmed and (signed_body >= rule.body_atr_min) and (location >= rule.close_location_min):
                _audit(rule, 'completed_structure_candidates')
                candidate = _finalize_candidate(row, direction, rule, 'FVG_PULLBACK_CONFIRMED', invalidation, failure_level, 3.62, min(1.35, 0.42 + 2.2 * fvg_size + 0.25 * max(0.0, impulse_body)), trend_aligned, supportive_trend, signal_i - impulse_i, max(0.0, abs(close - confirm_level) / atr) + fvg_size)
                if candidate is not None:
                    candidates.append(candidate)
                break
    if not candidates:
        _audit(rule, 'no_completed_pattern')
        return None
    candidates.sort(key=lambda item: (float(item['quality_score']), float(item['target_space_r']), float(item['confirmation_strength'])), reverse=True)
    return candidates[0]
_EVENT_CACHE: dict[tuple[str, str, int], dict[str, Any] | None] = {}
_EVENT_CACHE_LIMIT = 250000
PROBE_SWEEP_EMA50_MIN = -0.049404
PROBE_VWAP_YZ_MIN = 1.027087
PROBE_BREAKOUT_YZ_MAX = 1.058654
SCALP_RISK_DOLLARS = 800.0
SCALP_FAMILY_RISK_DOLLARS = {'SCALP_EXHAUST_LIQUID_SHORT': 1000.0, 'SCALP_SWEEP_CONTROLLED_SHORT': 800.0, 'SCALP_VWAP_LATE_SHORT': 800.0, 'SCALP_BREAK_LOW_RANGE_SHORT': 700.0}
SCALP_SWEEP_TARGET_R = 0.8
SCALP_VWAP_TARGET_R = 0.95
SCALP_EXHAUST_TARGET_R = 1.2
SCALP_BREAK_TARGET_R = 1.3
ENABLED_PROBE_FAMILIES = frozenset({'PROBE_VWAP_CROSS_SHORT'})
SCALP_STOP_FLOOR_ATR = 0.42
SCALP_STOP_CAP_ATR = 1.35
SCALP_VWAP_START_HOUR_CT = 7
SCALP_BREAK_YZ_MAX = 1.37
SCALP_BREAK_RANGE_Z_MAX = 0.23
SCALP_SWEEP_YZ_MAX = 1.3
SCALP_SWEEP_EXTENSION_MAX = 0.9
SCALP_EXHAUST_VOLUME_MIN = 0.92
SCALP_EXHAUST_RANGE_Z_MAX = 1.78
CORE_MAX_VARIANCE_RATIO4 = 0.95
SCALP_VWAP_MIN_DIRECTIONAL_CUSUM = 10.0
SCALP_BREAK_ADX_MAX = 35.0
SCALP_SWEEP_MAX_TARGET_SPACE_R = 2.83
ADDON_DAILY_FILL_TARGET = 4
ADDON_STOP_FLOOR_ATR = 0.42
ADDON_STOP_CAP_ATR = 1.35
ADDON_FAMILY_RISK_DOLLARS = {'ADDON_VWAP_IMPULSE_LONG': 500.0, 'ADDON_BREAK6_IMPULSE_SHORT': 600.0}
ADDON_FAMILY_TARGET_R = {'ADDON_VWAP_IMPULSE_LONG': 0.7, 'ADDON_BREAK6_IMPULSE_SHORT': 0.85}
ADDON_FAMILY_MAX_HOLD_BARS = {'ADDON_VWAP_IMPULSE_LONG': 4, 'ADDON_BREAK6_IMPULSE_SHORT': 5}
ADDON_LONG_MAX_EXTENSION_ATR = 0.58
ADDON_LONG_MIN_MOMENTUM_Z = 0.78
ADDON_SHORT_MIN_EXTENSION_ATR = -1.46
ADDON_SHORT_MIN_RANGE_Z = 2.24
ADDON_LONG_ALLOWED_HOURS_CT = frozenset({2, 3, 7, 8})
ADDON_SHORT_ALLOWED_HOURS_CT = frozenset({2, 4, 5, 6, 8, 9})

def _probe_payload(frame: pd.DataFrame, signal_i: int, family: str, invalidation: float, pattern_strength: float, priority: int) -> dict[str, Any] | None:
    row = frame.iloc[signal_i]
    close = float(row['close'])
    atr = float(row['atr14'])
    stop_distance = float(invalidation) - close
    if not np.isfinite(stop_distance) or stop_distance <= 0.0:
        return None
    trend_aligned, supportive_trend = _trend_alignment(row, 'SHORT')
    target_space = _nearest_target_space(row, 'SHORT', close, atr)
    target_space_r = target_space / max(stop_distance, EPS)
    volume_ratio = min(float(row['volume_ratio20']), float(row['volume_ratio5']))
    quality = 6.25 + 0.35 * float(pattern_strength)
    return {'direction': 'SHORT', 'event_family': family, 'event_rule': 'V12_PROBE_FLOW', 'strictness': 'LOW_RISK_CAUSAL_PROBE', 'quality_score': float(quality), 'opposite_score': 0.0, 'direction_margin': float(quality), 'signal_close': close, 'signal_stop_distance': float(stop_distance), 'invalidation_price': float(invalidation), 'failure_level': float(invalidation), 'atr': atr, 'target_space_r': float(target_space_r), 'pattern_strength': float(pattern_strength), 'confirmation_strength': float(pattern_strength), 'setup_age_bars': 1, 'adx': float(row['adx14']), 'volume_ratio': float(volume_ratio), 'trend_aligned': bool(trend_aligned), 'supportive_trend': bool(supportive_trend), 'kalman_slope_atr': float(-float(row['kalman_slope_atr'])), 'kalman_innovation_z': float(-float(row['kalman_innovation_z'])), 'directional_cusum': float(row['cusum_neg']), 'variance_ratio4': float(row['variance_ratio4']), 'variance_ratio12': float(row['variance_ratio12']), 'yz_vol_ratio100': float(row['yz_vol_ratio100']), 'robust_volume_z60': float(row['robust_volume_z60']), 'robust_momentum_z60': float(-float(row['robust_momentum_z60'])), 'fvg_size_atr': float(row['bear_fvg_size_atr']), 'risk_tier': 'PROBE', 'risk_budget_dollars': PROBE_RISK_DOLLARS, 'execution_mode': 'PROBE', 'target_r_override': PROBE_TARGET_R, 'max_hold_bars_override': PROBE_MAX_HOLD_BARS, 'stop_floor_atr_override': 0.0, 'probe_priority': int(priority)}

def detect_probe_event(frame: pd.DataFrame, signal_i: int) -> dict[str, Any] | None:
    if signal_i < 225 or signal_i >= len(frame):
        return None
    row = frame.iloc[signal_i]
    previous = frame.iloc[signal_i - 1]
    required = ('atr14', 'session_vwap', 'prior_high12', 'prior_low12', 'body_atr', 'close_location', 'ema50_slope12_atr', 'yz_vol_ratio100', 'range_atr', 'extension_atr')
    if any((pd.isna(row.get(name)) for name in required)):
        return None
    atr = float(row['atr14'])
    if not np.isfinite(atr) or atr <= 0.0:
        return None
    if abs(float(row['extension_atr'])) > 3.2 or float(row['range_atr']) > 4.25:
        return None
    close = float(row['close'])
    high = float(row['high'])
    body = float(row['body_atr'])
    location = float(row['close_location'])
    yz = float(row['yz_vol_ratio100'])
    candidates: list[dict[str, Any]] = []
    prior_high12 = float(row['prior_high12'])
    if high > prior_high12 + 0.02 * atr and close < prior_high12 and (location < 0.42) and (body < 0.0) and (float(row['ema50_slope12_atr']) >= PROBE_SWEEP_EMA50_MIN):
        invalidation = high + 0.08 * atr
        strength = max(0.0, (high - prior_high12) / atr) + abs(body)
        candidate = _probe_payload(frame, signal_i, 'PROBE_SWEEP_REVERSAL_SHORT', invalidation, strength, 0)
        if candidate is not None:
            candidates.append(candidate)
    previous_vwap = float(previous.get('session_vwap', np.nan))
    current_vwap = float(row['session_vwap'])
    if _finite(previous_vwap) and float(previous['close']) >= previous_vwap and (close < current_vwap) and (body < -0.03) and (yz >= PROBE_VWAP_YZ_MIN):
        recent = frame.iloc[max(0, signal_i - 3):signal_i + 1]
        invalidation = max(float(recent['high'].max()), close + 0.55 * atr) + 0.05 * atr
        strength = max(0.0, (current_vwap - close) / atr) + abs(body)
        candidate = _probe_payload(frame, signal_i, 'PROBE_VWAP_CROSS_SHORT', invalidation, strength, 1)
        if candidate is not None:
            candidates.append(candidate)
    prior_low12 = float(row['prior_low12'])
    if close < prior_low12 - 0.03 * atr and body < -0.12 and (location < 0.4) and (yz <= PROBE_BREAKOUT_YZ_MAX):
        recent = frame.iloc[max(0, signal_i - 3):signal_i + 1]
        invalidation = max(float(recent['high'].max()), prior_low12 + 0.1 * atr)
        strength = max(0.0, (prior_low12 - close) / atr) + abs(body)
        candidate = _probe_payload(frame, signal_i, 'PROBE_BREAKOUT_SHORT', invalidation, strength, 2)
        if candidate is not None:
            candidates.append(candidate)
    candidates = [item for item in candidates if str(item.get('event_family')) in ENABLED_PROBE_FAMILIES and int(pd.Timestamp(frame.index[signal_i]).tz_convert(CENTRAL).hour) == 2]
    if not candidates:
        return None
    candidates.sort(key=lambda item: int(item['probe_priority']))
    return candidates[0]

def simulate_probe_trade(frame: pd.DataFrame, signal_i: int, signal: dict[str, Any], config: StrategyConfig) -> dict[str, Any] | None:
    entry_i = signal_i + 1
    if entry_i >= len(frame):
        return None
    entry_time = pd.Timestamp(frame.index[entry_i])
    entry = round_to_tick(float(frame.iloc[entry_i]['open']))
    initial_stop = round_to_tick(float(signal['invalidation_price']))
    if not stop_is_valid('SHORT', entry, initial_stop):
        return None
    stop_distance = round_to_tick(initial_stop - entry)
    if not MIN_STOP_POINTS <= stop_distance <= MAX_STOP_POINTS:
        return None
    quantity = quantity_for_stop(stop_distance, PROBE_RISK_DOLLARS)
    if quantity <= 0:
        return None
    planned_risk = stop_distance * MGC_POINT_VALUE * quantity
    if planned_risk > PROBE_RISK_DOLLARS + 1e-06:
        raise AssertionError('PROBE risk exceeded its configured ceiling.')
    target = direction_target('SHORT', entry, stop_distance, PROBE_TARGET_R)
    final_i = min(len(frame) - 1, entry_i + PROBE_MAX_HOLD_BARS - 1)
    final_exit_price = round_to_tick(float(frame.iloc[final_i]['close']))
    exit_reason = 'PROBE_TIME_EXIT'
    mfe_r = 0.0
    mae_r = 0.0
    for bar_i in range(entry_i, min(len(frame), entry_i + PROBE_MAX_HOLD_BARS)):
        bar = frame.iloc[bar_i]
        high = float(bar['high'])
        low = float(bar['low'])
        mfe_r = max(mfe_r, (entry - low) / stop_distance)
        mae_r = min(mae_r, (entry - high) / stop_distance)
        stop_hit = high >= initial_stop
        target_hit = low <= target
        if stop_hit:
            final_i = bar_i
            final_exit_price = initial_stop
            exit_reason = 'PROBE_STOP'
            break
        if target_hit:
            final_i = bar_i
            final_exit_price = target
            exit_reason = 'PROBE_TARGET'
            break
    gross = gross_pnl('SHORT', entry, final_exit_price, quantity)
    costs = BASE_COST_PER_CONTRACT * quantity
    net = gross - costs
    return {'strategy': f'{config.event_rule.name}__V12_MULTI_ENGINE', 'event_family': signal['event_family'], 'event_rule': signal['event_rule'], 'strictness': signal['strictness'], 'direction': 'SHORT', 'signal_i': int(signal_i), 'entry_i': int(entry_i), 'exit_i': int(final_i), 'signal_time': pd.Timestamp(frame.index[signal_i]), 'entry_time': entry_time, 'exit_time': pd.Timestamp(frame.index[final_i]), 'segment_id': str(frame['segment_id'].iloc[0]), 'quality_score': float(signal['quality_score']), 'risk_tier': 'PROBE', 'risk_budget_dollars': PROBE_RISK_DOLLARS, 'opposite_score': 0.0, 'direction_margin': float(signal['direction_margin']), 'pattern_strength': float(signal['pattern_strength']), 'confirmation_strength': float(signal['confirmation_strength']), 'setup_age_bars': 1, 'target_space_r': float(signal['target_space_r']), 'adx': float(signal['adx']), 'volume_ratio': float(signal['volume_ratio']), 'kalman_slope_atr': float(signal['kalman_slope_atr']), 'kalman_innovation_z': float(signal['kalman_innovation_z']), 'directional_cusum': float(signal['directional_cusum']), 'variance_ratio4': float(signal['variance_ratio4']), 'variance_ratio12': float(signal['variance_ratio12']), 'yz_vol_ratio100': float(signal['yz_vol_ratio100']), 'robust_volume_z60': float(signal['robust_volume_z60']), 'robust_momentum_z60': float(signal['robust_momentum_z60']), 'fvg_size_atr': float(signal['fvg_size_atr']), 'trend_aligned': bool(signal['trend_aligned']), 'supportive_trend': bool(signal['supportive_trend']), 'entry_price': float(entry), 'invalidation_price': float(initial_stop), 'failure_level': float(initial_stop), 'initial_stop': float(initial_stop), 'last_working_stop': float(initial_stop), 'stop_orientation_valid': True, 'stop_distance': float(stop_distance), 'tp1': float(target), 'tp2': float(target), 'tp1_r': PROBE_TARGET_R, 'tp2_r': PROBE_TARGET_R, 'quantity': int(quantity), 'tp1_quantity': int(quantity), 'tp2_quantity': 0, 'planned_risk_dollars': float(planned_risk), 'gross_pnl': float(gross), 'costs': float(costs), 'net_pnl': float(net), 'exit_reason': exit_reason, 'mfe_r': float(mfe_r), 'mae_r': float(mae_r), 'final_exit_price': float(final_exit_price)}

def _scalp_payload(frame: pd.DataFrame, signal_i: int, family: str, invalidation: float, pattern_strength: float, priority: int, target_r: float, max_hold_bars: int) -> dict[str, Any] | None:
    row = frame.iloc[signal_i]
    close = float(row['close'])
    atr = float(row['atr14'])
    raw_distance = float(invalidation) - close
    if not np.isfinite(raw_distance) or raw_distance <= 0.0:
        return None
    trend_aligned, supportive_trend = _trend_alignment(row, 'SHORT')
    target_space = _nearest_target_space(row, 'SHORT', close, atr)
    target_space_r = target_space / max(raw_distance, EPS)
    volume_ratio = min(float(row['volume_ratio20']), float(row['volume_ratio5']))
    quality = 6.5 + 0.4 * float(pattern_strength)
    return {'direction': 'SHORT', 'event_family': family, 'event_rule': 'V12_SCALP_FLOW', 'strictness': 'CAUSAL_MULTI_FAMILY_SCALP', 'quality_score': float(quality), 'opposite_score': 0.0, 'direction_margin': float(quality), 'signal_close': close, 'signal_stop_distance': float(raw_distance), 'invalidation_price': float(invalidation), 'failure_level': float(invalidation), 'atr': atr, 'target_space_r': float(target_space_r), 'pattern_strength': float(pattern_strength), 'confirmation_strength': float(pattern_strength), 'setup_age_bars': 1, 'adx': float(row['adx14']), 'volume_ratio': float(volume_ratio), 'trend_aligned': bool(trend_aligned), 'supportive_trend': bool(supportive_trend), 'kalman_slope_atr': float(-float(row['kalman_slope_atr'])), 'kalman_innovation_z': float(-float(row['kalman_innovation_z'])), 'directional_cusum': float(row['cusum_neg']), 'variance_ratio4': float(row['variance_ratio4']), 'variance_ratio12': float(row['variance_ratio12']), 'yz_vol_ratio100': float(row['yz_vol_ratio100']), 'robust_volume_z60': float(row['robust_volume_z60']), 'robust_momentum_z60': float(-float(row['robust_momentum_z60'])), 'fvg_size_atr': float(row['bear_fvg_size_atr']), 'risk_tier': 'SCALP', 'risk_budget_dollars': float(SCALP_FAMILY_RISK_DOLLARS.get(family, SCALP_RISK_DOLLARS)), 'execution_mode': 'SCALP', 'target_r_override': float(target_r), 'max_hold_bars_override': int(max_hold_bars), 'stop_floor_atr_override': SCALP_STOP_FLOOR_ATR, 'stop_cap_atr_override': SCALP_STOP_CAP_ATR, 'scalp_priority': int(priority)}

def detect_scalp_event(frame: pd.DataFrame, signal_i: int) -> dict[str, Any] | None:
    if signal_i < 225 or signal_i >= len(frame):
        return None
    row = frame.iloc[signal_i]
    previous = frame.iloc[signal_i - 1]
    required = ('atr14', 'session_vwap', 'prior_high6', 'prior_low6', 'prior_high12', 'prior_low12', 'body_atr', 'close_location', 'adx14', 'yz_vol_ratio100', 'extension_atr', 'kalman_slope_atr', 'robust_momentum_z60', 'robust_range_z60', 'volume_ratio20')
    if any((pd.isna(row.get(name)) for name in required)):
        return None
    atr = float(row['atr14'])
    if not np.isfinite(atr) or atr <= 0.0:
        return None
    close = float(row['close'])
    high = float(row['high'])
    body = float(row['body_atr'])
    location = float(row['close_location'])
    adx = float(row['adx14'])
    yz = float(row['yz_vol_ratio100'])
    extension = float(row['extension_atr'])
    kalman = float(row['kalman_slope_atr'])
    range_z = float(row['robust_range_z60'])
    candidates: list[dict[str, Any]] = []
    local_hour = int(pd.Timestamp(frame.index[signal_i]).tz_convert(CENTRAL).hour)
    prior_high12 = float(row['prior_high12'])
    if high > prior_high12 + 0.02 * atr and close < prior_high12 and (location < 0.45) and (body < 0.0) and (yz <= SCALP_SWEEP_YZ_MAX) and (extension <= SCALP_SWEEP_EXTENSION_MAX) and (local_hour not in (5,)):
        invalidation = high + 0.06 * atr
        strength = max(0.0, (high - prior_high12) / atr) + abs(body)
        candidate = _scalp_payload(frame, signal_i, 'SCALP_SWEEP_CONTROLLED_SHORT', invalidation, strength, 0, SCALP_SWEEP_TARGET_R, 5)
        if candidate is not None and float(candidate['target_space_r']) <= SCALP_SWEEP_MAX_TARGET_SPACE_R:
            candidates.append(candidate)
    previous_vwap = float(previous.get('session_vwap', np.nan))
    current_vwap = float(row['session_vwap'])
    if _finite(previous_vwap) and local_hour >= SCALP_VWAP_START_HOUR_CT and (local_hour not in (12,)) and (float(previous['close']) >= previous_vwap) and (close < current_vwap) and (body < -0.03) and (yz >= 0.85) and (location < 0.48) and (float(row['cusum_neg']) >= SCALP_VWAP_MIN_DIRECTIONAL_CUSUM):
        recent = frame.iloc[max(0, signal_i - 3):signal_i + 1]
        invalidation = max(float(recent['high'].max()), close + 0.55 * atr) + 0.04 * atr
        strength = max(0.0, (current_vwap - close) / atr) + abs(body)
        candidate = _scalp_payload(frame, signal_i, 'SCALP_VWAP_LATE_SHORT', invalidation, strength, 1, SCALP_VWAP_TARGET_R, 5)
        if candidate is not None:
            candidates.append(candidate)
    close_values = frame['close'].iloc[signal_i - 4:signal_i].to_numpy(float)
    run3_previous = float(np.sign(np.diff(close_values)).sum()) if len(close_values) == 4 else 0.0
    previous_extension = float(previous['extension_atr'])
    previous_momentum_z = float(previous['robust_momentum_z60'])
    previous_range_z = float(previous['robust_range_z60'])
    if previous_extension > 1.0 and run3_previous >= 1.0 and (body < -0.04) and (location < 0.45) and (close < float(previous['low'])) and (previous_momentum_z > 0.4 or previous_range_z > 0.35) and (float(row['volume_ratio20']) >= SCALP_EXHAUST_VOLUME_MIN) and (range_z <= SCALP_EXHAUST_RANGE_Z_MAX) and (local_hour in (2, 3, 4, 9, 10, 11)):
        invalidation = max(float(previous['high']), high) + 0.06 * atr
        strength = abs(previous_extension) + abs(body)
        candidate = _scalp_payload(frame, signal_i, 'SCALP_EXHAUST_LIQUID_SHORT', invalidation, strength, 2, SCALP_EXHAUST_TARGET_R, 6)
        if candidate is not None:
            candidates.append(candidate)
    prior_low6 = float(row['prior_low6'])
    if close < prior_low6 - 0.015 * atr and body < -0.1 and (location < 0.42) and (adx >= 14.0) and (adx <= SCALP_BREAK_ADX_MAX) and (kalman < 0.08) and (yz <= SCALP_BREAK_YZ_MAX) and (range_z <= SCALP_BREAK_RANGE_Z_MAX) and (local_hour not in (10,)):
        recent = frame.iloc[max(0, signal_i - 3):signal_i + 1]
        invalidation = float(recent['high'].max()) + 0.04 * atr
        strength = abs(body) + max(0.0, (prior_low6 - close) / atr)
        candidate = _scalp_payload(frame, signal_i, 'SCALP_BREAK_LOW_RANGE_SHORT', invalidation, strength, 3, SCALP_BREAK_TARGET_R, 6)
        if candidate is not None:
            candidates.append(candidate)
    if not candidates:
        return None
    candidates.sort(key=lambda item: int(item['scalp_priority']))
    return candidates[0]

def simulate_scalp_trade(frame: pd.DataFrame, signal_i: int, signal: dict[str, Any], config: StrategyConfig) -> dict[str, Any] | None:
    entry_i = signal_i + 1
    if entry_i >= len(frame):
        return None
    entry_time = pd.Timestamp(frame.index[entry_i])
    entry = round_to_tick(float(frame.iloc[entry_i]['open']))
    atr = float(signal['atr'])
    raw_distance = float(signal['invalidation_price']) - entry
    stop_distance = max(raw_distance, SCALP_STOP_FLOOR_ATR * atr, MIN_STOP_POINTS)
    stop_distance = min(stop_distance, SCALP_STOP_CAP_ATR * atr, MAX_STOP_POINTS)
    if not MIN_STOP_POINTS <= stop_distance <= MAX_STOP_POINTS:
        return None
    initial_stop = round_to_tick(entry + stop_distance)
    stop_distance = round_to_tick(initial_stop - entry)
    if not stop_is_valid('SHORT', entry, initial_stop):
        return None
    scalp_risk_budget = float(signal.get('risk_budget_dollars', SCALP_RISK_DOLLARS))
    quantity = quantity_for_stop(stop_distance, scalp_risk_budget)
    if quantity <= 0:
        return None
    planned_risk = stop_distance * MGC_POINT_VALUE * quantity
    if planned_risk > scalp_risk_budget + 1e-06:
        raise AssertionError('SCALP risk exceeded its configured family ceiling.')
    target_r = float(signal['target_r_override'])
    max_hold_bars = int(signal['max_hold_bars_override'])
    target = direction_target('SHORT', entry, stop_distance, target_r)
    final_i = min(len(frame) - 1, entry_i + max_hold_bars - 1)
    final_exit_price = round_to_tick(float(frame.iloc[final_i]['close']))
    exit_reason = 'SCALP_TIME_EXIT'
    mfe_r = 0.0
    mae_r = 0.0
    for bar_i in range(entry_i, min(len(frame), entry_i + max_hold_bars)):
        bar = frame.iloc[bar_i]
        high = float(bar['high'])
        low = float(bar['low'])
        mfe_r = max(mfe_r, (entry - low) / stop_distance)
        mae_r = min(mae_r, (entry - high) / stop_distance)
        stop_hit = high >= initial_stop
        target_hit = low <= target
        if stop_hit:
            final_i = bar_i
            final_exit_price = initial_stop
            exit_reason = 'SCALP_STOP'
            break
        if target_hit:
            final_i = bar_i
            final_exit_price = target
            exit_reason = 'SCALP_TARGET'
            break
    gross = gross_pnl('SHORT', entry, final_exit_price, quantity)
    costs = BASE_COST_PER_CONTRACT * quantity
    net = gross - costs
    return {'strategy': f'{config.event_rule.name}__V12_MULTI_ENGINE', 'event_family': signal['event_family'], 'event_rule': signal['event_rule'], 'strictness': signal['strictness'], 'direction': 'SHORT', 'signal_i': int(signal_i), 'entry_i': int(entry_i), 'exit_i': int(final_i), 'signal_time': pd.Timestamp(frame.index[signal_i]), 'entry_time': entry_time, 'exit_time': pd.Timestamp(frame.index[final_i]), 'segment_id': str(frame['segment_id'].iloc[0]), 'quality_score': float(signal['quality_score']), 'risk_tier': 'SCALP', 'risk_budget_dollars': float(signal.get('risk_budget_dollars', SCALP_RISK_DOLLARS)), 'opposite_score': 0.0, 'direction_margin': float(signal['direction_margin']), 'pattern_strength': float(signal['pattern_strength']), 'confirmation_strength': float(signal['confirmation_strength']), 'setup_age_bars': 1, 'target_space_r': float(signal['target_space_r']), 'adx': float(signal['adx']), 'volume_ratio': float(signal['volume_ratio']), 'kalman_slope_atr': float(signal['kalman_slope_atr']), 'kalman_innovation_z': float(signal['kalman_innovation_z']), 'directional_cusum': float(signal['directional_cusum']), 'variance_ratio4': float(signal['variance_ratio4']), 'variance_ratio12': float(signal['variance_ratio12']), 'yz_vol_ratio100': float(signal['yz_vol_ratio100']), 'robust_volume_z60': float(signal['robust_volume_z60']), 'robust_momentum_z60': float(signal['robust_momentum_z60']), 'fvg_size_atr': float(signal['fvg_size_atr']), 'trend_aligned': bool(signal['trend_aligned']), 'supportive_trend': bool(signal['supportive_trend']), 'entry_price': float(entry), 'invalidation_price': float(initial_stop), 'failure_level': float(initial_stop), 'initial_stop': float(initial_stop), 'last_working_stop': float(initial_stop), 'stop_orientation_valid': True, 'stop_distance': float(stop_distance), 'tp1': float(target), 'tp2': float(target), 'tp1_r': target_r, 'tp2_r': target_r, 'quantity': int(quantity), 'tp1_quantity': int(quantity), 'tp2_quantity': 0, 'planned_risk_dollars': float(planned_risk), 'gross_pnl': float(gross), 'costs': float(costs), 'net_pnl': float(net), 'exit_reason': exit_reason, 'mfe_r': float(mfe_r), 'mae_r': float(mae_r), 'final_exit_price': float(final_exit_price)}

def _addon_payload(frame: pd.DataFrame, signal_i: int, family: str, direction: str, invalidation: float, pattern_strength: float, priority: int) -> dict[str, Any] | None:
    row = frame.iloc[signal_i]
    close = float(row['close'])
    atr = float(row['atr14'])
    raw_distance = close - float(invalidation) if direction == 'LONG' else float(invalidation) - close
    if not np.isfinite(raw_distance) or raw_distance <= 0.0:
        return None
    trend_aligned, supportive_trend = _trend_alignment(row, direction)
    target_space = _nearest_target_space(row, direction, close, atr)
    target_space_r = target_space / max(raw_distance, EPS)
    volume_ratio = min(float(row['volume_ratio20']), float(row['volume_ratio5']))
    quality = 6.1 + 0.4 * float(pattern_strength)
    directional_sign = 1.0 if direction == 'LONG' else -1.0
    return {'direction': direction, 'event_family': family, 'event_rule': 'V12_6_DUAL_EDGE_ADDON', 'strictness': 'LOW_RISK_INDEPENDENT_ADDON', 'quality_score': float(quality), 'opposite_score': 0.0, 'direction_margin': float(quality), 'signal_close': close, 'signal_stop_distance': float(raw_distance), 'invalidation_price': float(invalidation), 'failure_level': float(invalidation), 'atr': atr, 'target_space_r': float(target_space_r), 'pattern_strength': float(pattern_strength), 'confirmation_strength': float(pattern_strength), 'setup_age_bars': 1, 'adx': float(row['adx14']), 'volume_ratio': float(volume_ratio), 'trend_aligned': bool(trend_aligned), 'supportive_trend': bool(supportive_trend), 'kalman_slope_atr': float(directional_sign * float(row['kalman_slope_atr'])), 'kalman_innovation_z': float(directional_sign * float(row['kalman_innovation_z'])), 'directional_cusum': float(row['cusum_pos'] if direction == 'LONG' else row['cusum_neg']), 'variance_ratio4': float(row['variance_ratio4']), 'variance_ratio12': float(row['variance_ratio12']), 'yz_vol_ratio100': float(row['yz_vol_ratio100']), 'robust_volume_z60': float(row['robust_volume_z60']), 'robust_momentum_z60': float(directional_sign * float(row['robust_momentum_z60'])), 'fvg_size_atr': float(row['bull_fvg_size_atr'] if direction == 'LONG' else row['bear_fvg_size_atr']), 'risk_tier': 'ADDON', 'risk_budget_dollars': float(ADDON_FAMILY_RISK_DOLLARS[family]), 'execution_mode': 'ADDON', 'target_r_override': float(ADDON_FAMILY_TARGET_R[family]), 'max_hold_bars_override': int(ADDON_FAMILY_MAX_HOLD_BARS[family]), 'stop_floor_atr_override': ADDON_STOP_FLOOR_ATR, 'stop_cap_atr_override': ADDON_STOP_CAP_ATR, 'addon_priority': int(priority)}

def detect_addon_event(frame: pd.DataFrame, signal_i: int) -> dict[str, Any] | None:
    if signal_i < 225 or signal_i >= len(frame):
        return None
    row = frame.iloc[signal_i]
    previous = frame.iloc[signal_i - 1]
    required = ('atr14', 'session_vwap', 'prior_low6', 'body_atr', 'close_location', 'adx14', 'kalman_slope_atr', 'extension_atr', 'robust_momentum_z60', 'robust_range_z60', 'range_atr', 'volume_ratio20', 'volume_ratio5')
    if any((pd.isna(row.get(name)) for name in required)):
        return None
    atr = float(row['atr14'])
    if not np.isfinite(atr) or atr <= 0.0:
        return None
    if abs(float(row['extension_atr'])) > 3.2 or float(row['range_atr']) > 4.25:
        return None
    close = float(row['close'])
    body = float(row['body_atr'])
    location = float(row['close_location'])
    extension = float(row['extension_atr'])
    momentum_z = float(row['robust_momentum_z60'])
    range_z = float(row['robust_range_z60'])
    adx = float(row['adx14'])
    kalman = float(row['kalman_slope_atr'])
    candidates: list[dict[str, Any]] = []
    local_hour = int(pd.Timestamp(frame.index[signal_i]).tz_convert(CENTRAL).hour)
    previous_vwap = float(previous.get('session_vwap', np.nan))
    current_vwap = float(row['session_vwap'])
    if _finite(previous_vwap) and float(previous['close']) <= previous_vwap and (close > current_vwap) and (body > 0.03) and (location > 0.52) and (float(row['yz_vol_ratio100']) >= 0.85) and (extension <= ADDON_LONG_MAX_EXTENSION_ATR) and (momentum_z >= ADDON_LONG_MIN_MOMENTUM_Z) and (local_hour in ADDON_LONG_ALLOWED_HOURS_CT):
        recent = frame.iloc[max(0, signal_i - 3):signal_i + 1]
        invalidation = min(float(recent['low'].min()), close - 0.55 * atr) - 0.04 * atr
        strength = abs(body) + max(0.0, (close - current_vwap) / atr)
        candidate = _addon_payload(frame, signal_i, 'ADDON_VWAP_IMPULSE_LONG', 'LONG', invalidation, strength, 0)
        if candidate is not None:
            candidates.append(candidate)
    prior_low6 = float(row['prior_low6'])
    if close < prior_low6 - 0.015 * atr and body < -0.1 and (location < 0.42) and (adx >= 14.0) and (kalman < 0.08) and (extension >= ADDON_SHORT_MIN_EXTENSION_ATR) and (range_z >= ADDON_SHORT_MIN_RANGE_Z) and (local_hour in ADDON_SHORT_ALLOWED_HOURS_CT):
        recent = frame.iloc[max(0, signal_i - 3):signal_i + 1]
        invalidation = float(recent['high'].max()) + 0.04 * atr
        strength = abs(body) + max(0.0, (prior_low6 - close) / atr)
        candidate = _addon_payload(frame, signal_i, 'ADDON_BREAK6_IMPULSE_SHORT', 'SHORT', invalidation, strength, 1)
        if candidate is not None:
            candidates.append(candidate)
    if not candidates:
        return None
    candidates.sort(key=lambda item: int(item['addon_priority']))
    return candidates[0]

def simulate_addon_trade(frame: pd.DataFrame, signal_i: int, signal: dict[str, Any], config: StrategyConfig) -> dict[str, Any] | None:
    entry_i = signal_i + 1
    if entry_i >= len(frame):
        return None
    direction = str(signal['direction'])
    entry_time = pd.Timestamp(frame.index[entry_i])
    entry = round_to_tick(float(frame.iloc[entry_i]['open']))
    atr = float(signal['atr'])
    raw_invalidation = float(signal['invalidation_price'])
    raw_distance = entry - raw_invalidation if direction == 'LONG' else raw_invalidation - entry
    stop_distance = max(raw_distance, ADDON_STOP_FLOOR_ATR * atr, MIN_STOP_POINTS)
    stop_distance = min(stop_distance, ADDON_STOP_CAP_ATR * atr, MAX_STOP_POINTS)
    if not MIN_STOP_POINTS <= stop_distance <= MAX_STOP_POINTS:
        return None
    initial_stop = direction_stop(direction, entry, stop_distance)
    stop_distance = round_to_tick(abs(entry - initial_stop))
    if not stop_is_valid(direction, entry, initial_stop):
        return None
    risk_budget = float(signal['risk_budget_dollars'])
    quantity = quantity_for_stop(stop_distance, risk_budget)
    if quantity <= 0:
        return None
    planned_risk = stop_distance * MGC_POINT_VALUE * quantity
    if planned_risk > risk_budget + 1e-06:
        raise AssertionError('ADDON risk exceeded its configured family ceiling.')
    target_r = float(signal['target_r_override'])
    max_hold_bars = int(signal['max_hold_bars_override'])
    target = direction_target(direction, entry, stop_distance, target_r)
    final_i = min(len(frame) - 1, entry_i + max_hold_bars - 1)
    final_exit_price = round_to_tick(float(frame.iloc[final_i]['close']))
    exit_reason = 'ADDON_TIME_EXIT'
    mfe_r = 0.0
    mae_r = 0.0
    for bar_i in range(entry_i, min(len(frame), entry_i + max_hold_bars)):
        bar = frame.iloc[bar_i]
        high = float(bar['high'])
        low = float(bar['low'])
        if direction == 'LONG':
            mfe_r = max(mfe_r, (high - entry) / stop_distance)
            mae_r = min(mae_r, (low - entry) / stop_distance)
            stop_hit = low <= initial_stop
            target_hit = high >= target
        else:
            mfe_r = max(mfe_r, (entry - low) / stop_distance)
            mae_r = min(mae_r, (entry - high) / stop_distance)
            stop_hit = high >= initial_stop
            target_hit = low <= target
        if stop_hit:
            final_i = bar_i
            final_exit_price = initial_stop
            exit_reason = 'ADDON_STOP'
            break
        if target_hit:
            final_i = bar_i
            final_exit_price = target
            exit_reason = 'ADDON_TARGET'
            break
    gross = gross_pnl(direction, entry, final_exit_price, quantity)
    costs = BASE_COST_PER_CONTRACT * quantity
    net = gross - costs
    return {'strategy': f'{config.event_rule.name}__V12_6_DUAL_EDGE_ADDON', 'event_family': signal['event_family'], 'event_rule': signal['event_rule'], 'strictness': signal['strictness'], 'direction': direction, 'signal_i': int(signal_i), 'entry_i': int(entry_i), 'exit_i': int(final_i), 'signal_time': pd.Timestamp(frame.index[signal_i]), 'entry_time': entry_time, 'exit_time': pd.Timestamp(frame.index[final_i]), 'segment_id': str(frame['segment_id'].iloc[0]), 'quality_score': float(signal['quality_score']), 'risk_tier': 'ADDON', 'risk_budget_dollars': risk_budget, 'opposite_score': 0.0, 'direction_margin': float(signal['direction_margin']), 'pattern_strength': float(signal['pattern_strength']), 'confirmation_strength': float(signal['confirmation_strength']), 'setup_age_bars': 1, 'target_space_r': float(signal['target_space_r']), 'adx': float(signal['adx']), 'volume_ratio': float(signal['volume_ratio']), 'kalman_slope_atr': float(signal['kalman_slope_atr']), 'kalman_innovation_z': float(signal['kalman_innovation_z']), 'directional_cusum': float(signal['directional_cusum']), 'variance_ratio4': float(signal['variance_ratio4']), 'variance_ratio12': float(signal['variance_ratio12']), 'yz_vol_ratio100': float(signal['yz_vol_ratio100']), 'robust_volume_z60': float(signal['robust_volume_z60']), 'robust_momentum_z60': float(signal['robust_momentum_z60']), 'fvg_size_atr': float(signal['fvg_size_atr']), 'trend_aligned': bool(signal['trend_aligned']), 'supportive_trend': bool(signal['supportive_trend']), 'entry_price': float(entry), 'invalidation_price': float(initial_stop), 'failure_level': float(initial_stop), 'initial_stop': float(initial_stop), 'last_working_stop': float(initial_stop), 'stop_orientation_valid': True, 'stop_distance': float(stop_distance), 'tp1': float(target), 'tp2': float(target), 'tp1_r': target_r, 'tp2_r': target_r, 'quantity': int(quantity), 'tp1_quantity': int(quantity), 'tp2_quantity': 0, 'planned_risk_dollars': float(planned_risk), 'gross_pnl': float(gross), 'costs': float(costs), 'net_pnl': float(net), 'exit_reason': exit_reason, 'mfe_r': float(mfe_r), 'mae_r': float(mae_r), 'final_exit_price': float(final_exit_price)}

def choose_event(frame: pd.DataFrame, signal_i: int, rule: EventRule) -> dict[str, Any] | None:
    segment_id = str(frame['segment_id'].iloc[0]) if 'segment_id' in frame else 'SEGMENT'
    timestamp_key = int(pd.Timestamp(frame.index[signal_i]).value)
    cache_key = (segment_id, rule.name, timestamp_key)
    if cache_key in _EVENT_CACHE:
        cached = _EVENT_CACHE[cache_key]
        return None if cached is None else dict(cached)
    long_event = detect_direction_event(frame, signal_i, 'LONG', rule)
    short_event = detect_direction_event(frame, signal_i, 'SHORT', rule)
    if long_event is None and short_event is None:
        if len(_EVENT_CACHE) >= _EVENT_CACHE_LIMIT:
            _EVENT_CACHE.clear()
        _EVENT_CACHE[cache_key] = None
        return None
    if long_event is None:
        winner = short_event
        opposite_score = 0.0
    elif short_event is None:
        winner = long_event
        opposite_score = 0.0
    elif float(long_event['quality_score']) >= float(short_event['quality_score']):
        winner = long_event
        opposite_score = float(short_event['quality_score'])
    else:
        winner = short_event
        opposite_score = float(long_event['quality_score'])
    assert winner is not None
    margin = float(winner['quality_score']) - opposite_score
    if margin < rule.min_direction_margin:
        _audit(rule, 'direction_margin')
        result = None
    elif str(winner.get('event_family')) == 'VWAP_TREND_RECLAIM_CONFIRMED' and float(winner.get('variance_ratio4', 99.0)) > CORE_MAX_VARIANCE_RATIO4:
        _audit(rule, 'core_variance_regime')
        result = None
    else:
        result = dict(winner)
        result['opposite_score'] = opposite_score
        result['direction_margin'] = margin
        _audit(rule, 'signals_accepted')
    if len(_EVENT_CACHE) >= _EVENT_CACHE_LIMIT:
        _EVENT_CACHE.clear()
    _EVENT_CACHE[cache_key] = None if result is None else dict(result)
    return None if result is None else dict(result)

def simulate_trade(frame: pd.DataFrame, signal_i: int, signal: dict[str, Any], config: StrategyConfig) -> dict[str, Any] | None:
    entry_i = signal_i + 1
    if entry_i >= len(frame):
        return None
    direction = str(signal['direction'])
    entry_time = pd.Timestamp(frame.index[entry_i])
    if not entry_session_open(entry_time) or friday_entry_block(entry_time):
        return None
    entry = round_to_tick(float(frame.iloc[entry_i]['open']))
    signal_close = float(signal['signal_close'])
    atr = float(signal['atr'])
    if abs(entry - signal_close) > config.event_rule.max_entry_gap_atr * atr:
        _audit(config.event_rule, 'entry_gap')
        return None
    raw_invalidation = float(signal['invalidation_price'])
    if direction == 'LONG':
        initial_stop = min(raw_invalidation, entry - config.event_rule.stop_atr_floor * atr)
    else:
        initial_stop = max(raw_invalidation, entry + config.event_rule.stop_atr_floor * atr)
    initial_stop = round_to_tick(initial_stop)
    if not stop_is_valid(direction, entry, initial_stop):
        return None
    stop_distance = round_to_tick(abs(entry - initial_stop))
    if not MIN_STOP_POINTS <= stop_distance <= MAX_STOP_POINTS:
        return None
    risk_budget = min(MAX_PLANNED_RISK_DOLLARS, float(signal.get('risk_budget_dollars', MAX_PLANNED_RISK_DOLLARS)))
    quantity = quantity_for_stop(stop_distance, risk_budget)
    if quantity <= 0:
        return None
    planned_risk = stop_distance * MGC_POINT_VALUE * quantity
    if planned_risk > risk_budget + 1e-06:
        raise AssertionError('Planned risk exceeded the signal tier budget.')
    profile = config.exit_profile
    tp1 = direction_target(direction, entry, stop_distance, profile.tp1_r)
    tp2 = direction_target(direction, entry, stop_distance, profile.tp2_r)
    if abs(tp1 - entry) + 1e-09 < 0.75 * stop_distance:
        raise AssertionError('TP1 is below the minimum allowed reward multiple.')
    if abs(tp2 - entry) + 1e-09 < abs(tp1 - entry):
        raise AssertionError('TP2 is closer than TP1.')
    tp1_quantity, tp2_quantity = split_quantity(quantity, profile.partial_fraction, profile.single_target)
    remaining = quantity
    working_stop = initial_stop
    tp1_filled = False
    gross = 0.0
    mfe_r = 0.0
    mae_r = 0.0
    final_exit_price = entry
    exit_reason = 'MAX_HOLD_CLOSE'
    final_i = min(len(frame) - 1, entry_i + profile.max_hold_bars)
    failure_level = float(signal['failure_level'])
    for bar_i in range(entry_i, final_i + 1):
        bar = frame.iloc[bar_i]
        high = float(bar['high'])
        low = float(bar['low'])
        close = round_to_tick(float(bar['close']))
        if direction == 'LONG':
            favorable_r = (high - entry) / stop_distance
            adverse_r = (low - entry) / stop_distance
            close_r = (close - entry) / stop_distance
            stop_hit = low <= working_stop
            tp1_hit = high >= tp1
            tp2_hit = high >= tp2
            structure_failed = close <= failure_level
        else:
            favorable_r = (entry - low) / stop_distance
            adverse_r = (entry - high) / stop_distance
            close_r = (entry - close) / stop_distance
            stop_hit = high >= working_stop
            tp1_hit = low <= tp1
            tp2_hit = low <= tp2
            structure_failed = close >= failure_level
        mfe_r = max(mfe_r, favorable_r)
        mae_r = min(mae_r, adverse_r)
        if stop_hit:
            gross += gross_pnl(direction, entry, working_stop, remaining)
            remaining = 0
            final_exit_price = working_stop
            final_i = bar_i
            exit_reason = 'POST_TP1_STOP' if tp1_filled else 'INITIAL_STOP'
            break
        if not tp1_filled and tp1_hit:
            first_fill = min(tp1_quantity, remaining)
            gross += gross_pnl(direction, entry, tp1, first_fill)
            remaining -= first_fill
            tp1_filled = True
            final_exit_price = tp1
            if remaining <= 0:
                final_i = bar_i
                exit_reason = 'SINGLE_TARGET'
                break
            if tp2_hit:
                gross += gross_pnl(direction, entry, tp2, remaining)
                remaining = 0
                final_exit_price = tp2
                final_i = bar_i
                exit_reason = 'SECOND_TARGET'
                break
            entry_revisited = low <= entry if direction == 'LONG' else high >= entry
            if entry_revisited:
                gross += gross_pnl(direction, entry, entry, remaining)
                remaining = 0
                final_exit_price = entry
                final_i = bar_i
                exit_reason = 'TP1_THEN_SAME_BAR_BREAK_EVEN'
                break
            working_stop = direction_target(direction, entry, stop_distance, profile.post_tp1_stop_r)
        elif tp1_filled and remaining > 0 and tp2_hit:
            gross += gross_pnl(direction, entry, tp2, remaining)
            remaining = 0
            final_exit_price = tp2
            final_i = bar_i
            exit_reason = 'SECOND_TARGET'
            break
        bars_held = bar_i - entry_i + 1
        if remaining > 0 and (not tp1_filled) and (bars_held >= 2) and structure_failed:
            gross += gross_pnl(direction, entry, close, remaining)
            remaining = 0
            final_exit_price = close
            final_i = bar_i
            exit_reason = 'PATTERN_FAILURE_EXIT'
            break
        if remaining > 0 and (not tp1_filled) and (bars_held >= 2) and (mfe_r >= profile.giveback_trigger_r) and (close_r <= profile.giveback_floor_r):
            gross += gross_pnl(direction, entry, close, remaining)
            remaining = 0
            final_exit_price = close
            final_i = bar_i
            exit_reason = 'MFE_GIVEBACK_EXIT'
            break
        if remaining > 0 and (not tp1_filled) and (bars_held >= profile.no_progress_bars) and (mfe_r < profile.no_progress_min_mfe_r):
            gross += gross_pnl(direction, entry, close, remaining)
            remaining = 0
            final_exit_price = close
            final_i = bar_i
            exit_reason = 'NO_PROGRESS_EXIT'
            break
        if remaining > 0 and tp1_filled and (favorable_r >= profile.trail_after_r):
            recent = frame.iloc[max(entry_i, bar_i - profile.trail_lookback + 1):bar_i + 1]
            bar_atr = float(bar.get('atr14', atr))
            if direction == 'LONG':
                candidate_stop = round_to_tick(float(recent['low'].min()) - 0.08 * bar_atr)
                if candidate_stop > working_stop and candidate_stop < close:
                    working_stop = candidate_stop
            else:
                candidate_stop = round_to_tick(float(recent['high'].max()) + 0.08 * bar_atr)
                if candidate_stop < working_stop and candidate_stop > close:
                    working_stop = candidate_stop
    if remaining > 0:
        close = round_to_tick(float(frame.iloc[final_i]['close']))
        gross += gross_pnl(direction, entry, close, remaining)
        final_exit_price = close
        exit_reason = 'MAX_HOLD_CLOSE'
    costs = BASE_COST_PER_CONTRACT * quantity
    net = gross - costs
    return {'strategy': config.name, 'event_family': signal['event_family'], 'event_rule': signal['event_rule'], 'strictness': signal['strictness'], 'direction': direction, 'signal_i': int(signal_i), 'entry_i': int(entry_i), 'exit_i': int(final_i), 'signal_time': pd.Timestamp(frame.index[signal_i]), 'entry_time': entry_time, 'exit_time': pd.Timestamp(frame.index[final_i]), 'segment_id': str(frame['segment_id'].iloc[0]), 'quality_score': float(signal['quality_score']), 'risk_tier': str(signal.get('risk_tier', 'CORE')), 'risk_budget_dollars': float(signal.get('risk_budget_dollars', MAX_PLANNED_RISK_DOLLARS)), 'opposite_score': float(signal['opposite_score']), 'direction_margin': float(signal['direction_margin']), 'pattern_strength': float(signal['pattern_strength']), 'confirmation_strength': float(signal.get('confirmation_strength', 0.0)), 'setup_age_bars': int(signal.get('setup_age_bars', 0)), 'target_space_r': float(signal['target_space_r']), 'adx': float(signal['adx']), 'volume_ratio': float(signal['volume_ratio']), 'kalman_slope_atr': signal.get('kalman_slope_atr', 0.0), 'kalman_innovation_z': signal.get('kalman_innovation_z', 0.0), 'directional_cusum': signal.get('directional_cusum', 0.0), 'variance_ratio4': signal.get('variance_ratio4', 0.0), 'variance_ratio12': signal.get('variance_ratio12', 0.0), 'yz_vol_ratio100': signal.get('yz_vol_ratio100', 0.0), 'robust_volume_z60': signal.get('robust_volume_z60', 0.0), 'robust_momentum_z60': signal.get('robust_momentum_z60', 0.0), 'fvg_size_atr': signal.get('fvg_size_atr', 0.0), 'trend_aligned': bool(signal['trend_aligned']), 'supportive_trend': bool(signal['supportive_trend']), 'entry_price': float(entry), 'invalidation_price': float(signal['invalidation_price']), 'failure_level': float(failure_level), 'initial_stop': float(initial_stop), 'last_working_stop': float(working_stop), 'stop_orientation_valid': bool(stop_is_valid(direction, entry, initial_stop)), 'stop_distance': float(stop_distance), 'tp1': float(tp1), 'tp2': float(tp2), 'tp1_r': float(profile.tp1_r), 'tp2_r': float(profile.tp2_r), 'quantity': int(quantity), 'tp1_quantity': int(tp1_quantity), 'tp2_quantity': int(tp2_quantity), 'planned_risk_dollars': float(planned_risk), 'gross_pnl': float(gross), 'costs': float(costs), 'net_pnl': float(net), 'exit_reason': exit_reason, 'mfe_r': float(mfe_r), 'mae_r': float(mae_r), 'final_exit_price': float(final_exit_price)}

def resize_trade_contracts(trade: dict[str, Any], contract_cap: int) -> dict[str, Any]:
    """Reduce quantity without changing the already-known price path."""
    old_quantity = int(trade.get('quantity', 0))
    new_quantity = min(old_quantity, max(0, int(contract_cap)))
    if old_quantity <= 0 or new_quantity >= old_quantity:
        return trade
    out = dict(trade)
    ratio = new_quantity / old_quantity
    out['quantity'] = new_quantity
    old_tp2 = int(out.get('tp2_quantity', 0))
    if old_tp2 > 0:
        partial_fraction = float(out.get('tp1_quantity', 0)) / old_quantity
        q1, q2 = split_quantity(new_quantity, partial_fraction, False)
    else:
        q1, q2 = (new_quantity, 0)
    out['tp1_quantity'] = q1
    out['tp2_quantity'] = q2
    out['gross_pnl'] = float(out.get('gross_pnl', 0.0)) * ratio
    out['costs'] = BASE_COST_PER_CONTRACT * new_quantity
    out['net_pnl'] = out['gross_pnl'] - out['costs']
    out['planned_risk_dollars'] = float(out.get('stop_distance', 0.0)) * MGC_POINT_VALUE * new_quantity
    return out

def run_strategy(segments: list[pd.DataFrame], config: StrategyConfig, allowed_dates: set[Any]) -> pd.DataFrame:
    trades: list[dict[str, Any]] = []
    daily_trades: dict[Any, int] = {}
    daily_pnl: dict[Any, float] = {}
    last_exit_time: pd.Timestamp | None = None
    closed_balance = START_BALANCE
    buffer_unlocked = closed_balance >= BUFFER_UNLOCK_BALANCE
    for frame in segments:
        active_until_i = -1
        for signal_i in range(220, len(frame) - 2):
            signal_time = pd.Timestamp(frame.index[signal_i])
            entry_time = pd.Timestamp(frame.index[signal_i + 1])
            entry_date = entry_time.tz_convert(CENTRAL).date()
            if entry_date not in allowed_dates:
                continue
            _audit(config.event_rule, 'bars_checked')
            if signal_i + 1 <= active_until_i:
                continue
            if not entry_session_open(entry_time):
                continue
            if friday_entry_block(entry_time):
                continue
            if daily_trades.get(entry_date, 0) >= MAX_TRADES_PER_CT_DATE:
                _audit(config.event_rule, 'daily_trade_cap')
                continue
            effective_daily_loss_limit = POST_BUFFER_DAILY_LOSS_DOLLARS if buffer_unlocked else PRE_BUFFER_DAILY_LOSS_DOLLARS
            if daily_pnl.get(entry_date, 0.0) <= -effective_daily_loss_limit:
                _audit(config.event_rule, 'daily_loss_cap')
                continue
            if last_exit_time is not None and entry_time - last_exit_time < pd.Timedelta(minutes=MIN_MINUTES_BETWEEN_TRADES):
                _audit(config.event_rule, 'cooldown')
                continue
            signal = choose_event(frame, signal_i, config.event_rule)
            trade = None
            if signal is not None:
                trade = simulate_trade(frame, signal_i, signal, config)
            if trade is None:
                signal = detect_scalp_event(frame, signal_i)
                if signal is not None:
                    trade = simulate_scalp_trade(frame, signal_i, signal, config)
            if trade is None:
                signal = detect_probe_event(frame, signal_i)
                if signal is not None:
                    trade = simulate_probe_trade(frame, signal_i, signal, config)
            if trade is None and daily_trades.get(entry_date, 0) < ADDON_DAILY_FILL_TARGET:
                signal = detect_addon_event(frame, signal_i)
                if signal is not None:
                    trade = simulate_addon_trade(frame, signal_i, signal, config)
            if trade is None:
                continue
            if not buffer_unlocked:
                trade = resize_trade_contracts(trade, PRE_BUFFER_MAX_CONTRACTS)
            trade['buffer_unlocked_at_entry'] = bool(buffer_unlocked)
            trade['effective_daily_loss_limit'] = float(effective_daily_loss_limit)
            planned_risk = float(trade.get('planned_risk_dollars', 0.0))
            projected_worst_case = daily_pnl.get(entry_date, 0.0) - planned_risk
            if projected_worst_case < -effective_daily_loss_limit - 1e-06:
                _audit(config.event_rule, 'daily_risk_capacity')
                continue
            trades.append(trade)
            _audit(config.event_rule, 'trades_executed')
            active_until_i = int(trade['exit_i'])
            last_exit_time = pd.Timestamp(trade['exit_time'])
            daily_trades[entry_date] = daily_trades.get(entry_date, 0) + 1
            daily_pnl[entry_date] = daily_pnl.get(entry_date, 0.0) + float(trade['net_pnl'])
            closed_balance += float(trade['net_pnl'])
            if not buffer_unlocked and closed_balance >= BUFFER_UNLOCK_BALANCE:
                buffer_unlocked = True
    if not trades:
        return pd.DataFrame()
    return pd.DataFrame(trades).sort_values('entry_time').reset_index(drop=True)
