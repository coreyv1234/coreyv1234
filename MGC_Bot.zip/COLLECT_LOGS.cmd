@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0COLLECT_LOGS.ps1" 
pause
