from __future__ import annotations

import math
from collections import Counter
from dataclasses import asdict, dataclass, replace
from datetime import datetime

from .market import Bar, CT, INSTRUMENTS, MINUTE
from .strategy import Signal, SignalEngine, StrategyConfig
from .statistics import day_block_bootstrap
from .decisions import EntryContext


@dataclass(frozen=True)
class RiskConfig:
    starting_balance: float = 50_000
    max_drawdown: float = 2000
    daily_loss_limit: float = 900
    max_contracts: int = 4
    risk_per_trade: float = 250
    drawdown_reserve: float = 50
    commission_round_trip: float = 6.0  # Placeholder; replace with actual GC all-in fees.
    slippage_ticks_per_side: int = 1
    target_trade_through_ticks: int = 1
    entry_start_ct: int = 7 * 60 + 20
    entry_end_ct: int = 12 * 60
    flatten_ct: int = 15 * 60 + 55
    max_trades_per_session: int = 6
    daily_profit_target: float | None = None  # Stop new entries after realized session PnL reaches this.
    account_trailing_mode: str = 'end_of_day'
    trailing_highwater_cap: float | None = 52_000

    def __post_init__(self):
        for name in ("starting_balance", "max_drawdown", "daily_loss_limit", "risk_per_trade"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be positive and finite")
        if not 0 <= self.drawdown_reserve < self.max_drawdown:
            raise ValueError("reserve must be nonnegative and below maximum drawdown")
        if self.drawdown_reserve >= self.daily_loss_limit:
            raise ValueError("reserve must be below daily loss limit")
        if not math.isfinite(self.commission_round_trip) or self.commission_round_trip < 0:
            raise ValueError("commission must be finite and nonnegative")
        for name in ("max_contracts", "max_trades_per_session"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f"{name} must be a positive integer")
        for name in ("slippage_ticks_per_side", "target_trade_through_ticks"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"{name} must be a nonnegative integer")
        if not 0 <= self.entry_start_ct < self.entry_end_ct <= self.flatten_ct < 17 * 60:
            raise ValueError("entry and flatten windows must end before the 16:00 CT maintenance break")
        if self.daily_profit_target is not None and (not math.isfinite(self.daily_profit_target) or self.daily_profit_target <= 0):
            raise ValueError('daily profit target must be positive and finite')
        if self.account_trailing_mode not in {'minute_close', 'end_of_day'}:
            raise ValueError('unknown account trailing mode')
        if self.trailing_highwater_cap is not None and (
                not math.isfinite(self.trailing_highwater_cap) or self.trailing_highwater_cap < self.starting_balance):
            raise ValueError('trailing high-water cap must be finite and at least starting balance')


@dataclass
class Position:
    signal: Signal
    entry_time: datetime
    entry: float
    stop: float
    target: float
    quantity: int
    planned_risk: float
    bars_held: int = 0


@dataclass(frozen=True)
class Trade:
    session: str
    instrument: str
    family: str
    direction: int
    signal_time: str
    entry_time: str
    exit_time: str
    entry: float
    exit: float
    stop: float
    target: float
    quantity: int
    planned_risk: float
    gross_pnl: float
    fees: float
    net_pnl: float
    reason: str
    ambiguous_bar: bool


class Backtest:
    """Closed-bar research only. No ATI, brokerage API or live order submission."""

    def __init__(self, root: str, strategy: StrategyConfig, risk: RiskConfig, entry_policy=None, target_policy=None):
        self.instrument = INSTRUMENTS[root]
        self.strategy_config, self.risk = strategy, risk
        self.engine = SignalEngine(strategy)
        self.balance = self.peak = risk.starting_balance
        self.session_open = self.balance
        self.session: str | None = None
        self.position: Position | None = None
        self.pending: Signal | None = None
        self.previous: Bar | None = None
        self.halted = self.daily_halted = False
        self.trades: list[Trade] = []
        self.signals: list[Signal] = []
        self.rejections: Counter = Counter()
        self.session_count = 0
        self.max_marked_drawdown = 0.0
        self.max_adverse_drawdown = 0.0
        self.active_sessions: set[str] = set()
        self.equity_curve: list[tuple[str, float]] = []
        self.entry_policy = entry_policy
        self.pending_features = None
        self.pending_history = ()
        self.last_entry_context = None
        self.entry_decisions = []
        self.target_policy = target_policy
        self.target_decisions = []
        self.profit_locked_sessions = set()
        self.trailing_peak = risk.starting_balance
        self.max_account_trailing_drawdown = 0.
        self.account_floors_by_session = {}

    def account_stop_floor(self):
        return self.trailing_peak-self.risk.max_drawdown+self.risk.drawdown_reserve

    def advance_trailing_peak(self, value):
        self.trailing_peak = max(self.trailing_peak, value)
        if self.risk.trailing_highwater_cap is not None:
            self.trailing_peak = min(self.trailing_peak, self.risk.trailing_highwater_cap)

    def finish_session(self):
        if self.session is None:
            return
        if self.risk.account_trailing_mode == 'end_of_day':
            self.advance_trailing_peak(self.balance)
        self.account_floors_by_session[self.session] = self.account_stop_floor()

    def risk_budget(self) -> float:
        r = self.risk
        return max(0.0, min(r.risk_per_trade,
                           self.balance - self.account_stop_floor(),
                           self.balance - (self.session_open - r.daily_loss_limit + r.drawdown_reserve)))

    def open_position(self, signal: Signal, bar: Bar) -> Position | None:
        c, r, inst = self.strategy_config, self.risk, self.instrument
        if signal.time != bar.time - MINUTE or signal.instrument != bar.instrument:
            self.rejections["stale_or_wrong_contract_signal"] += 1
            return None
        if abs(bar.open - signal.reference) > c.max_gap_atr * signal.atr:
            self.rejections["entry_gap"] += 1
            return None
        slip = r.slippage_ticks_per_side * inst.tick_size
        direction = signal.direction
        entry = inst.price(bar.open + direction * slip, up=direction == 1)
        stop = inst.price(signal.stop, up=direction == -1)
        distance = direction * (entry - stop)
        if distance < inst.tick_size - 1e-8:
            self.rejections["invalid_stop_after_gap"] += 1
            return None
        per_contract = (distance + slip) * inst.point_value + r.commission_round_trip
        quantity = min(r.max_contracts, int((self.risk_budget() + 1e-8) // per_contract))
        if quantity <= 0:
            self.rejections["risk_budget_cannot_fit_one_contract"] += 1
            return None
        target = inst.price(entry + direction * distance * c.target_r, up=direction == 1)
        history = self.pending_history
        context = EntryContext(signal, bar.time-MINUTE, entry, stop, target, quantity,
                               per_contract*quantity, r.commission_round_trip, slip,
                               self.pending_features,
                               max(b.high for b in history[-12:]) if len(history)>=12 else None,
                               min(b.low for b in history[-12:]) if len(history)>=12 else None,
                               history[-4].close if len(history)>=4 else None)
        self.last_entry_context = context
        if self.target_policy is not None:
            target_decision = self.target_policy(context)
            self.target_decisions.append({'signal_time': signal.time.isoformat(),
                'entry_time': context.entry_time.isoformat(), 'direction': direction,
                'quantity': quantity, 'entry': entry, 'stop': stop,
                'planned_risk': context.planned_risk, **asdict(target_decision)})
            if not target_decision.accepted:
                self.rejections[target_decision.reason] += 1
                return None
            target = target_decision.target
            if target is None or not math.isfinite(target) or direction*(target-entry) <= 0:
                raise ValueError('target policy returned invalid target')
            context = replace(context, target=target)
            self.last_entry_context = context
        if self.entry_policy is not None:
            decision = self.entry_policy(context)
            self.entry_decisions.append({"signal_time": signal.time.isoformat(),
                "entry_time": context.entry_time.isoformat(), "direction": signal.direction,
                "entry": entry, "stop": stop, "quantity": quantity,
                "planned_risk": context.planned_risk, **asdict(decision)})
            if not decision.accepted:
                self.rejections[decision.reason] += 1
                return None
        self.session_count += 1
        return Position(signal, bar.time - MINUTE, entry, stop, target, quantity, per_contract * quantity)

    def close_position(self, raw_price: float, stamp: datetime, reason: str, *, limit=False, ambiguous=False):
        p, inst, r = self.position, self.instrument, self.risk
        if p is None:
            raise RuntimeError("no position to close")
        d = p.signal.direction
        price = raw_price if limit else inst.price(raw_price - d * r.slippage_ticks_per_side * inst.tick_size, up=d == -1)
        gross = (price - p.entry) * d * inst.point_value * p.quantity
        fees = r.commission_round_trip * p.quantity
        net = gross - fees
        self.balance += net
        self.trades.append(Trade(p.signal.time.astimezone(CT).date().isoformat(), p.signal.instrument,
                                 p.signal.family, d, p.signal.time.isoformat(), p.entry_time.isoformat(),
                                 stamp.isoformat(), p.entry, price, p.stop, p.target, p.quantity,
                                 p.planned_risk, gross, fees, net, reason, ambiguous))
        self.position = None
        self.check_equity(self.balance)

    def check_equity(self, equity: float):
        self.peak = max(self.peak, equity)
        if self.risk.account_trailing_mode == 'minute_close':
            self.advance_trailing_peak(equity)
        self.max_marked_drawdown = max(self.max_marked_drawdown, self.peak - equity)
        self.max_account_trailing_drawdown = max(self.max_account_trailing_drawdown, self.trailing_peak-equity)
        if equity <= self.account_stop_floor() + 1e-8:
            self.halted = True
        if equity <= self.session_open - self.risk.daily_loss_limit + self.risk.drawdown_reserve + 1e-8:
            self.daily_halted = True

    def manage(self, bar: Bar):
        p, inst, r = self.position, self.instrument, self.risk
        if p is None:
            return
        p.bars_held += 1
        d = p.signal.direction
        low_equity = self.balance + ((bar.low if d == 1 else bar.high) - p.entry) * d * inst.point_value * p.quantity
        low_equity -= (r.commission_round_trip + r.slippage_ticks_per_side * inst.tick_size * inst.point_value) * p.quantity
        self.max_adverse_drawdown = max(self.max_adverse_drawdown, self.peak - low_equity)
        # A risk floor supplements the original stop; it never widens a stop.
        floor = max(self.account_stop_floor(),
                    self.session_open - r.daily_loss_limit + r.drawdown_reserve)
        fees_and_exit_slip = (r.commission_round_trip + r.slippage_ticks_per_side * inst.tick_size * inst.point_value) * p.quantity
        max_loss_points = max(0.0, self.balance - floor - fees_and_exit_slip) / (inst.point_value * p.quantity)
        risk_stop = inst.price(p.entry - d * max_loss_points, up=d == 1)
        stop = max(p.stop, risk_stop) if d == 1 else min(p.stop, risk_stop)
        risk_tightened = d * (stop - p.stop) > 1e-8
        stop_hit = bar.low <= stop if d == 1 else bar.high >= stop
        through = r.target_trade_through_ticks * inst.tick_size
        target_hit = bar.high >= p.target + through if d == 1 else bar.low <= p.target - through
        # Opening gaps have known ordering: the open occurs before the rest of a bar.
        stop_gap = bar.open <= stop if d == 1 else bar.open >= stop
        target_gap = bar.open >= p.target + through if d == 1 else bar.open <= p.target - through
        if stop_gap:
            self.close_position(bar.open, bar.time - MINUTE, "RISK_GAP" if risk_tightened else "STOP_GAP")
        elif target_gap:
            self.close_position(p.target, bar.time - MINUTE, "TARGET_GAP", limit=True)
        elif stop_hit:
            self.close_position(stop, bar.time, "RISK_STOP" if risk_tightened else "STOP", ambiguous=target_hit)
        elif target_hit:
            self.close_position(p.target, bar.time, "TARGET", limit=True)
        else:
            local = bar.time.astimezone(CT)
            if local.hour * 60 + local.minute >= r.flatten_ct:
                self.close_position(bar.close, bar.time, "SESSION_FLAT")
            elif p.bars_held >= self.strategy_config.max_hold_minutes:
                self.close_position(bar.close, bar.time, "TIME_EXIT")

    def run(self, bars: list[Bar], start: str | None = None, end: str | None = None) -> dict:
        if self.previous is not None:
            raise RuntimeError("Backtest instances are single-use")
        for bar in bars:
            selected = (start is None or bar.session >= start) and (end is None or bar.session < end)
            discontinuity = self.previous and (bar.time - self.previous.time != MINUTE or bar.instrument != self.previous.instrument or bar.session != self.previous.session)
            if self.position and (discontinuity or not selected):
                # Gaps/rolls cannot be simulated without ticks. End the previous
                # contiguous segment at its final close and flag this assumption.
                self.close_position(self.previous.close, self.previous.time, "SEGMENT_END")
            if bar.session != self.session:
                self.finish_session()
                self.session, self.session_open = bar.session, self.balance
                self.daily_halted, self.session_count = False, 0
            if selected:
                self.active_sessions.add(bar.session)
                local_open = (bar.time - MINUTE).astimezone(CT)
                minute = local_open.hour * 60 + local_open.minute
                profit_locked = (bar.session in self.profit_locked_sessions or
                                 (self.risk.daily_profit_target is not None and
                                  self.balance-self.session_open >= self.risk.daily_profit_target-1e-8))
                if profit_locked:
                    self.profit_locked_sessions.add(bar.session)
                eligible = (not self.halted and not self.daily_halted and self.position is None
                            and not profit_locked
                            and local_open.weekday() < 5 and self.risk.entry_start_ct <= minute < self.risk.entry_end_ct
                            and self.session_count < self.risk.max_trades_per_session)
                if self.pending and not discontinuity and eligible:
                    self.position = self.open_position(self.pending, bar)
                self.manage(bar)
                equity = self.balance
                if self.position:
                    p = self.position
                    equity += (bar.close - p.entry) * p.signal.direction * self.instrument.point_value * p.quantity
                    equity -= (self.risk.commission_round_trip + self.risk.slippage_ticks_per_side * self.instrument.tick_size * self.instrument.point_value) * p.quantity
                self.check_equity(equity)
                self.equity_curve.append((bar.time.isoformat(), equity))
            if self.target_policy is not None:
                self.target_policy.on_bar(bar)
            signal = self.engine.on_bar(bar)
            if signal and selected:
                self.signals.append(signal)
            self.pending = signal if selected else None
            self.pending_features = getattr(self.engine, "last_features", None) if self.pending else None
            self.pending_history = tuple(getattr(self.engine, "history", ())) if self.pending else ()
            self.previous = bar
        if self.position:
            self.close_position(bars[-1].close, bars[-1].time, "DATA_END")
            self.equity_curve.append((bars[-1].time.isoformat(), self.balance))
        if bars:
            last = bars[-1].time.astimezone(CT)
            # No further entries/positions are permitted after our flatten time;
            # the modeled closing balance is then fixed for this session.
            if last.hour*60+last.minute >= self.risk.flatten_ct:
                self.finish_session()
        return self.report()

    def report(self) -> dict:
        pnls = [t.net_pnl for t in self.trades]
        daily = {s: 0.0 for s in sorted(self.active_sessions)}
        for t in self.trades:
            daily[t.session] = daily.get(t.session, 0.0) + t.net_pnl
        wins = sum(x > 0 for x in pnls)
        losses = sum(x < 0 for x in pnls)
        positive, negative = sum(x for x in pnls if x > 0), -sum(x for x in pnls if x < 0)
        traded_sessions = {t.session for t in self.trades}
        current_streak = longest_streak = 0
        for pnl in pnls:
            current_streak = current_streak + 1 if pnl < 0 else 0
            longest_streak = max(longest_streak, current_streak)
        n = len(pnls)
        # Wilson 95% interval for win rate, not a probability of profitability.
        z = 1.959963984540054
        if n:
            rate = wins / n
            center = (rate + z*z/(2*n)) / (1+z*z/n)
            half = z * math.sqrt(rate*(1-rate)/n + z*z/(4*n*n)) / (1+z*z/n)
            interval = [center - half, center + half]
        else:
            interval = None
        return {
            "mode": "RESEARCH_ONLY", "trades": n, "wins": wins, "losses": losses,
            "net_profit": self.balance - self.risk.starting_balance,
            "profit_factor": positive / negative if negative else None,
            "average_net_winner": positive / wins if wins else None,
            "average_net_loser": -negative / losses if losses else None,
            "payoff_ratio": (positive / wins) / (negative / losses) if wins and losses else None,
            "longest_losing_streak": longest_streak,
            "expectancy_per_trade": sum(pnls) / n if n else None,
            "win_rate": wins / n if n else None, "win_rate_wilson_95": interval,
            "max_marked_drawdown": self.max_marked_drawdown,
            "max_adverse_bar_drawdown_bound": self.max_adverse_drawdown,
            "max_account_trailing_drawdown": self.max_account_trailing_drawdown,
            "account_trailing_highwater": self.trailing_peak,
            "account_loss_floor_before_reserve": self.trailing_peak-self.risk.max_drawdown,
            "research_account_stop_floor": self.account_stop_floor(),
            "drawdown_halt": self.halted, "signals": len(self.signals),
            "rejections": dict(self.rejections), "daily_pnl": daily,
            "sessions": len(daily), "no_trade_sessions": sum(s not in traded_sessions for s in daily),
            "profitable_sessions": sum(x > 0 for x in daily.values()),
            "losing_sessions": sum(x < 0 for x in daily.values()),
            "mean_per_observed_session": sum(daily.values()) / len(daily) if daily else None,
            "sessions_net_at_least_500": sum(x >= 500 for x in daily.values()),
            "sessions_net_at_least_1000": sum(x >= 1000 for x in daily.values()),
            "worst_observed_session": min(daily.values()) if daily else None,
            "daily_block_bootstrap": day_block_bootstrap(list(daily.values())),
            "ambiguous_bars": sum(t.ambiguous_bar for t in self.trades),
            "segment_end_exits": sum(t.reason == "SEGMENT_END" for t in self.trades),
            "profit_locked_sessions": len(self.profit_locked_sessions),
            "strategy": asdict(self.strategy_config), "risk": asdict(self.risk),
            "limitations": [
                "Minute OHLCV cannot establish tick ordering, queue position, spread, or intrabar equity peaks.",
                "Stops win ambiguous bars; target limits require trade-through; gaps fill adversely.",
                "Segment-end liquidation assumes advance flattening at a data gap; investigate these exits before relying on performance.",
                "Drawdown uses closed trades and minute closes; adverse-bar bound is diagnostic, not actual broker intrabar drawdown.",
                "Loss limits are modeled controls, not guaranteed fill prices or certified Tradeify rules.",
                "Positive observed performance is not evidence of daily guaranteed profit.",
            ],
        }
