"""Shared current-model decisions with native fills only; Sim101 adapter."""
from dataclasses import replace
from .backtest import Position
from .market import MINUTE
from .scaleout import ScaleState
from .strategy import Signal
from .mgc_red_context_quality import RedContextQualityMgc
from .mgc_sim_execution import BridgeError,healthy_state,command


class LiveResearchPlanner(RedContextQualityMgc):
    """Use the research state machine; never run its hypothetical fill engine."""
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.native_busy=False
        self.sent_sources=set()
        self.native_signal=None
        self.native_entry_time=None

    def manage(self,bar):
        return  # Native brackets and execution callbacks own every fill.

    def check_equity(self,equity):
        return  # Native marked liquidation and persisted ledger own halts.

    def close_position(self,*args,**kwargs):
        raise BridgeError('Research attempted a synthetic close; native reconciliation required')

    def finish(self):
        raise BridgeError('Live planner cannot finalize hypothetical trades')

    def _eligible_source(self,bar):
        return not self.native_busy and super()._eligible_source(bar)

    def fill_limit(self,bar):
        if self.native_busy:
            if self.limit_order is not None:self.cancel_limit(bar.time,'native_exposure_or_order')
            return bar
        if self.limit_order is not None and self.confirmation_time is not None:
            self.cancel_limit(bar.time,'missed_confirmation_submission')
            return bar
        # With no confirmation this branch only observes touches/reclaims.
        return super().fill_limit(bar)

    def seed(self,bars):
        for bar in bars:
            self.on_bar(bar)
            self.engine.on_bar(bar)
            self.previous=bar

    def synchronize(self,state):
        self.balance=50000.+state['realized_net']
        self.trailing_peak=state['highwater']
        self.session_open=state['session_open_cash']
        self.session=state['session'];self.stage_session=state['session']
        self.session_count=state['session_count']
        self.unlimited_stage=bool(state['goal_reached'])
        self.halted=bool(state['blocked'])
        self.native_busy=bool(state['quantity'] or state['entry_working'] or state['orders_working'] or state['active_id'])
        self.position=None;self.scale_state=None
        if state['quantity']:
            if self.native_signal is None or self.native_entry_time is None:
                raise BridgeError('Native position has no controller source identity; flatten/reconcile')
            self.position=Position(self.native_signal,self.native_entry_time,state['average_entry'],
                state['stop'],state['target'],state['quantity'],state['initial_risk'])
            self.scale_state=ScaleState(state['quantity'],0,state['target'])

    def observe(self,bar,state,payloads):
        if self.previous is not None and bar.time-self.previous.time!=MINUTE:
            raise BridgeError('Live minute gap; do not infer missing executions or confirmation')
        self.synchronize(state)
        self.payloads[bar.time]=payloads
        self.step(bar)

    def prepare_entry(self,state,now,config):
        healthy_state(state,now,config)
        order=self.limit_order
        busy=any(state[k] for k in ('quantity','entry_working','orders_working','active_id'))
        if busy or order is None or self.confirmation_time!=state['last_bar_utc']:
            return None
        if not 0<=(now-self.confirmation_time).total_seconds()<=5:
            self.cancel_limit(now,'submission_deadline_missed');return None
        if order.order_id in self.sent_sources:raise BridgeError('Source identity already submitted')
        d=order.signal.direction
        quote=state['ask'] if d==1 else state['bid']
        entry=self.instrument.price(quote+d*self.instrument.tick_size,up=d==1)
        if min(d*(quote-order.stop),d*(order.target-quote),d*(entry-order.stop),d*(order.target-entry))<=0:
            self.cancel_limit(now,'actual_quote_invalidates_bracket');return None
        self.family_cap=min(self.risk.risk_per_trade,order.source_budget)
        self.balance=50000.+state['realized_net'];self.session_open=state['session_open_cash'];self.trailing_peak=state['highwater']
        per=d*(entry-order.stop)*10+state['fee']+1.
        budget=min(order.budget_ceiling,self.risk_budget())
        q=min(order.quantity,10,int((budget+1e-8)//per))
        net_target=d*(order.target-entry)*10-state['fee']
        if net_target<=0:q=0
        elif not state['goal_reached']:
            q=min(q,int((max(0.,1200.-(self.balance-self.session_open))+1e-8)//net_target))
        if q<1:
            self.cancel_limit(now,'actual_quote_risk_or_profit_room');return None
        row=command(state,'ENTER',order.order_id,now,direction=d,quantity=q,
            reference=order.signal.reference,atr=order.signal.atr,stop=order.stop,target=order.target,
            planned_risk=per*q,expected_entry=entry,budget_ceiling=budget)
        self.native_signal=order.signal
        self.native_entry_time=self.confirmation_time
        self.sent_sources.add(order.order_id)
        self.limit_order=None
        return row
