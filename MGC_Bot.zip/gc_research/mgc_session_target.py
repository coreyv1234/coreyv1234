"""One fixed2R-to3R target extension using only realized session net at entry."""
from .mgc_exit_precision import ExitPrecisionMgc
from .targets import TargetPlanner,TargetDecision

def session_target_r(planned_risk,realized_session_net):
    needed=max(0.,500.-realized_session_net)
    return needed/planned_risk if 2*planned_risk<needed<=3*planned_risk else 2.

class SessionTargetMgc(ExitPrecisionMgc):
    def __init__(self,*args,**kwargs):super().__init__(*args,exit_policy='day_tree_protect2r',**kwargs)

    def __call__(self,ctx):
        r=session_target_r(ctx.planned_risk,self.balance-self.session_open)
        target,reward=TargetPlanner.net_target(ctx,r)
        return TargetDecision(True,'session500_extension' if r>2 else 'unchanged2r',target,r,reward,reward/ctx.planned_risk)

    def report(self):
        r=super().report();r['session_target_extension']={'goal':500.,'max_target_r':3.,'input':'realized session net at entry only',
            'extended_entries':sum(v['requested_net_r']>2 for v in self.target_decisions if v['accepted']),
            'no_profit_entry_lock':True,'target_is_not_guaranteed_fill':True};return r
