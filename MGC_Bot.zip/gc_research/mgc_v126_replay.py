"""V12.6 signals, corrected minute-path MGC risk/fill accounting, fixed TP trials."""
from collections import Counter,deque
from dataclasses import replace
from .backtest import Backtest
from .scaleout import ScaleOutBacktest
from .market import MINUTE,CT,INSTRUMENTS
from .strategy import Signal,StrategyConfig
from .targets import TargetPlanner,TargetDecision
from .decisions import EntryDecision

PLANS=('family_timer','family_no_timer','net2r','net3r','partial1r_runner3r')


class LegacySignalReplay:
    def __init__(self,payloads,account):
        self.payloads,self.account=payloads,account
        self.history=deque(maxlen=12);self.last_features=None;self.previous=None

    def on_bar(self,b):
        if self.previous and (b.time-self.previous.time!=MINUTE or b.session!=self.previous.session):self.history.clear()
        self.history.append(b);self.previous=b
        candidates=self.payloads.get(b.time,())
        if not candidates:return None
        first=candidates[0];d=1 if first['direction']=='LONG' else -1
        return Signal(b.time,b.instrument,d,first['event_family'],float(first['signal_close']),float(first['invalidation_price']),float(first['atr']))


class MgcV126Backtest(ScaleOutBacktest):
    def __init__(self,risk,payloads,pivots,*,plan='family_no_timer',stop_mode='original_cap',zero_trade_gaps=(),blocked_dates=(),research_contract_cap=10):
        if plan not in PLANS or stop_mode not in ('original_cap','full_structure'):raise ValueError('unknown trial')
        if research_contract_cap not in (10,12,15):raise ValueError('unregistered research contract cap')
        if risk.risk_per_trade>300 or risk.max_contracts>research_contract_cap:raise ValueError('outside agreed research limits')
        Backtest.__init__(self,'MGC',StrategyConfig(family='breakout',max_gap_atr=.34),risk)
        self.plan,self.stop_mode=plan,stop_mode;self.payloads=payloads;self.pivots=pivots
        self.engine=LegacySignalReplay(payloads,self)
        self.target_policy=self;self.entry_policy=lambda ctx:EntryDecision(True,'original_v126_raw_bar_signal')
        self.family_cap=300.;self.payload=None;self.initial_stop=None;self.deadline_minutes=None
        self.scale_state=None;self.partial_executions=[];self.runner_executions=[];self.runner=3
        self.one_contract_fallback_entries=0;self.stop_updates=[];self.exit_journal=[];self.attempts=[]
        self.zero_trade_gaps=set(zero_trade_gaps);self.blocked_dates=set(blocked_dates);self.gap_events=[]

    def risk_budget(self):return min(self.family_cap,super().risk_budget())

    def entry_guard(self,bar):
        """Extension point for past-realized-trade session policies."""
        return True

    def entry_payloads(self,stamp):
        """Source-priority candidates; optional learned vetoes override this."""
        return self.payloads.get(stamp,())

    def __call__(self,ctx):
        if self.plan.startswith('family'):
            r=float(self.payload.get('target_r_override',.9));distance=abs(ctx.entry-ctx.stop)
            target=round(round((ctx.entry+ctx.signal.direction*distance*r)/.1)*.1,10)
            reward=(ctx.signal.direction*(target-ctx.entry)*10-ctx.fees_per_contract)*ctx.quantity
            return TargetDecision(True,'original_family_gross_r',target,r,reward,reward/ctx.planned_risk)
        return TargetPlanner('net_2r' if self.plan=='net2r' else 'net_3r')(ctx)

    def open_position(self,ignored,b):
        if b.session in self.blocked_dates:
            self.rejections['published_holiday_blackout']+=1;return None
        stamp=b.time-MINUTE
        for payload in self.entry_payloads(stamp):
            family=payload['event_family']
            if family.startswith('ADDON_') and self.session_count>=4:continue
            self.family_cap=min(300.,float(payload.get('risk_budget_dollars',300.)))
            self.payload=payload;d=1 if payload['direction']=='LONG' else -1
            atr=float(payload['atr']);raw=float(payload['invalidation_price'])
            entry=self.instrument.price(b.open+d*self.risk.slippage_ticks_per_side*.1,up=d==1)
            raw_distance=d*(entry-raw)
            if raw_distance<=0:
                self.rejections['source_invalidation_already_passed']+=1;continue
            floor=.42 if family.startswith(('SCALP_','ADDON_')) else .62 if not family.startswith('PROBE_') else 0.
            distance=max(raw_distance,floor*atr,1.2)
            if self.stop_mode=='original_cap' and family.startswith(('SCALP_','ADDON_')):
                distance=min(distance,1.35*atr,8.)
            if self.stop_mode=='original_cap' and not 1.2<=distance<=8.:
                self.rejections['source_stop_bounds']+=1;continue
            stop=self.instrument.price(entry-d*distance,up=d==-1)
            signal=Signal(stamp,b.instrument,d,family,float(payload['signal_close']),stop,atr)
            before=dict(self.rejections)
            p=ScaleOutBacktest.open_position(self,signal,b)
            self.attempts.append({'signal_time':stamp.isoformat(),'session':b.session,'family':family,'direction':d,
                'raw_invalidation':raw,'stop':stop,'entry_estimate':entry,'family_budget':self.family_cap,
                'accepted':p is not None,'quantity':p.quantity if p else 0,
                'reason':'entered' if p else '|'.join(k for k,v in self.rejections.items() if v>before.get(k,0))})
            if p is not None:
                self.initial_stop=p.stop
                if self.plan!='partial1r_runner3r':self.scale_state.partial_quantity=0
                horizon=int(payload.get('max_hold_bars_override',12))
                self.deadline_minutes=5*horizon+(0 if family.startswith(('SCALP_','PROBE_','ADDON_')) else 5)
                return p
        return None

    def close_position(self,price,stamp,reason,*,limit=False,ambiguous=False):
        p=self.position
        self.exit_journal.append({'entry_time':p.entry_time.isoformat(),'exit_time':stamp.isoformat(),
            'remaining_quantity':p.quantity,'raw_price':price,'working_stop':p.stop,'initial_stop':self.initial_stop,
            'reason':reason,'limit':limit,'cash_before_exit':self.balance})
        initial=self.initial_stop
        super().close_position(price,stamp,reason,limit=limit,ambiguous=ambiguous)
        self.trades[-1]=replace(self.trades[-1],stop=initial)
        self.initial_stop=None

    def geometry(self):
        p=self.position;d=p.signal.direction;r=self.risk;inst=self.instrument
        charges=(r.commission_round_trip+r.slippage_ticks_per_side*inst.tick_size*inst.point_value)*p.quantity
        floor=max(self.account_stop_floor(),self.session_open-r.daily_loss_limit+r.drawdown_reserve)
        distance=max(0.,self.balance-floor-charges)/(inst.point_value*p.quantity)
        rs=inst.price(p.entry-d*distance,up=d==1)
        stop=max(p.stop,rs) if d==1 else min(p.stop,rs)
        through=inst.price(p.target+d*r.target_trade_through_ticks*.1,up=d==1)
        return stop,through,d*(stop-p.stop)>1e-8

    def base_manage(self,b):
        p=self.position
        if p is None:return
        p.bars_held+=1;d=p.signal.direction;stop,through,tightened=self.geometry()
        sg=b.open<=stop if d==1 else b.open>=stop
        tg=b.open>=through if d==1 else b.open<=through
        sh=b.low<=stop if d==1 else b.high>=stop
        th=b.high>=through if d==1 else b.low<=through
        if sg:self.close_position(b.open,b.time-MINUTE,'RISK_GAP' if tightened else 'STOP_GAP')
        elif tg:self.close_position(p.target,b.time-MINUTE,'TARGET_GAP',limit=True)
        elif sh:self.close_position(stop,b.time,'RISK_STOP' if tightened else 'STOP',ambiguous=th)
        elif th:self.close_position(p.target,b.time,'TARGET',limit=True)
        elif b.time.astimezone(CT).hour*60+b.time.astimezone(CT).minute>=self.risk.flatten_ct:
            self.close_position(b.close,b.time,'SESSION_FLAT')
        elif self.plan=='family_timer' and (b.time-p.entry_time).total_seconds()>=self.deadline_minutes*60:
            self.close_position(b.close,b.time,'ORIGINAL_TIME_EXIT')

    def manage(self,b):
        p,state=self.position,self.scale_state
        if p is None:return
        d=p.signal.direction
        adverse=self.balance+(d*((b.low if d==1 else b.high)-p.entry)*10-
            self.risk.commission_round_trip-self.risk.slippage_ticks_per_side)*p.quantity
        self.max_adverse_drawdown=max(self.max_adverse_drawdown,self.peak-adverse)
        if state and not state.partial_done and state.partial_quantity>0:
            stop,_,_=self.geometry();through=self.instrument.price(state.partial_target+d*.1,up=d==1)
            sg=b.open<=stop if d==1 else b.open>=stop
            sh=b.low<=stop if d==1 else b.high>=stop
            pg=b.open>=through if d==1 else b.open<=through
            ph=b.high>=through if d==1 else b.low<=through
            if not sg and pg:self.fill_partial(b,True)
            elif not sg and not sh and ph:
                self.fill_partial(b,False);b=replace(b,open=state.partial_target)
        self.base_manage(b)

    def on_bar(self,b):
        p=self.position
        if p is None or self.plan!='partial1r_runner3r':return
        per=p.planned_risk/self.scale_state.original_quantity;d=p.signal.direction
        close_net=d*(b.close-p.entry)*10-self.risk.commission_round_trip-self.risk.slippage_ticks_per_side
        if close_net<per-1e-8:return
        for level in self.pivots.get(b.time,()):
            if level['direction']!=d or level['origin']<p.entry_time.isoformat():continue
            candidate=self.instrument.price(level['price']-d*.1,up=d==-1)
            proposed=max(p.stop,candidate) if d==1 else min(p.stop,candidate)
            if d*(proposed-p.stop)>1e-8 and d*(b.close-proposed)>=.1-1e-8:
                self.stop_updates.append({'entry_time':p.entry_time.isoformat(),'bar_end':b.time.isoformat(),
                    'previous_stop':p.stop,'new_stop':proposed,'origin':level['origin'],'effective_after_this_bar':True})
                p.stop=proposed

    def report(self):
        r=super().report()
        r['limitations']=[v for v in r['limitations'] if not v.startswith('Segment-end liquidation')]
        r['limitations'].append('Only volume-verified zero-trade gaps retain brackets; unresolved open-position gaps exit at the next observed quote and remain flagged.')
        one=r['scaleout'].pop('one_contract_full_1r_fallback_entries',0)
        r['scaleout'].pop('runner_net_r',None)
        r['scaleout']['one_contract_full_final_target_entries']=one
        r['v126_corrected']={'exit_plan':self.plan,'stop_mode':self.stop_mode,
            'timer_active':self.plan=='family_timer','source_signal_priority':'core,scalp,probe,addon only below4 completed entries',
            'one_contract_retains_final_target':True,'gap_aware':True,'bar_path':'completed1m; stops before ambiguous targets',
            'source_labels_or_learned_model_used':False,'holiday_blackout_dates':sorted(self.blocked_dates),
            'zero_trade_gaps_while_open':sum(v['resolved_zero_trade'] for v in self.gap_events),
            'unresolved_gaps_while_open':sum(not v['resolved_zero_trade'] for v in self.gap_events)}
        return r

    def run(self,bars,start=None,end=None):
        """Same account sequence; never use a future gap to flatten at past close."""
        if self.previous is not None:raise RuntimeError('Single-use replay')
        for b in bars:
            selected=(start is None or b.session>=start) and (end is None or b.session<end)
            gap=self.previous and (b.time-self.previous.time!=MINUTE or b.instrument!=self.previous.instrument or b.session!=self.previous.session)
            if b.session!=self.session:
                self.finish_session();self.session,self.session_open=b.session,self.balance
                self.daily_halted,self.session_count=False,0
            if self.position and gap:
                resolved=(self.previous.time,b.time) in self.zero_trade_gaps
                self.gap_events.append({'entry_time':self.position.entry_time.isoformat(),
                    'previous_bar':self.previous.time.isoformat(),'next_bar':b.time.isoformat(),'resolved_zero_trade':resolved})
                if not resolved:
                    self.close_position(b.open,b.time-MINUTE,'DATA_GAP_NEXT_QUOTE')
            if self.position and not selected:
                self.close_position(b.open,b.time-MINUTE,'EVALUATION_BOUNDARY')
            if selected:
                self.active_sessions.add(b.session)
                local=(b.time-MINUTE).astimezone(CT);minute=local.hour*60+local.minute
                locked=self.risk.daily_profit_target is not None and self.balance-self.session_open>=self.risk.daily_profit_target-1e-8
                if locked:self.profit_locked_sessions.add(b.session)
                eligible=(not self.halted and not self.daily_halted and self.position is None and not locked and
                    local.weekday()<5 and self.risk.entry_start_ct<=minute<self.risk.entry_end_ct and
                    self.session_count<self.risk.max_trades_per_session and b.session not in self.blocked_dates)
                if eligible:eligible=self.entry_guard(b)
                if self.pending and not gap and eligible:self.position=self.open_position(self.pending,b)
                self.manage(b)
                equity=self.balance
                if self.position:
                    p=self.position
                    equity+=(b.close-p.entry)*p.signal.direction*10*p.quantity
                    equity-=(self.risk.commission_round_trip+self.risk.slippage_ticks_per_side)*p.quantity
                self.check_equity(equity);self.equity_curve.append((b.time.isoformat(),equity))
            self.on_bar(b)
            signal=self.engine.on_bar(b)
            if signal and selected:self.signals.append(signal)
            self.pending=signal if selected else None
            self.pending_features=None;self.pending_history=tuple(self.engine.history)
            self.previous=b
        if self.position:
            self.close_position(bars[-1].close,bars[-1].time,'DATA_END')
            self.equity_curve.append((bars[-1].time.isoformat(),self.balance))
        if bars:
            local=bars[-1].time.astimezone(CT)
            if local.hour*60+local.minute>=self.risk.flatten_ct:self.finish_session()
        return self.report()
