"""Source-derived long scalp patterns and causal continuation-context checks."""
import math
import numpy as np
import pandas as pd
from .mgc_native_model import NativeMgcReplay

POLICIES=('control','context_only','mirror_longs_only','context_and_mirror_longs')

def cme_context(frame,session_labels):
    """Bar-estimated session VWAP and extremes reset at17:00 Chicago.

    The legacy source resets its own context at calendar midnight. Its payloads
    stay unchanged; only the new context and new long mirrors use this frame.
    """
    out=frame.copy();sessions=session_labels.reindex(out.index)
    if sessions.isna().any():raise ValueError('Missing native CME session labels')
    typical=(out.high+out.low+out.close)/3
    out['session_date']=sessions
    out['session_open']=out.open.groupby(sessions).transform('first')
    out['session_vwap']=(typical*out.volume).groupby(sessions).cumsum()/out.volume.groupby(sessions).cumsum()
    out['distance_vwap_atr']=(out.close-out.session_vwap)/out.atr14
    high=out.high.groupby(sessions).max();low=out.low.groupby(sessions).min()
    out['prior_session_high']=sessions.map(high.shift(1));out['prior_session_low']=sessions.map(low.shift(1))
    out['session_high_prior']=out.high.groupby(sessions).cummax().groupby(sessions).shift(1)
    out['session_low_prior']=out.low.groupby(sessions).cummin().groupby(sessions).shift(1)
    return out

def context_values(row):
    atr=max(float(row['atr14']),1e-9)
    return [(float(row['ema21'])-float(row['ema55']))/atr,
        float(row['ema20_slope6_atr']),float(row['distance_vwap_atr'])]

def alignment_count(direction,metrics):
    return sum(math.isfinite(v) and direction*v>0 for v in metrics)

def long_scalp(m,frame,i):
    """Mirror the reviewed SHORT detector's price inequalities and invalidation.

    No reflection of log prices or future-trained target-space labels is used.
    The source helper evaluates actual LONG resistance/trend alignment.
    """
    if i<225:return None
    row=frame.iloc[i];previous=frame.iloc[i-1]
    required=('atr14','session_vwap','prior_high6','prior_low6','prior_high12','prior_low12',
        'body_atr','close_location','adx14','yz_vol_ratio100','extension_atr','kalman_slope_atr',
        'robust_momentum_z60','robust_range_z60','volume_ratio20')
    if any(pd.isna(row.get(k)) for k in required):return None
    atr=float(row.atr14)
    if not math.isfinite(atr) or atr<=0:return None
    close=float(row.close);low=float(row.low);body=float(row.body_atr);loc=float(row.close_location)
    adx=float(row.adx14);yz=float(row.yz_vol_ratio100);ext=float(row.extension_atr)
    kalman=float(row.kalman_slope_atr);rangez=float(row.robust_range_z60)
    hour=frame.index[i].tz_convert(m.CENTRAL).hour;candidates=[]

    def add(original,invalidation,strength,priority,target,horizon):
        distance=close-invalidation
        if not math.isfinite(distance) or distance<=0:return
        space=m._nearest_target_space(row,'LONG',close,atr)/max(distance,m.EPS)
        if priority==0 and space>m.SCALP_SWEEP_MAX_TARGET_SPACE_R:return
        aligned,supportive=m._trend_alignment(row,'LONG')
        quality=6.5+.4*strength
        p={'direction':'LONG','event_family':original.replace('BREAK_LOW','BREAK_HIGH').replace('SHORT','MIRROR_LONG'),
            'event_rule':'SYMMETRIC_V126_SCALP','strictness':'MIRRORED_PRICE_ACTION','quality_score':quality,
            'signal_close':close,'signal_stop_distance':distance,'invalidation_price':invalidation,
            'failure_level':invalidation,'atr':atr,'target_space_r':space,'pattern_strength':strength,
            'confirmation_strength':strength,'setup_age_bars':1,'adx':adx,
            'volume_ratio':min(float(row.volume_ratio20),float(row.volume_ratio5)),
            'trend_aligned':bool(aligned),'supportive_trend':bool(supportive),'risk_tier':'SCALP',
            'risk_budget_dollars':min(300.,float(m.SCALP_FAMILY_RISK_DOLLARS.get(original,m.SCALP_RISK_DOLLARS))),
            'execution_mode':'SCALP','target_r_override':float(target),'max_hold_bars_override':horizon,
            'stop_floor_atr_override':m.SCALP_STOP_FLOOR_ATR,'stop_cap_atr_override':m.SCALP_STOP_CAP_ATR,
            'scalp_priority':priority,'source_kind':'scalp','mirrored_long':True}
        candidates.append(p)

    prior_low=float(row.prior_low12)
    if (low<prior_low-.02*atr and close>prior_low and loc>.55 and body>0
        and yz<=m.SCALP_SWEEP_YZ_MAX and ext>=-m.SCALP_SWEEP_EXTENSION_MAX and hour!=5):
        add('SCALP_SWEEP_CONTROLLED_SHORT',low-.06*atr,max(0.,(prior_low-low)/atr)+abs(body),0,m.SCALP_SWEEP_TARGET_R,5)
    prev_vwap=float(previous.get('session_vwap',np.nan))
    if (math.isfinite(prev_vwap) and hour>=m.SCALP_VWAP_START_HOUR_CT and hour!=12
        and float(previous.close)<=prev_vwap and close>float(row.session_vwap) and body>.03
        and yz>=.85 and loc>.52 and float(row.cusum_pos)>=m.SCALP_VWAP_MIN_DIRECTIONAL_CUSUM):
        recent=frame.iloc[max(0,i-3):i+1]
        invalid=min(float(recent.low.min()),close-.55*atr)-.04*atr
        add('SCALP_VWAP_LATE_SHORT',invalid,max(0.,(close-float(row.session_vwap))/atr)+abs(body),1,m.SCALP_VWAP_TARGET_R,5)
    closes=frame.close.iloc[i-4:i].to_numpy(float)
    run=float(np.sign(np.diff(closes)).sum()) if len(closes)==4 else 0.
    if (float(previous.extension_atr)<-1 and run<=-1 and body>.04 and loc>.55
        and close>float(previous.high) and (float(previous.robust_momentum_z60)<-.4 or float(previous.robust_range_z60)>.35)
        and float(row.volume_ratio20)>=m.SCALP_EXHAUST_VOLUME_MIN and rangez<=m.SCALP_EXHAUST_RANGE_Z_MAX
        and hour in (2,3,4,9,10,11)):
        add('SCALP_EXHAUST_LIQUID_SHORT',min(float(previous.low),low)-.06*atr,abs(float(previous.extension_atr))+abs(body),2,m.SCALP_EXHAUST_TARGET_R,6)
    prior_high=float(row.prior_high6)
    if (close>prior_high+.015*atr and body>.1 and loc>.58 and 14<=adx<=m.SCALP_BREAK_ADX_MAX
        and kalman>-.08 and yz<=m.SCALP_BREAK_YZ_MAX and rangez<=m.SCALP_BREAK_RANGE_Z_MAX and hour!=10):
        recent=frame.iloc[max(0,i-3):i+1]
        add('SCALP_BREAK_LOW_RANGE_SHORT',float(recent.low.min())-.04*atr,abs(body)+max(0.,(close-prior_high)/atr),3,m.SCALP_BREAK_TARGET_R,6)
    if not candidates:return None
    candidates.sort(key=lambda p:p['scalp_priority']);return candidates[0]

class ContextMgcReplay(NativeMgcReplay):
    def __init__(self,*args,policy='control',**kwargs):
        if policy not in POLICIES:raise ValueError('Unregistered entry policy')
        super().__init__(*args,exit_style='net2r',**kwargs)
        self.policy=policy;self.context_decisions=[]

    def entry_payloads(self,stamp):
        allowed=[]
        for p in super().entry_payloads(stamp):
            mirrored=p.get('mirrored_long',False)
            if mirrored and self.policy not in ('mirror_longs_only','context_and_mirror_longs'):continue
            d=1 if p['direction']=='LONG' else -1;votes=alignment_count(d,p['context_metrics'])
            continuation='BREAK' in p['event_family'] or 'VWAP' in p['event_family']
            apply=mirrored or (self.policy in ('context_only','context_and_mirror_longs') and continuation)
            accepted=not apply or votes>=2
            self.context_decisions.append({'signal_time':stamp.isoformat(),'family':p['event_family'],
                'direction':d,'mirrored_long':mirrored,'favorable_context_votes':votes,'context_required':apply,'accepted':accepted})
            if accepted:allowed.append(p)
            else:self.rejections['continuation_or_new_long_against_context']+=1
        return allowed

    def report(self):
        r=super().report();r['entry_context_policy']=self.policy
        r['new_long_mirror_entries']=sum('MIRROR_LONG' in t.family for t in self.trades)
        return r
