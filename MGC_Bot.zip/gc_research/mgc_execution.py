"""SIM bridge wire format and frozen-model entry planning from native fill state.

This module never simulates a fill or calls the historical run/manage loop.
NinjaTrader owns position accounting and protective orders. This version is
restricted to Sim101/Playback101 until its native execution tests are complete.
"""
from __future__ import annotations

import hashlib
import math
import os
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .backtest import RiskConfig
from .market import Bar, CT, MINUTE, instrument_root
from .mgc_forest_session_target import ForestSessionTargetMgc

STATE_FIELDS = ("version", "run_id", "updated_utc", "phase", "account", "instrument", "blocked", "reason",
    "last_bar_utc", "last", "bid", "ask", "quote_utc", "quantity", "direction", "average_entry", "active_id",
    "stop", "target", "entry_working", "realized_net", "session_open_cash", "highwater", "session",
    "session_count", "fee", "slip", "initial_risk", "orders_working", "flatten_ct")
COMMAND_FIELDS = ("version", "run_id", "command_id", "issued_utc", "expires_utc", "kind", "model_id",
    "direction", "quantity", "reference", "atr", "stop", "target", "planned_risk", "expected_entry")
ID = re.compile(r"[a-f0-9]{32}\Z")
ENTRY_START_CT, ENTRY_END_CT, FLATTEN_CT = 120, 720, 955


class BridgeError(ValueError):
    pass


def utc(value):
    stamp = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if stamp.tzinfo is None or stamp.utcoffset() != timedelta():
        raise BridgeError("Expected explicit UTC timestamp")
    return stamp


def atomic_text(path, content):
    path = Path(path)
    temp = path.with_name(path.name + ".tmp." + str(os.getpid()))
    with temp.open("w", encoding="utf-8", newline="") as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)


def parse_state(text):
    lines = text.strip().splitlines()
    if len(lines) != 2 or tuple(lines[0].split(";")) != STATE_FIELDS:
        raise BridgeError("Wrong NinjaTrader snapshot schema")
    values = lines[1].split(";")
    if len(values) != len(STATE_FIELDS):
        raise BridgeError("Incomplete NinjaTrader snapshot")
    state = dict(zip(STATE_FIELDS, values))
    if state["version"] != "1" or not ID.fullmatch(state["run_id"]):
        raise BridgeError("Unsupported snapshot/run identity")
    if state["account"] not in ("Sim101", "Playback101"):
        raise BridgeError("This execution release only permits local SIM accounts")
    if instrument_root(state["instrument"]) != "MGC" or state["instrument"] == "MGC":
        raise BridgeError("Use an actual MGC expiry")
    for name in ("quantity", "direction", "entry_working", "session_count", "slip", "blocked", "orders_working", "flatten_ct"):
        state[name] = int(state[name])
    for name in ("last", "bid", "ask", "average_entry", "stop", "target", "realized_net", "session_open_cash", "highwater", "fee", "initial_risk"):
        state[name] = float(state[name])
        if not math.isfinite(state[name]):
            raise BridgeError("Nonfinite native state")
    for name in ("updated_utc", "last_bar_utc", "quote_utc"):
        state[name] = utc(state[name])
    if (not 0 <= state["quantity"] <= 10 or state["direction"] not in (-1, 0, 1) or
            (state["quantity"] == 0) != (state["direction"] == 0) or
            state["session_count"] < 0 or state["fee"] < 0 or state["slip"] != 1 or
            not 50000 <= state["highwater"] <= 52000 or state["session_open_cash"] <= 0 or state['flatten_ct'] not in (720,955) or
            any(state[k] not in (0, 1) for k in ("entry_working", "blocked", "orders_working"))):
        raise BridgeError("Native state violates release limits")
    return state


def healthy_state(state, now):
    if state["phase"] != "REALTIME" or state["blocked"]:
        raise BridgeError("NinjaTrader bridge is not armed in realtime SIM")
    if not 0 <= (now - state["updated_utc"]).total_seconds() <= 3:
        raise BridgeError("Native snapshot is stale or future-dated")
    if not 0 <= (now - state["quote_utc"]).total_seconds() <= 5:
        raise BridgeError("Bid/ask quote is stale or future-dated")
    if not 0 <= (now - state["last_bar_utc"]).total_seconds() <= 75:
        raise BridgeError("Closed minute feed is stale or future-dated")
    if state["bid"] <= 0 or state["ask"] < state["bid"] or state["ask"] - state["bid"] > .5 + 1e-8:
        raise BridgeError("Missing, crossed, or wider-than-five-tick quote")


def validate_chart_rows(rows, symbol):
    previous = None
    for row in rows:
        stamp = utc(row["time_utc"])
        if stamp.second or stamp.microsecond or (previous is not None and stamp <= previous):
            raise BridgeError("Chart rows must have unique, increasing minute ends")
        if row["instrument"] != symbol:
            raise BridgeError("Chart export changed expiry")
        o,h,l,c,v = (float(row[k]) for k in ("open","high","low","close","volume"))
        if (not all(math.isfinite(x) for x in (o,h,l,c,v)) or min(o,h,l,c) <= 0 or v <= 0 or
                l > min(o,c) or h < max(o,c) or l > h or
                any(abs(x/.1-round(x/.1)) > 1e-7 for x in (o,h,l,c))):
            raise BridgeError("Invalid chart OHLCV or price ticks; synthetic zero-volume bars are unsupported")
        previous = stamp


def command(state, kind, model_id, now, **values):
    if kind not in ("ENTER", "STOP", "FLATTEN") or not ID.fullmatch(model_id):
        raise BridgeError("Invalid command identity/type")
    ident = hashlib.sha256(f"{state['run_id']}|{kind}|{model_id}|{values}".encode()).hexdigest()[:32]
    row = dict.fromkeys(COMMAND_FIELDS, 0)
    row.update(version=1, run_id=state["run_id"], command_id=ident, issued_utc=now.isoformat(),
        expires_utc=(now + timedelta(seconds=3)).isoformat(), kind=kind, model_id=model_id, **values)
    return row


def write_command(folder, row):
    if tuple(row) != COMMAND_FIELDS or not ID.fullmatch(str(row["command_id"])):
        raise BridgeError("Invalid command schema")
    values = [str(row[k]) for k in COMMAND_FIELDS]
    if any(any(c in v for c in ";\r\n") for v in values):
        raise BridgeError("Unsafe command field")
    path = Path(folder) / "commands" / (row["command_id"] + ".cmd")
    if path.exists():
        raise BridgeError("A command with this identity already exists")
    atomic_text(path, ";".join(COMMAND_FIELDS) + "\n" + ";".join(values) + "\n")
    return path


def plan_entry(state, stamp, payloads, features, days, forests, holidays, now):
    healthy_state(state, now)
    if state["quantity"] or state["entry_working"] or state["orders_working"] or state["active_id"]:
        return None
    if stamp != state["last_bar_utc"] or not 0 <= (now-stamp).total_seconds() <= 20:
        return None
    local = stamp.astimezone(CT)
    session = Bar(stamp, state["instrument"], 1, 1, 1, 1, 0).session
    if (local.weekday() >= 5 or not ENTRY_START_CT <= local.hour*60+local.minute < ENTRY_END_CT or
            session != state["session"] or state["session_count"] >= 20 or session in holidays):
        return None
    if session not in features or utc(features[session]["available_at"]) > stamp:
        return None
    risk = RiskConfig(risk_per_trade=300, max_contracts=10, max_trades_per_session=20,
        commission_round_trip=state["fee"], slippage_ticks_per_side=1,
        entry_start_ct=ENTRY_START_CT, entry_end_ct=ENTRY_END_CT, flatten_ct=state['flatten_ct'])
    for source in payloads:
        if source["session_date"] != session:
            raise BridgeError("Source packet belongs to another session")
        d = 1 if source["direction"] == "LONG" else -1
        quote = state["ask"] if d == 1 else state["bid"]
        bar = Bar(stamp+MINUTE, state["instrument"], quote, quote, quote, quote, 0)
        planner = ForestSessionTargetMgc(risk, {stamp:[source]}, {}, models=days, features=features,
                                        trade_models=forests, blocked_dates=holidays)
        # Native execution ledger, never the balance from a hypothetical price path.
        planner.balance = 50000 + state["realized_net"]
        planner.session_open = state["session_open_cash"]
        planner.trailing_peak = state["highwater"]
        planner.session_count = state["session_count"]
        if not planner.entry_guard(bar):
            return None
        p = planner.open_position(None, bar)
        if p is None:
            continue
        key = f"{p.signal.instrument}|{stamp.isoformat()}|{p.signal.family}|{d}"
        model_id = hashlib.sha256(key.encode()).hexdigest()[:32]
        return command(state, "ENTER", model_id, now, direction=d, quantity=p.quantity,
            reference=p.signal.reference, atr=p.signal.atr, stop=p.stop, target=p.target,
            planned_risk=p.planned_risk, expected_entry=p.entry)
    return None


def protective_stop(state, closed_bar, now):
    """Cost break-even after a completed close reaches 1R from actual entry."""
    healthy_state(state, now)
    q, d = state["quantity"], state["direction"]
    if not q or state["entry_working"] or not ID.fullmatch(state["active_id"]):
        return None
    if closed_bar.time != state["last_bar_utc"] or closed_bar.instrument != state["instrument"]:
        raise BridgeError("Stop input does not match current native bar")
    charges = state["fee"] + 1.0
    close_net = (d*(closed_bar.close-state["average_entry"])*10-charges)*q
    if close_net < state["initial_risk"] - 1e-8:
        return None
    from .market import INSTRUMENTS
    candidate = INSTRUMENTS["MGC"].price(state["average_entry"]+d*charges/10, up=d == 1)
    if d*(candidate-state["stop"]) < .1-1e-8 or d*(closed_bar.close-candidate) < .1-1e-8:
        return None
    return command(state, "STOP", state["active_id"], now, direction=d, quantity=q, stop=candidate)
