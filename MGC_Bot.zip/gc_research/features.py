"""Causal, normalized research features from completed one-minute bars.

No aggressor direction, institutional identity, or Hawkes fit is inferred.
"""
from __future__ import annotations

import math
from collections import deque
from dataclasses import asdict, dataclass

from .market import Bar, MINUTE


@dataclass(frozen=True)
class FeatureFrame:
    velocity_atr_per_minute: float | None = None
    acceleration_atr_per_minute2: float | None = None
    efficiency_20: float | None = None
    volume_z_prior20: float | None = None
    ewma_return_volatility: float | None = None

    def values(self):
        return asdict(self)


class CausalFeatures:
    def __init__(self):
        self.reset()

    def reset(self):
        self.previous = None
        self.closes = deque(maxlen=21)
        self.volumes = deque(maxlen=20)
        self.ranges = deque(maxlen=14)
        self.atr = None
        self.previous_velocity = None
        self.return_variance = None

    def push(self, bar: Bar) -> FeatureFrame:
        previous = self.previous
        if previous and bar.time <= previous.time:
            raise ValueError("feature input must advance in time")
        if previous and (bar.time - previous.time != MINUTE
                         or bar.instrument != previous.instrument
                         or bar.session != previous.session):
            self.reset()
            previous = None
        tr = max(bar.high - bar.low, abs(bar.high - previous.close),
                 abs(bar.low - previous.close)) if previous else bar.high - bar.low
        self.ranges.append(tr)
        if self.atr is None and len(self.ranges) == 14:
            self.atr = sum(self.ranges) / 14
        elif self.atr is not None:
            self.atr = (13 * self.atr + tr) / 14
        self.closes.append(bar.close)
        velocity = acceleration = efficiency = volume_z = volatility = None
        if self.atr is not None and self.atr > 0:
            # Three-minute secant reduces noise compared with a one-tick derivative.
            velocity = (self.closes[-1] - self.closes[-4]) / (3 * self.atr)
            if self.previous_velocity is not None:
                acceleration = velocity - self.previous_velocity
        if len(self.closes) == 21:
            path = sum(abs(b-a) for a, b in zip(self.closes, list(self.closes)[1:]))
            if path > 0:
                efficiency = abs(self.closes[-1] - self.closes[0]) / path
        # Current volume is excluded from the reference distribution.
        if len(self.volumes) == 20:
            mean = sum(self.volumes) / 20
            variance = sum((v-mean)**2 for v in self.volumes) / 20
            if variance > 0:
                volume_z = (bar.volume-mean) / math.sqrt(variance)
        if previous:
            ret = math.log(bar.close / previous.close)
            self.return_variance = (ret*ret if self.return_variance is None else
                                    .94*self.return_variance + .06*ret*ret)
            volatility = math.sqrt(self.return_variance)
        self.volumes.append(bar.volume)
        self.previous_velocity = velocity
        self.previous = bar
        return FeatureFrame(velocity, acceleration, efficiency, volume_z, volatility)


def accepts(frame: FeatureFrame, direction: int, name: str) -> bool:
    if name not in {"none", "momentum", "efficiency", "combined"}:
        raise ValueError("unknown feature filter")
    momentum = (frame.velocity_atr_per_minute is not None
                and frame.acceleration_atr_per_minute2 is not None
                and direction * frame.velocity_atr_per_minute > 0
                and direction * frame.acceleration_atr_per_minute2 >= 0)
    efficient = frame.efficiency_20 is not None and frame.efficiency_20 >= .30
    return {"none": True, "momentum": momentum, "efficiency": efficient,
            "combined": momentum and efficient}[name]
