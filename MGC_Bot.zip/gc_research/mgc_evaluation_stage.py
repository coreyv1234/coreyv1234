"""Evaluation profit-budget and legacy-entry hypotheses; offline research only."""
from dataclasses import replace
import math

from .market import MINUTE
from .mgc_native_scale_v2 import NativeScaleV2Mgc

ENTRY_POLICIES=('confirmed','source_next_open','scalp_next_open','legacy_scalp')
LEGACY_SCALP_R={
    'SCALP_SWEEP_CONTROLLED_SHORT': .8,
    'SCALP_VWAP_LATE_SHORT': .95,
    'SCALP_EXHAUST_LIQUID_SHORT': 1.2,
    'SCALP_BREAK_LOW_RANGE_SHORT': 1.3,
}


class EvaluationStageMgc(NativeScaleV2Mgc):
    def __init__(self,*args,entry_policy='confirmed',profit_cap=1200.,pass_balance=53000.,**kwargs):
        if entry_policy not in ENTRY_POLICIES:
            raise ValueError('Unknown registered entry policy')
        if not math.isfinite(profit_cap) or profit_cap<=0 or not math.isfinite(pass_balance):
            raise ValueError('Invalid evaluation policy')
        super().__init__(*args,**kwargs)
        if self.risk.daily_profit_target is not None or self.goal_lock:
            raise ValueError('Stage policy owns its profit budget; no conflicting goal lock')
        self.entry_policy=entry_policy
        self.profit_cap=float(profit_cap)
        self.pass_balance=float(pass_balance)
        self.unlimited_stage=False
        self.stage_session=None
        self.stage_events=[]
        self.profit_budget_events=[]

    def step(self,bar):
        if bar.session!=self.stage_session:
            # A crossing never lifts the cap during the same evaluation day.
            self.unlimited_stage=self.unlimited_stage or self.balance>self.pass_balance+1e-8
            self.stage_session=bar.session
            self.stage_events.append(dict(session=bar.session,opening_balance=self.balance,
                unlimited=self.unlimited_stage,net_profit_cap=None if self.unlimited_stage else self.profit_cap))
        return super().step(bar)

    def profit_room(self):
        return math.inf if self.unlimited_stage else max(0.,self.profit_cap-(self.balance-self.session_open))

    def place_limit(self,bar):
        if self.profit_room()<=1e-8:
            self.rejections['evaluation_profit_cap_reached']+=1
            return None
        order=super().place_limit(bar)
        if order is None:
            return None
        family=order.signal.family
        immediate=self.entry_policy=='source_next_open' or (
            self.entry_policy in ('scalp_next_open','legacy_scalp') and family.startswith('SCALP_'))
        if self.entry_policy=='legacy_scalp' and family in LEGACY_SCALP_R:
            d=order.signal.direction
            target=self.instrument.price(order.limit+d*abs(order.limit-order.stop)*LEGACY_SCALP_R[family],up=d==1)
            self.limit_order=order=replace(order,target=target)
            self.orders[-1].update(target=target,target_rule='archived_scalp_family_r',legacy_target_r=LEGACY_SCALP_R[family])
        if immediate:
            self.confirmation_time=self.touch_time=bar.time
            self.limit_order=order=replace(order,expiry=bar.time+MINUTE)
            self.orders[-1].update(expiry=order.expiry.isoformat(),execution_rule='source_close_next_open',
                confirmation_time=bar.time.isoformat(),touch_time=bar.time.isoformat())
        return order

    def fill_limit(self,bar):
        order=self.limit_order
        if order is not None and self.confirmation_time is not None and not self.unlimited_stage:
            d=order.signal.direction
            slip=self.risk.slippage_ticks_per_side*self.instrument.tick_size
            entry=self.instrument.price(bar.open+d*slip,up=d==1)
            per_net=d*(order.target-entry)*self.instrument.point_value-self.risk.commission_round_trip
            room=self.profit_room()
            quantity=min(order.quantity,int((room+1e-8)//per_net)) if per_net>0 else 0
            self.profit_budget_events.append(dict(order_id=order.order_id,time=(bar.time-MINUTE).isoformat(),
                opening_quote=bar.open,expected_entry=entry,source_quantity=order.quantity,
                profit_room=room,net_target_per_contract=per_net,profit_budget_quantity=quantity,
                stop=order.stop,target=order.target))
            if quantity<1:
                self.cancel_limit(bar.time-MINUTE,'evaluation_profit_room_below_one_contract')
                return bar
            self.limit_order=replace(order,quantity=quantity)
        result=super().fill_limit(bar)
        if self.position is not None and self.fills and self.fills[-1]['fill_bar_end']==bar.time.isoformat():
            self.fills[-1].update(stage_unlimited=self.unlimited_stage,profit_room_at_entry=self.profit_room(),
                entry_policy=self.entry_policy)
        return result

    def report(self):
        report=super().report()
        report['evaluation_stage']=dict(entry_policy=self.entry_policy,profit_cap=self.profit_cap,
            pass_balance=self.pass_balance,unlimited_latched=self.unlimited_stage,
            transition='Next session after a closing balance strictly above threshold; historical simulation only',
            sizing='Whole-contract quantity reduced before actual next-open entry; brackets unchanged except explicit legacy target arm',
            gaps='Observed gap exits retained even if they breach the profit cap; never clip PnL',
            broker_orders_sent=False)
        return report
