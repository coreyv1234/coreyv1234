"""Separate price invalidation, chart-based profit objective and dollar sizing.

Explicit research-only higher-risk profiles. No execution adapter is provided.
"""
from collections import deque
from dataclasses import replace
from datetime import timedelta
from .gold_daily_uplift import GoldSessionRuntime
from .market import MINUTE
from .scaleout import ScaleOutBacktest
from .strategy import Signal
from .targets import TargetDecision


def structure_target(history,stamp,entry,direction):
    """Next confirmed five-minute swing; otherwise a prior-range projection.

    No stop, quantity, risk budget, daily cash goal or future bar is an input.
    History continuity/expiry is enforced by the caller; zero-trade gaps may
    remain when already attested. The first potentially partial bucket is cut.
    """
    if not history or history[-1].time!=stamp:return None
    bins={}
    for b in history:
        if b.time>stamp:raise ValueError('Future target candle')
        phase=b.time.minute%5
        close=b.time+timedelta(minutes=5-phase) if phase else b.time
        if close>stamp:continue
        if close not in bins:bins[close]=[b.high,b.low]
        else:bins[close]=[max(bins[close][0],b.high),min(bins[close][1],b.low)]
    five=list(sorted(bins.items()))[1:]
    if len(five)<12:return None
    levels=[]
    for i in range(2,len(five)-2):
        window=five[i-2:i+3]
        if any(window[j][0]-window[j-1][0]!=timedelta(minutes=5) for j in range(1,5)):continue
        level=five[i][1][0 if direction==1 else 1]
        values=[v[1][0 if direction==1 else 1] for v in window]
        pivot=level>=max(values) if direction==1 else level<=min(values)
        if pivot and direction*(level-entry)>.1+1e-8:levels.append((level,five[i][0]))
    if levels:
        level,origin=min(levels,key=lambda v:direction*(v[0]-entry))
        raw=round(level-direction*.1,10)
        return dict(price=raw,reason='next_confirmed5m_swing_inside_tick',level=level,origin=origin.isoformat(),inputs_end=stamp.isoformat())
    prior=five[-7:-1];high=max(v[1][0] for v in prior);low=min(v[1][1] for v in prior);width=high-low
    if width<.1:return None
    raw=round((high+width-.1) if direction==1 else (low-width+.1),10)
    if direction*(raw-entry)<.1-1e-8:return None
    return dict(price=raw,reason='prior30m_range_measured_move_inside_tick',box_high=high,box_low=low,
        projection_origin=prior[-1][0].isoformat(),inputs_end=stamp.isoformat())


class PriceTargetMgc(GoldSessionRuntime):
    def __init__(self,risk,payloads,*,target_mode='structure',explicit_research_risk=False,**kwargs):
        if not explicit_research_risk or risk.risk_per_trade not in (300,450,600) or risk.max_contracts!=40:
            raise ValueError('Explicit research profiles only:300/450/600TOTALrisk and40MGC ceiling')
        if target_mode not in ('retained_cash','structure'):raise ValueError('Unknown target policy')
        # Preserve frozen constructors/default caps. This research subclass
        # explicitly opts into the user-requested higher dollar/contract caps;
        # all new accepted positions still fit daily and EOD remaining room.
        initial=replace(risk,risk_per_trade=300,max_contracts=10)
        super().__init__('MGC',initial,payloads,minimum_stop_points=1.2,minimum_goal_r=2.,deduplicate_entries=False,**kwargs)
        self.risk=risk;self.target_mode=target_mode;self.structure_history=deque(maxlen=240);self.price_targets=[]

    def __call__(self,ctx):
        if self.target_mode=='retained_cash':return super().__call__(ctx)
        result=structure_target(self.structure_history,ctx.signal.time,ctx.entry,ctx.signal.direction)
        if result is None:return TargetDecision(False,'no_independent_structure_target',None,None,None,None)
        # Price target is selected first from closed chart observations. Size
        # and stop are used below only to report the resulting dollars/R.
        target=self.instrument.price(result['price'],up=ctx.signal.direction==-1)
        reward=(ctx.signal.direction*(target-ctx.entry)*10-self.risk.commission_round_trip)*ctx.quantity
        self.price_targets.append(dict(signal_time=ctx.signal.time.isoformat(),entry=ctx.entry,stop=ctx.stop,
            quantity=ctx.quantity,planned_risk=ctx.planned_risk,net_reward=reward,**result))
        if reward<=0:return TargetDecision(False,'chart_target_not_profitable_after_cost',None,None,None,None)
        derived_r=reward/ctx.planned_risk
        return TargetDecision(True,result['reason'],target,derived_r,reward,derived_r)

    def open_position(self,ignored,b):
        if b.session in self.blocked_dates:return None
        stamp=b.time-MINUTE
        for source in self.entry_payloads(stamp):
            family=source['event_family']
            if family.startswith('ADDON_') and self.session_count>=4:continue
            self.family_cap=min(self.risk.risk_per_trade,float(source['risk_budget_dollars']))
            self.payload=source;d=1 if source['direction']=='LONG' else -1;atr=float(source['atr'])
            entry=self.instrument.price(b.open+d*self.risk.slippage_ticks_per_side*.1,up=d==1)
            raw=float(source['invalidation_price']);distance=d*(entry-raw)
            if distance<=0:self.rejections['source_invalidation_already_passed']+=1;continue
            floor=.42 if family.startswith(('SCALP_','ADDON_')) else .62 if not family.startswith('PROBE_') else 0.
            stop=self.instrument.price(entry-d*max(distance,floor*atr,1.2),up=d==-1)
            signal=Signal(stamp,b.instrument,d,family,source['signal_close'],stop,atr)
            p=ScaleOutBacktest.open_position(self,signal,b)
            if p is not None:
                self.entry_bars.clear();self.initial_stop=p.stop;self.scale_state.partial_quantity=0
                return p
        return None

    def on_bar(self,b):
        super().on_bar(b)
        if self.structure_history:
            prior=self.structure_history[-1]
            known=(prior.time,b.time) in self.zero_trade_gaps
            if prior.instrument!=b.instrument or prior.session!=b.session or (b.time-prior.time!=MINUTE and not known):self.structure_history.clear()
        self.structure_history.append(b)

    def report(self):
        r=super().report()
        if self.target_mode=='structure':r['session_target_extension']=dict(enabled=False,R_is_result_diagnostic_only=True)
        r['independent_price_target']=dict(mode=self.target_mode,planned_risk_cap=self.risk.risk_per_trade,
            research_contract_ceiling=self.risk.max_contracts,stop_rule='Original invalidation+existing ATRfloor/minimum; no narrowing for size',
            target_rule='Closed chart swings or prior30m measured move; no stop/R/cash-goal input' if self.target_mode=='structure' else 'Incumbent R/cash formula, control only',
            size_rule='Whole contracts fitting stop+exit slippage+RTfees and available daily/EOD/source risk',
            actual_firm_micro_contract_cap_verified=False,broker_orders=False)
        return r
