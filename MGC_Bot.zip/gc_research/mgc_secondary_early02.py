"""One fixed additional early02 opening-range source; offline research only."""
from .market import CT, MINUTE
from .mgc_confirmed_pullback import ConfirmedPullbackMgc


class SecondaryEarly02Mgc(ConfirmedPullbackMgc):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, confirmation_policy='confirmed_pullback3', **kwargs)
        self.or_attempted = set()
        self.or_sources = []
        self.or_decisions = []
        self._or_injection = None

    def entry_payloads(self, stamp):
        # This new price-defined family has no legacy47 feature vector. Its
        # rules do not invent zero order-flow features to pass an old forest.
        if self._or_injection is not None and self._or_injection[0] == stamp:
            return [self._or_injection[1]]
        return super().entry_payloads(stamp)

    def or_payload(self, bar):
        loc = bar.time.astimezone(CT)
        minute = loc.hour*60+loc.minute
        if not 135 < minute < 210:
            return None, 'outside_or_source_window'
        history = list(self.structure_history)
        if not history or history[-1].time != bar.time or any(b.time > bar.time for b in history):
            raise ValueError('OR context must end at the current closed candle')
        window = [b for b in history if b.session == bar.session and b.instrument == bar.instrument
                  and 120 < (b.time.astimezone(CT).hour*60+b.time.astimezone(CT).minute) <= 135]
        if (len(window) != 15 or window[0].time.astimezone(CT).minute != 1
                or window[0].time.astimezone(CT).hour != 2
                or any(b.volume <= 0 for b in window)
                or any(b.time-a.time != MINUTE for a,b in zip(window,window[1:]))):
            return None, 'incomplete_opening_range'
        recent = history[-21:]
        if (len(recent) != 21 or any(b.instrument != bar.instrument or b.session != bar.session for b in recent)
                or any(b.time-a.time != MINUTE for a,b in zip(recent,recent[1:]))):
            return None, 'incomplete_atr_context'
        high, low = max(b.high for b in window), min(b.low for b in window)
        d = (1 if bar.close >= high+.1-1e-8 and bar.close > bar.open else
             -1 if bar.close <= low-.1+1e-8 and bar.close < bar.open else 0)
        if not d:
            return None, 'no_closed_directional_breakout'
        atr = sum(max(b.high-b.low, abs(b.high-a.close), abs(b.low-a.close))
                  for a,b in zip(recent,recent[1:]))/20
        if atr <= 0 or high-low < .1:
            return None, 'invalid_range_or_atr'
        source = dict(direction='LONG' if d == 1 else 'SHORT', event_family='EARLY02_OR15_BREAK_'+('LONG' if d==1 else 'SHORT'),
            source_kind='secondary_opening_range', session_date=bar.session,
            signal_close=bar.close, invalidation_price=low if d == 1 else high,
            atr=atr, risk_budget_dollars=400., source_time=bar.time.isoformat(),
            range_high=high, range_low=low, range_start=window[0].time.isoformat(),
            range_end=window[-1].time.isoformat(), atr_inputs_start=recent[0].time.isoformat(),
            inputs_end=bar.time.isoformat())
        return source, 'closed_or_breakout'

    def step(self, bar):
        # Existing positions/proposals and same-bar canonical signals always
        # receive their original handling before the supplementary source.
        super().step(bar)
        selected = ((self.start is None or bar.session >= self.start)
                    and (self.end is None or bar.session < self.end))
        if (not selected or bar.session in self.or_attempted or self.position is not None
                or self.limit_order is not None or self.session_count != 0):
            return
        source, reason = self.or_payload(bar)
        if reason == 'outside_or_source_window':
            return
        decision = dict(time=bar.time.isoformat(), session=bar.session, reason=reason)
        if source is not None:
            # Only one attempted proposal per session, even when its inherited
            # daily/risk/target checks subsequently reject it.
            self.or_attempted.add(bar.session)
            self.or_sources.append(source)
            self._or_injection = (bar.time, source)
            try:
                order = self.place_limit(bar)
            finally:
                self._or_injection = None
            decision.update(accepted=order is not None, source=source,
                            order_id=order.order_id if order else None)
        self.or_decisions.append(decision)

    def report(self):
        r = super().report()
        r['secondary_early02'] = dict(attempted=len(self.or_attempted), sources=len(self.or_sources),
            new_family_only_bypasses_legacy_trade_forest=True, daily_gate_retained=True,
            invented_flow_features=False, native_adapter=False)
        return r
