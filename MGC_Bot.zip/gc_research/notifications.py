"""Optional Discord transport. Importing this module never sends anything."""
from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.request


class NotificationError(RuntimeError):
    pass


class DiscordNotifier:
    def __init__(self, webhook: str):
        if not re.fullmatch(r"https://discord\.com/api/webhooks/[0-9]+/[A-Za-z0-9_-]+", webhook):
            raise ValueError("Discord webhook must use the official discord.com HTTPS webhook endpoint")
        self._webhook = webhook

    @classmethod
    def from_environment(cls):
        value = os.environ.get("DISCORD_WEBHOOK_URL", "").strip()
        if not value:
            raise NotificationError("DISCORD_WEBHOOK_URL is not configured")
        return cls(value)

    def send(self, message: str):
        if not isinstance(message, str) or not message or len(message) > 2000:
            raise ValueError("Discord message must contain 1–2000 characters")
        payload = json.dumps({"content": message, "allowed_mentions": {"parse": []}}).encode()
        request = urllib.request.Request(self._webhook, data=payload, method="POST",
                                         headers={"Content-Type": "application/json", "User-Agent": "SovereignGCResearch/0.1"})
        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                if not 200 <= response.status < 300:
                    raise NotificationError(f"Discord returned HTTP {response.status}")
        except urllib.error.HTTPError as exc:
            raise NotificationError(f"Discord returned HTTP {exc.code}; no automatic retry") from None
        except (urllib.error.URLError, TimeoutError, OSError):
            raise NotificationError("Discord delivery failed; webhook details omitted") from None
