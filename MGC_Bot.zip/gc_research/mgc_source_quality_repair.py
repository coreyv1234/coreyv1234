"""Source-candle confirmation tests on top of the targeted breakout repair."""
from dataclasses import replace
from .mgc_loss_flat_repair import LossFlatRepairMgc

POLICIES=('reference','body_reclaim','location_reclaim','both_reclaim')


class SourceQualityRepairMgc(LossFlatRepairMgc):
    def __init__(self,*args,source_quality_policy,**kwargs):
        if source_quality_policy not in POLICIES:
            raise ValueError('Unknown fixed source quality policy')
        super().__init__(*args,repair_policy='break_reclaim',**kwargs)
        self.source_quality_policy=source_quality_policy
        self.source_quality_events=[]

    def place_limit(self,bar):
        order=super().place_limit(bar)
        if order is None or self.confirmation_time!=bar.time:
            return order
        d=order.signal.direction
        body_support=d*(bar.close-bar.open)>1e-8
        location_support=bar.high>bar.low and d*(2*bar.close-bar.high-bar.low)>=-1e-8
        wait=(self.source_quality_policy in ('body_reclaim','both_reclaim') and not body_support
            or self.source_quality_policy in ('location_reclaim','both_reclaim') and not location_support)
        self.source_quality_events.append(dict(order_id=order.order_id,source_time=bar.time.isoformat(),
            policy=self.source_quality_policy,direction=d,source_open=bar.open,source_high=bar.high,
            source_low=bar.low,source_close=bar.close,body_support=body_support,
            location_support=location_support,wait_for_reclaim=wait,stop=order.stop,
            target=order.target,quantity=order.quantity))
        if wait:
            self.confirmation_time=self.touch_time=None
            self.limit_order=order=replace(order,expiry=self.confirmation_deadline)
            self.orders[-1].update(expiry=order.expiry.isoformat(),confirmation_time='',touch_time='',
                execution_rule='source_quality_requires_reclaim')
        return order

    def report(self):
        report=super().report()
        report['source_quality_repair']=dict(policy=self.source_quality_policy,
            events=self.source_quality_events,price_inputs='Current completed source minute only',
            stop_target_size_unchanged=True,forecasts_unchanged=True)
        return report
