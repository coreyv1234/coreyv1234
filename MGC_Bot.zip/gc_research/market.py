from __future__ import annotations

import csv
import math
import re
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_EVEN
from pathlib import Path
from zoneinfo import ZoneInfo

CT = ZoneInfo("America/Chicago")
MINUTE = timedelta(minutes=1)


@dataclass(frozen=True)
class Instrument:
    root: str
    point_value: float
    tick_size: float = 0.1

    def price(self, value: float, up: bool) -> float:
        if not math.isfinite(value):
            raise ValueError('price must be finite')
        ticks = Decimal(str(value)) / Decimal(str(self.tick_size))
        # Float arithmetic on an already valid tick (e.g. 4273.7 - .1)
        # must not charge another tick when converted to an outward price.
        nearest = ticks.to_integral_value(rounding=ROUND_HALF_EVEN)
        if abs(ticks-nearest) <= Decimal('0.000000001'):
            ticks = nearest
        rounded = ticks.to_integral_value(rounding=ROUND_CEILING if up else ROUND_FLOOR)
        return float(rounded * Decimal(str(self.tick_size)))


INSTRUMENTS = {"GC": Instrument("GC", 100.0), "MGC": Instrument("MGC", 10.0)}


@dataclass(frozen=True)
class Bar:
    # Timestamp is the END of a completed one-minute bar, always timezone-aware.
    time: datetime
    instrument: str
    open: float
    high: float
    low: float
    close: float
    volume: float

    @property
    def session(self) -> str:
        # CME trading date rolls at 17:00 CT, including daylight saving changes.
        local = self.time.astimezone(CT)
        day = local.date() + (timedelta(days=1) if local.hour >= 17 else timedelta())
        return day.isoformat()


def instrument_root(symbol: str) -> str:
    # Accept GC 12-26 / GC DEC26 / GCZ6 / GCZ26 / GCZ2026, never substring MGC.
    s = symbol.strip().upper()
    for root in ("MGC", "GC"):
        suffix = s[len(root):] if s.startswith(root) else "!"
        if not suffix or re.fullmatch(r"\s+(?:\d{2}-\d{2}|[A-Z]{3}\d{2,4})|[FGHJKMNQUVXZ]\d{1,4}", suffix):
            return root
    raise ValueError(f"Unrecognized futures contract: {symbol!r}")


def load_bars(path: Path, root: str) -> list[Bar]:
    bars: list[Bar] = []
    seen: set[datetime] = set()
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        required = {"time_utc", "instrument", "open", "high", "low", "close", "volume"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError(f"CSV requires columns {sorted(required)}")
        for line, row in enumerate(reader, 2):
            try:
                stamp = datetime.fromisoformat(row["time_utc"].replace("Z", "+00:00"))
                if stamp.tzinfo is None or stamp.utcoffset() != timedelta():
                    raise ValueError("time_utc must explicitly use UTC (Z or +00:00)")
                if stamp.second or stamp.microsecond:
                    raise ValueError("bar end must be aligned to a minute")
                symbol = row["instrument"].strip().upper()
                if instrument_root(symbol) != root:
                    raise ValueError(f"expected {root}; mixed GC/MGC input is prohibited")
                if symbol == root:
                    raise ValueError("use an actual expiry, not a continuous root symbol")
                o, h, lo, c, v = (float(row[k]) for k in ("open", "high", "low", "close", "volume"))
                if not all(math.isfinite(x) for x in (o, h, lo, c, v)):
                    raise ValueError("nonfinite OHLCV")
                if min(o, h, lo, c) <= 0 or v < 0 or lo > min(o, c) or h < max(o, c) or h < lo:
                    raise ValueError("invalid OHLCV geometry")
                for price in (o, h, lo, c):
                    if not math.isclose(price / .1, round(price / .1), abs_tol=1e-7):
                        raise ValueError("price is off the 0.10 tick grid")
                if stamp in seen or (bars and stamp <= bars[-1].time):
                    raise ValueError("timestamps must be unique and strictly increasing; roll contracts explicitly")
                seen.add(stamp)
                bars.append(Bar(stamp.astimezone(timezone.utc), symbol, o, h, lo, c, v))
            except (ValueError, KeyError, TypeError) as exc:
                raise ValueError(f"{path.name}:{line}: {exc}") from exc
    if not bars:
        raise ValueError("CSV has no bars")
    return bars


def data_quality(bars: list[Bar]) -> dict:
    gaps = [(a, b) for a, b in zip(bars, bars[1:]) if b.time - a.time != MINUTE]
    return {
        "bars": len(bars), "sessions": len({b.session for b in bars}),
        "first_bar_end": bars[0].time.isoformat(), "last_bar_end": bars[-1].time.isoformat(),
        "instruments": sorted({b.instrument for b in bars}), "gaps": len(gaps),
        "same_session_gaps": sum(a.session == b.session for a, b in gaps),
        "contract_changes": sum(a.instrument != b.instrument for a, b in zip(bars, bars[1:])),
        "note": "Gaps include expected closures; every gap resets strategy warmup. Review provider session coverage separately.",
    }
