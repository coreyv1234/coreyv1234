"""Shared historical/native sizing with an explicit reserve against drawdown."""
from dataclasses import dataclass, replace
import math

from .mgc_range_projection import RangeProjectionMgc


@dataclass(frozen=True)
class CapitalPolicy:
    protected_room: float = 600.
    fraction: float = .25

    def __post_init__(self):
        if not math.isfinite(self.protected_room) or self.protected_room<0:
            raise ValueError('Protected room must be finite and nonnegative')
        if not math.isfinite(self.fraction) or not 0<self.fraction<=1:
            raise ValueError('Capital fraction must be in (0,1]')


def capital_budget(balance,session_open,highwater,risk,policy=CapitalPolicy()):
    if not all(math.isfinite(v) for v in (balance,session_open,highwater)):
        raise ValueError('Nonfinite account capital')
    eod_room=balance-highwater+risk.max_drawdown-risk.drawdown_reserve
    daily_room=balance-session_open+risk.daily_loss_limit-risk.drawdown_reserve
    usable=max(0.,eod_room-policy.protected_room)
    return max(0.,min(risk.risk_per_trade,daily_room,eod_room,usable*policy.fraction))


class EvalCapitalMgc(RangeProjectionMgc):
    def __init__(self,risk,payloads,*,capital_policy=CapitalPolicy(),**kwargs):
        if not 1<=risk.max_contracts<=40 or risk.risk_per_trade!=400:
            raise ValueError('400 total planned risk cap;1..40 MGC')
        super().__init__(replace(risk,max_contracts=40),payloads,explicit_research_risk=True,**kwargs)
        self.risk=risk
        self.capital_policy=capital_policy

    def risk_budget(self):
        return min(super().risk_budget(),capital_budget(self.balance,self.session_open,self.trailing_peak,self.risk,self.capital_policy))

    def report(self):
        r=super().report()
        r['capital_policy']=dict(protected_room=self.capital_policy.protected_room,fraction=self.capital_policy.fraction,
            max_contracts=self.risk.max_contracts,
            rule='min400/source/day/EOD/quarter(EODroom-600); full stop and independent range TP unchanged',
            protected_room_is_entry_sizing_reserve=True,losses_can_exceed_planned_risk_on_gaps=True)
        return r
