"""Past-trained nonlinear selection of original protected2R source candidates."""
from datetime import datetime,timedelta
import hashlib,json,math
import numpy as np
from .market import CT
from .mgc_native_model import FEATURES
from .mgc_day_precision import DAY_FEATURES
from .mgc_exit_precision import ExitPrecisionMgc

TRADE_FEATURES=tuple(FEATURES)+tuple('day_'+f for f in DAY_FEATURES)
POLICIES=('protected_control','tree_with_day','forest_with_day','forest_only')

def trade_features(payload,day,stamp):
    if datetime.fromisoformat(day['available_at'])>stamp:raise ValueError('Future day features')
    x=list(payload['features'])+list(day['features'])
    if len(x)!=len(TRADE_FEATURES) or not all(math.isfinite(v) for v in x):raise ValueError('Invalid trade features')
    return x

def tree_dict(estimator):
    t=estimator.tree_
    return {'left':t.children_left.tolist(),'right':t.children_right.tolist(),'feature':t.feature.tolist(),
            'threshold':t.threshold.tolist(),'value':t.value.reshape(-1).tolist(),'seed':int(estimator.random_state)}

def fit_trade(rows,available,kind):
    from sklearn.tree import DecisionTreeRegressor
    from sklearn.ensemble import RandomForestRegressor
    cutoff=datetime.fromisoformat(available).replace(tzinfo=CT)-timedelta(hours=7)
    if len(rows)<60 or any(datetime.fromisoformat(r['exit_time'])>=cutoff for r in rows):raise ValueError('Insufficient or future training outcomes')
    x=np.asarray([r['features'] for r in rows]);y=np.asarray([r['net_r'] for r in rows])
    if x.shape!=(len(rows),len(TRADE_FEATURES)) or not np.isfinite(x).all() or not np.isfinite(y).all():raise ValueError('Invalid training data')
    common={'min_samples_leaf':30,'random_state':7193}
    if kind=='tree':
        fitted=DecisionTreeRegressor(max_depth=2,**common).fit(x,y);trees=[tree_dict(fitted)]
        params=common|{'max_depth':2}
    elif kind=='forest':
        params=common|{'n_estimators':128,'max_depth':3,'max_features':.7,'bootstrap':True,'n_jobs':1}
        fitted=RandomForestRegressor(**params).fit(x,y);trees=[tree_dict(t) for t in fitted.estimators_]
    else:raise ValueError('Unregistered trade model')
    model={'kind':kind,'params':params,'features':TRADE_FEATURES,'trees':trees,'training_rows':len(rows),
        'training_sessions':len(set(r['session'] for r in rows)),'available_from_session':available,
        'last_label_exit':max(r['exit_time'] for r in rows),'input_precision':'float32, matching sklearn tree inference',
        'label':'Isolated protected2R realized net / initial cost-inclusive planned risk'}
    model['sha256']=hashlib.sha256(json.dumps(model,sort_keys=True).encode()).hexdigest()
    # JSON traversal must match the fitted model, including float32 threshold semantics.
    assert np.allclose([trade_score(model,v) for v in x],fitted.predict(x),rtol=1e-10,atol=1e-10)
    return model

def trade_score(model,features):
    x=np.asarray(features,dtype=np.float32)
    if len(x)!=len(model['features']) or not np.isfinite(x).all():raise ValueError('Invalid scoring features')
    predictions=[]
    for t in model['trees']:
        i=0
        while t['left'][i]!=-1:i=t['left'][i] if float(x[t['feature'][i]])<=t['threshold'][i] else t['right'][i]
        predictions.append(t['value'][i])
    return sum(predictions)/len(predictions)

class TradeSelectionMgc(ExitPrecisionMgc):
    def __init__(self,*args,trade_policy,trade_models,models,features,**kwargs):
        if trade_policy not in POLICIES:raise ValueError('Unregistered trade policy')
        super().__init__(*args,exit_policy='day_tree_protect2r',models=[] if trade_policy=='forest_only' else models,
                         features=features,**kwargs)
        self.trade_policy=trade_policy;self.trade_models=sorted(trade_models,key=lambda m:m['available_from_session'])
        self.trade_decisions=[]

    def entry_payloads(self,stamp):
        source=super().entry_payloads(stamp)
        if self.trade_policy=='protected_control':return source
        allowed=[]
        for p in source:
            available=[m for m in self.trade_models if m['available_from_session']<=p['session_date']]
            m=available[-1] if available else None;day=self.daily_features.get(p['session_date']);score=None
            accepted=m is None
            if m is not None and day is not None:
                if datetime.fromisoformat(m['last_label_exit'])>=stamp:raise ValueError('Future trade label')
                score=trade_score(m,trade_features(p,day,stamp));accepted=score>0
            self.trade_decisions.append({'signal_time':stamp.isoformat(),'session':p['session_date'],'family':p['event_family'],
                'accepted':accepted,'expected_net_r':score,'model_sha256':m['sha256'] if m else None})
            if accepted:allowed.append(p)
            else:self.rejections['trade_model_nonpositive_or_missing_context']+=1
        return allowed

    def report(self):
        r=super().report();r['trade_selection']={'policy':self.trade_policy,'model_schedule':[
            {k:m[k] for k in ['kind','sha256','available_from_session','training_rows','training_sessions','last_label_exit']} for m in self.trade_models],
            'decision_rows':len(self.trade_decisions),'gate':'expected_netR>0; original entries preserved before first model'}
        return r
