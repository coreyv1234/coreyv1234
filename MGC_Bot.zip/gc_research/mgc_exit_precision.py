"""Fixed staged-exit experiments on frozen past-trained day gates; offline only."""
from collections import deque
from .mgc_day_precision import DayPrecisionMgc
from .targets import TargetPlanner,TargetDecision

POLICIES=('original_control','day_tree_control','day_tree_partial2r',
          'day_tree_protect2r','day_tree_swing3r')

class ExitPrecisionMgc(DayPrecisionMgc):
    def __init__(self,*args,exit_policy,models,**kwargs):
        if exit_policy not in POLICIES:raise ValueError('Unregistered exit policy')
        super().__init__(*args,models=[] if exit_policy=='original_control' else models,**kwargs)
        self.exit_policy=exit_policy;self.entry_bars=deque(maxlen=3)

    def __call__(self,ctx):
        r=3 if self.exit_policy=='day_tree_swing3r' else 2
        target,reward=TargetPlanner.net_target(ctx,r)
        return TargetDecision(True,'fixed_exit_net_'+str(r)+'r',target,r,reward,reward/ctx.planned_risk)

    def open_position(self,signal,bar):
        p=super().open_position(signal,bar)
        if p is not None:
            self.entry_bars.clear()
            if self.exit_policy in ('day_tree_partial2r','day_tree_swing3r'):
                self.scale_state.partial_quantity=p.quantity//2
        return p

    def on_bar(self,bar):
        p=self.position
        if p is None:return
        self.entry_bars.append(bar)
        if self.exit_policy not in ('day_tree_protect2r','day_tree_swing3r'):return
        d=p.signal.direction;charges=self.risk.commission_round_trip+self.risk.slippage_ticks_per_side
        close_net=d*(bar.close-p.entry)*10-charges
        if close_net<p.planned_risk/self.scale_state.original_quantity-1e-8:return
        if self.exit_policy=='day_tree_protect2r':
            candidate=self.instrument.price(p.entry+d*charges/10,up=d==1)
        else:
            if len(self.entry_bars)<3 or not self.scale_state.partial_done:return
            raw=(min(b.low for b in self.entry_bars)-.1 if d==1 else max(b.high for b in self.entry_bars)+.1)
            candidate=self.instrument.price(raw,up=d==-1)
        proposed=max(p.stop,candidate) if d==1 else min(p.stop,candidate)
        if d*(proposed-p.stop)>1e-8 and d*(bar.close-proposed)>=.1-1e-8:
            self.stop_updates.append({'entry_time':p.entry_time.isoformat(),'bar_end':bar.time.isoformat(),
                'previous_stop':p.stop,'new_stop':proposed,'effective_after_this_bar':True,
                'policy':self.exit_policy,'inputs_end':bar.time.isoformat()})
            p.stop=proposed

    def report(self):
        r=super().report();r['fixed_exit_policy']=self.exit_policy
        r['scaleout']['runner_net_r']=3 if self.exit_policy=='day_tree_swing3r' else 2
        r['native_target_style']='fixed_exit_precision';r['stop_amendments']=len(self.stop_updates)
        r['v126_corrected']['timer_active']=False
        return r
