"""Whole-GC 1R scale-out research, with aggregate trade and fee accounting."""
from __future__ import annotations

from dataclasses import dataclass, replace

from .backtest import Backtest
from .market import MINUTE
from .targets import TargetPlanner


class ScaleTargetPlanner:
    """One GC exits fully at 1R; multi-GC leaves a net-2R/3R runner."""
    def __init__(self, runner):
        if runner not in (2, 3):
            raise ValueError('scale-out runner must be 2R or 3R')
        self.runner = runner

    def on_bar(self, bar):
        pass

    def __call__(self, ctx):
        multiple = 1 if ctx.quantity == 1 else self.runner
        return TargetPlanner('net_'+str(multiple)+'r')(ctx)


@dataclass
class ScaleState:
    original_quantity: int
    partial_quantity: int
    partial_target: float
    partial_done: bool = False
    partial_gross: float = 0.
    partial_fees: float = 0.


class ScaleOutBacktest(Backtest):
    """No order interface. Original stop wins an ambiguous partial/stop bar.

    At a known favorable opening gap, partial/final limits precede later bar
    extremes. After an intrabar partial, any remaining adverse ambiguity is
    resolved conservatively. Partial executions are not separate winning trades.
    """
    def __init__(self, root, strategy, risk, *, runner=2, entry_policy=None):
        if root != 'GC':
            raise ValueError('this scale-out study supports GC only')
        super().__init__(root, strategy, risk, entry_policy=entry_policy,
                         target_policy=ScaleTargetPlanner(runner))
        self.scale_state = None
        self.partial_executions = []
        self.runner_executions = []
        self.runner = runner
        self.one_contract_fallback_entries = 0

    def open_position(self, signal, bar):
        position = super().open_position(signal, bar)
        if position is None:
            return None
        ctx = self.last_entry_context
        partial_target, _ = TargetPlanner.net_target(ctx, 1)
        self.scale_state = ScaleState(position.quantity, position.quantity//2, partial_target)
        if position.quantity == 1:
            self.one_contract_fallback_entries += 1
        return position

    def close_position(self, raw_price, stamp, reason, *, limit=False, ambiguous=False):
        state = self.scale_state
        super().close_position(raw_price, stamp, reason, limit=limit, ambiguous=ambiguous)
        if state is not None:
            last = self.trades[-1]
            self.runner_executions.append({'session': last.session, 'entry_time': last.entry_time,
                'time_label': last.exit_time, 'quantity': last.quantity, 'price': last.exit,
                'gross_pnl': last.gross_pnl, 'fees': last.fees, 'net_pnl': last.net_pnl,
                'reason': last.reason})
            gross = last.gross_pnl+state.partial_gross
            average_exit = (last.entry+last.direction*gross/(self.instrument.point_value*state.original_quantity)
                            if state.partial_done else last.exit)
            self.trades[-1] = replace(last, quantity=state.original_quantity,
                exit=average_exit, gross_pnl=gross,
                fees=last.fees+state.partial_fees,
                net_pnl=last.net_pnl+state.partial_gross-state.partial_fees)
        self.scale_state = None

    def fill_partial(self, bar, opening_gap):
        p, state, inst, risk = self.position, self.scale_state, self.instrument, self.risk
        quantity = state.partial_quantity
        price = state.partial_target  # Conservative limit price, no gap improvement.
        gross = (price-p.entry)*p.signal.direction*inst.point_value*quantity
        fees = risk.commission_round_trip*quantity
        self.balance += gross-fees
        if (risk.daily_profit_target is not None and
                self.balance-self.session_open >= risk.daily_profit_target-1e-8):
            self.profit_locked_sessions.add(bar.session)
        state.partial_done = True; state.partial_gross = gross; state.partial_fees = fees
        p.quantity -= quantity
        equity = self.balance+((price-p.entry)*p.signal.direction*inst.point_value
                              -risk.commission_round_trip
                              -risk.slippage_ticks_per_side*inst.tick_size*inst.point_value)*p.quantity
        self.check_equity(equity)
        # This event price is known; exact intrabar time is not available.
        stamp = bar.time-MINUTE if opening_gap else bar.time
        self.equity_curve.append((stamp.isoformat(), equity))
        self.partial_executions.append({'session': bar.session,
            'entry_time': p.entry_time.isoformat(), 'bar_end': bar.time.isoformat(),
            'time_label': stamp.isoformat(), 'timing': 'opening_gap' if opening_gap else 'intrabar_time_unknown',
            'direction': p.signal.direction, 'quantity': quantity, 'remaining_quantity': p.quantity,
            'price': price, 'gross_pnl': gross, 'fees': fees, 'net_pnl': gross-fees,
            'initial_position_risk': p.planned_risk, 'marked_equity_at_partial': equity})

    def manage(self, bar):
        p, state = self.position, self.scale_state
        if p is None or state is None or state.partial_done or state.partial_quantity == 0:
            return super().manage(bar)
        d, inst, risk = p.signal.direction, self.instrument, self.risk
        adverse = self.balance+((bar.low if d == 1 else bar.high)-p.entry)*d*inst.point_value*p.quantity
        adverse -= (risk.commission_round_trip+risk.slippage_ticks_per_side*inst.tick_size*inst.point_value)*p.quantity
        self.max_adverse_drawdown = max(self.max_adverse_drawdown, self.peak-adverse)
        floor = max(self.account_stop_floor(),
                    self.session_open-risk.daily_loss_limit+risk.drawdown_reserve)
        charges = (risk.commission_round_trip+ risk.slippage_ticks_per_side*inst.tick_size*inst.point_value)*p.quantity
        distance = max(0., self.balance-floor-charges)/(inst.point_value*p.quantity)
        risk_stop = inst.price(p.entry-d*distance, up=d == 1)
        stop = max(p.stop, risk_stop) if d == 1 else min(p.stop, risk_stop)
        stop_gap = bar.open <= stop if d == 1 else bar.open >= stop
        through = risk.target_trade_through_ticks*inst.tick_size
        partial_gap = bar.open >= state.partial_target+through if d == 1 else bar.open <= state.partial_target-through
        stop_hit = bar.low <= stop if d == 1 else bar.high >= stop
        partial_hit = bar.high >= state.partial_target+through if d == 1 else bar.low <= state.partial_target-through
        if stop_gap:
            return super().manage(bar)
        if partial_gap:
            self.fill_partial(bar, True)
            return super().manage(bar)
        if stop_hit:
            return super().manage(bar)
        if partial_hit:
            price = state.partial_target
            self.fill_partial(bar, False)
            # New risk state applies after the known partial crossing, never at
            # the original bar open. Retain extremes as adverse ambiguity bounds.
            return super().manage(replace(bar, open=price))
        return super().manage(bar)

    def report(self):
        report = super().report()
        report['scaleout'] = {'runner_net_r': self.runner,
            'partial_executions': len(self.partial_executions),
            'partial_contracts': sum(p['quantity'] for p in self.partial_executions),
            'one_contract_full_1r_fallback_entries': self.one_contract_fallback_entries,
            'partial_net_is_in_aggregate_trade_pnl': True,
            'aggregate_exit_price': 'Quantity-weighted average across partial and final fills; target is the runner target.',
            'peak_accounting': 'Minute closes plus marked liquidation equity at known partial-limit price events; exact intrabar fill times remain unknown.'}
        return report
