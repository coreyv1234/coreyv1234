"""Offline source-cap sizing attribution; no order adapter or live default."""
from dataclasses import replace,asdict
import hashlib,math
from .backtest import Position
from .decisions import EntryContext
from .market import CT,MINUTE
from .mgc_range_pullback import PendingLimit
from .mgc_confirmed_pullback import POLICIES
from .mgc_secondary_early02 import SecondaryEarly02Mgc
from .scaleout import ScaleState
from .strategy import Signal

class NativeScaleMgc(SecondaryEarly02Mgc):
    def __init__(self,risk,payloads,**kwargs):
        if risk.risk_per_trade not in (400,600,800) or risk.max_contracts!=10:
            raise ValueError('Only preregistered400/600/800 withmax10')
        super().__init__(replace(risk,risk_per_trade=400),payloads,**kwargs)
        self.risk=risk

    def _place_scaled_proposal(self, b):
        """Uses only the just-completed source and already known account state."""
        if not self._eligible_source(b):
            return None
        stamp = b.time
        if not self.structure_history or self.structure_history[-1].time != stamp:
            raise ValueError('Source-time target history must end at source close')
        if any(v.time > stamp for v in self.structure_history):
            raise ValueError('Future source-time target history')
        for source in self.entry_payloads(stamp):
            family = source['event_family']
            if source['session_date'] != b.session:
                raise ValueError('Wrong canonical source session')
            if family.startswith('ADDON_') and self.session_count >= 4:
                continue
            d = 1 if source['direction'] == 'LONG' else -1
            atr = float(source['atr'])
            if not math.isfinite(atr) or atr <= 0:
                raise ValueError('Invalid canonical source ATR')
            # Round away from the market: buy down, sell up. Never cross.
            entry = self.instrument.price(float(source['signal_close'])-d*.25*atr, up=d == -1)
            raw = float(source['invalidation_price'])
            distance = d*(entry-raw)
            if distance <= 0:
                self.rejections['source_invalidation_already_passed'] += 1
                continue
            floor = .42 if family.startswith(('SCALP_', 'ADDON_')) else .62 if not family.startswith('PROBE_') else 0.
            stop = self.instrument.price(entry-d*max(distance, floor*atr, 1.2), up=d == -1)
            self.family_cap = min(self.risk.risk_per_trade, float(source['risk_budget_dollars']))
            budget = self.risk_budget()
            charges = self.risk.commission_round_trip+self.risk.slippage_ticks_per_side*self.instrument.tick_size*self.instrument.point_value
            per = d*(entry-stop)*self.instrument.point_value+charges
            quantity = min(self.risk.max_contracts, int((budget+1e-8)//per))
            if quantity < 1:
                self.rejections['insufficient_risk_budget'] += 1
                continue
            planned = per*quantity
            signal = Signal(stamp, b.instrument, d, family, float(source['signal_close']), stop, atr)
            ctx = EntryContext(signal, stamp, entry, stop, entry, quantity, planned,
                self.risk.commission_round_trip, self.risk.slippage_ticks_per_side*self.instrument.tick_size,
                None, None, None, None)
            decision = self(ctx)
            self.target_decisions.append(dict(signal_time=stamp.isoformat(), entry_time=stamp.isoformat(),
                direction=d, quantity=quantity, entry=entry, stop=stop, planned_risk=planned,
                committed_at_source_close=True, **asdict(decision)))
            if not decision.accepted:
                self.rejections[decision.reason] += 1
                continue
            target = decision.target
            if target is None or not math.isfinite(target) or d*(target-entry) <= 0:
                raise ValueError('Invalid independently calculated target')
            noon = stamp.astimezone(CT).replace(hour=12, minute=0, second=0, microsecond=0)
            expiry = min(stamp+3*MINUTE, noon.astimezone(stamp.tzinfo))
            ident = hashlib.sha256(f'{stamp.isoformat()}|{b.instrument}|{family}|{d}'.encode()).hexdigest()[:32]
            order = PendingLimit(ident, signal, expiry, entry, stop, target, quantity, planned,
                self.balance, self.trailing_peak, float(source['risk_budget_dollars']), budget)
            self.limit_order = order
            self.orders.append(dict(order_id=ident, source_time=stamp.isoformat(), session=b.session,
                instrument=b.instrument, family=family, direction=d, expiry=expiry.isoformat(),
                limit=entry, stop=stop, target=target, quantity=quantity, planned_risk=planned,
                source_budget=order.source_budget, budget_ceiling=budget, cash_at_source=self.balance,
                session_open_at_source=self.session_open, highwater_at_source=self.trailing_peak,
                target_inputs_end=self.structure_history[-1].time.isoformat(), status='working'))
            self.order_events.append(dict(order_id=ident, time=stamp.isoformat(), event='placed'))
            return order
        return None

    def place_limit(self, b):
        # The ancestor constructs a source-time proposal, not a resting order.
        order = self._place_scaled_proposal(b)
        if order is None:
            return None
        noon = b.time.astimezone(CT).replace(hour=12, minute=0, second=0, microsecond=0)
        deadline = min(b.time+POLICIES[self.confirmation_policy]*MINUTE, noon.astimezone(b.time.tzinfo))
        self.limit_order = replace(order, expiry=deadline)
        self.confirmation_deadline = deadline
        self.touch_time = self.confirmation_time = None
        self.orders[-1].update(expiry=deadline.isoformat(), order_type='unsubmitted_confirmation_idea',
            confirmation_policy=self.confirmation_policy)
        return self.limit_order

    def fill_limit(self, b):
        order = self.limit_order
        if order is None:
            return b
        if b.time <= order.signal.time:
            raise ValueError('Cannot use source candle for confirmation')
        if b.instrument != order.signal.instrument or b.session != self.orders[-1]['session']:
            self.cancel_limit(b.time-MINUTE, 'contract_or_session_boundary')
            return b
        d, tick = order.signal.direction, self.instrument.tick_size
        if self.confirmation_time is not None:
            stamp = b.time-MINUTE
            if stamp != self.confirmation_time:
                self.cancel_limit(stamp, 'missing_immediate_entry_bar')
                return b
            local = stamp.astimezone(CT)
            if not self.risk.entry_start_ct <= local.hour*60+local.minute < self.risk.entry_end_ct:
                self.cancel_limit(stamp, 'entry_outside_session')
                return b
            slip = self.risk.slippage_ticks_per_side*tick
            entry = self.instrument.price(b.open+d*slip, up=d == 1)
            # Both the actual quote and the slipped fill must preserve bracket.
            if d*(b.open-order.stop) <= 0 or d*(order.target-b.open) <= 0 or d*(entry-order.stop) <= 0 or d*(order.target-entry) <= 0:
                self.cancel_limit(stamp, 'entry_gap_invalidates_bracket')
                return b
            if d*(order.target-entry)*self.instrument.point_value <= self.risk.commission_round_trip:
                self.cancel_limit(stamp, 'entry_target_net_nonpositive')
                return b
            self.family_cap = min(self.risk.risk_per_trade, order.source_budget)
            budget = min(order.budget_ceiling, self.risk_budget())
            per = d*(entry-order.stop)*self.instrument.point_value+self.risk.commission_round_trip+slip*self.instrument.point_value
            quantity = min(order.quantity, self.risk.max_contracts, int((budget+1e-8)//per))
            locked = self.risk.daily_profit_target is not None and self.balance-self.session_open >= self.risk.daily_profit_target-1e-8
            if quantity < 1 or self.halted or self.daily_halted or locked or not self.entry_guard(b):
                self.cancel_limit(stamp, 'entry_account_or_risk_rejected')
                return b
            self.position = Position(order.signal, stamp, entry, order.stop, order.target, quantity, per*quantity)
            self.initial_stop = order.stop
            self.scale_state = ScaleState(quantity, 0, order.target)
            self.entry_bars.clear()
            self.session_count += 1
            if quantity == 1:
                self.one_contract_fallback_entries += 1
            row = dict(order_id=order.order_id, source_time=order.signal.time.isoformat(),
                touch_time=self.touch_time.isoformat(), confirmation_time=self.confirmation_time.isoformat(),
                fill_time=stamp.isoformat(), fill_bar_end=b.time.isoformat(), entry_timing='next_open_after_closed_reclaim',
                raw_open=b.open, entry=entry, stop=order.stop, target=order.target, quantity=quantity,
                planned_risk=per*quantity, source_quantity=order.quantity, source_limit=order.limit,
                budget_at_entry=budget, favorable_extreme_censored=False,
                full_observed_high=b.high, full_observed_low=b.low)
            self.fills.append(row)
            self.trade_timing[(order.signal.time.isoformat(), stamp.isoformat())] = row
            self.orders[-1].update(status='filled', fill_time=stamp.isoformat(), fill_bar_end=b.time.isoformat(),
                confirmation_time=self.confirmation_time.isoformat(), touch_time=self.touch_time.isoformat())
            self.order_events.append(dict(order_id=order.order_id, time=stamp.isoformat(), event='confirmed_market_entry'))
            self.limit_order = None
            return b
        if b.time > self.confirmation_deadline:
            self.cancel_limit(self.confirmation_deadline, 'expired')
            return b
        stopped = b.low <= order.stop if d == 1 else b.high >= order.stop
        target_seen = b.high >= order.target if d == 1 else b.low <= order.target
        if stopped or target_seen:
            self.cancel_limit(b.time, 'waiting_stop_invalidated' if stopped else 'waiting_target_already_reached')
            return b
        touched = b.low <= order.limit-tick+1e-8 if d == 1 else b.high >= order.limit+tick-1e-8
        if touched and self.touch_time is None:
            self.touch_time = b.time
        reclaimed = d*(b.close-order.limit) >= tick-1e-8
        local = b.time.astimezone(CT)
        confirmed = self.touch_time is not None and reclaimed and local.hour*60+local.minute < self.risk.entry_end_ct
        self.confirmation_events.append(dict(order_id=order.order_id, bar_end=b.time.isoformat(),
            touched=touched, touch_time=self.touch_time.isoformat() if self.touch_time else None,
            close=b.close, reclaimed=reclaimed, confirmed=confirmed))
        if confirmed:
            self.confirmation_time = b.time
            # Parent expiration runs after this hook. Retain only the immediate
            # next bar for execution, including reclaim on the final wait bar.
            self.limit_order = replace(order, expiry=b.time+MINUTE)
            self.orders[-1].update(confirmation_time=b.time.isoformat(), touch_time=self.touch_time.isoformat(),
                execution_deadline=(b.time+MINUTE).isoformat())
        return b
