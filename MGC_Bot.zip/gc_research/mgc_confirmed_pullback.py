"""Offline pullback-touch/reclaim entry; decisions only on completed bars."""
from dataclasses import replace

from .backtest import Position
from .market import CT, MINUTE
from .mgc_range_pullback import RangePullbackMgc
from .scaleout import ScaleState

POLICIES = {'confirmed_pullback3': 3, 'confirmed_pullback6': 6}


class ConfirmedPullbackMgc(RangePullbackMgc):
    def __init__(self, *args, confirmation_policy, **kwargs):
        if confirmation_policy not in POLICIES:
            raise ValueError('Unknown fixed confirmation policy')
        super().__init__(*args, **kwargs)
        self.confirmation_policy = confirmation_policy
        self.touch_time = None
        self.confirmation_time = None
        self.confirmation_deadline = None
        self.confirmation_events = []

    def place_limit(self, b):
        # The ancestor constructs a source-time proposal, not a resting order.
        order = super().place_limit(b)
        if order is None:
            return None
        noon = b.time.astimezone(CT).replace(hour=12, minute=0, second=0, microsecond=0)
        deadline = min(b.time+POLICIES[self.confirmation_policy]*MINUTE, noon.astimezone(b.time.tzinfo))
        self.limit_order = replace(order, expiry=deadline)
        self.confirmation_deadline = deadline
        self.touch_time = self.confirmation_time = None
        self.orders[-1].update(expiry=deadline.isoformat(), order_type='unsubmitted_confirmation_idea',
            confirmation_policy=self.confirmation_policy)
        return self.limit_order

    def fill_limit(self, b):
        order = self.limit_order
        if order is None:
            return b
        if b.time <= order.signal.time:
            raise ValueError('Cannot use source candle for confirmation')
        if b.instrument != order.signal.instrument or b.session != self.orders[-1]['session']:
            self.cancel_limit(b.time-MINUTE, 'contract_or_session_boundary')
            return b
        d, tick = order.signal.direction, self.instrument.tick_size
        if self.confirmation_time is not None:
            stamp = b.time-MINUTE
            if stamp != self.confirmation_time:
                self.cancel_limit(stamp, 'missing_immediate_entry_bar')
                return b
            local = stamp.astimezone(CT)
            if not self.risk.entry_start_ct <= local.hour*60+local.minute < self.risk.entry_end_ct:
                self.cancel_limit(stamp, 'entry_outside_session')
                return b
            slip = self.risk.slippage_ticks_per_side*tick
            entry = self.instrument.price(b.open+d*slip, up=d == 1)
            # Both the actual quote and the slipped fill must preserve bracket.
            if d*(b.open-order.stop) <= 0 or d*(order.target-b.open) <= 0 or d*(entry-order.stop) <= 0 or d*(order.target-entry) <= 0:
                self.cancel_limit(stamp, 'entry_gap_invalidates_bracket')
                return b
            if d*(order.target-entry)*self.instrument.point_value <= self.risk.commission_round_trip:
                self.cancel_limit(stamp, 'entry_target_net_nonpositive')
                return b
            self.family_cap = min(400., order.source_budget)
            budget = min(order.budget_ceiling, self.risk_budget())
            per = d*(entry-order.stop)*self.instrument.point_value+self.risk.commission_round_trip+slip*self.instrument.point_value
            quantity = min(order.quantity, self.risk.max_contracts, int((budget+1e-8)//per))
            locked = self.risk.daily_profit_target is not None and self.balance-self.session_open >= self.risk.daily_profit_target-1e-8
            if quantity < 1 or self.halted or self.daily_halted or locked or not self.entry_guard(b):
                self.cancel_limit(stamp, 'entry_account_or_risk_rejected')
                return b
            self.position = Position(order.signal, stamp, entry, order.stop, order.target, quantity, per*quantity)
            self.initial_stop = order.stop
            self.scale_state = ScaleState(quantity, 0, order.target)
            self.entry_bars.clear()
            self.session_count += 1
            if quantity == 1:
                self.one_contract_fallback_entries += 1
            row = dict(order_id=order.order_id, source_time=order.signal.time.isoformat(),
                touch_time=self.touch_time.isoformat(), confirmation_time=self.confirmation_time.isoformat(),
                fill_time=stamp.isoformat(), fill_bar_end=b.time.isoformat(), entry_timing='next_open_after_closed_reclaim',
                raw_open=b.open, entry=entry, stop=order.stop, target=order.target, quantity=quantity,
                planned_risk=per*quantity, source_quantity=order.quantity, source_limit=order.limit,
                budget_at_entry=budget, favorable_extreme_censored=False,
                full_observed_high=b.high, full_observed_low=b.low)
            self.fills.append(row)
            self.trade_timing[(order.signal.time.isoformat(), stamp.isoformat())] = row
            self.orders[-1].update(status='filled', fill_time=stamp.isoformat(), fill_bar_end=b.time.isoformat(),
                confirmation_time=self.confirmation_time.isoformat(), touch_time=self.touch_time.isoformat())
            self.order_events.append(dict(order_id=order.order_id, time=stamp.isoformat(), event='confirmed_market_entry'))
            self.limit_order = None
            return b
        if b.time > self.confirmation_deadline:
            self.cancel_limit(self.confirmation_deadline, 'expired')
            return b
        stopped = b.low <= order.stop if d == 1 else b.high >= order.stop
        target_seen = b.high >= order.target if d == 1 else b.low <= order.target
        if stopped or target_seen:
            self.cancel_limit(b.time, 'waiting_stop_invalidated' if stopped else 'waiting_target_already_reached')
            return b
        touched = b.low <= order.limit-tick+1e-8 if d == 1 else b.high >= order.limit+tick-1e-8
        if touched and self.touch_time is None:
            self.touch_time = b.time
        reclaimed = d*(b.close-order.limit) >= tick-1e-8
        local = b.time.astimezone(CT)
        confirmed = self.touch_time is not None and reclaimed and local.hour*60+local.minute < self.risk.entry_end_ct
        self.confirmation_events.append(dict(order_id=order.order_id, bar_end=b.time.isoformat(),
            touched=touched, touch_time=self.touch_time.isoformat() if self.touch_time else None,
            close=b.close, reclaimed=reclaimed, confirmed=confirmed))
        if confirmed:
            self.confirmation_time = b.time
            # Parent expiration runs after this hook. Retain only the immediate
            # next bar for execution, including reclaim on the final wait bar.
            self.limit_order = replace(order, expiry=b.time+MINUTE)
            self.orders[-1].update(confirmation_time=b.time.isoformat(), touch_time=self.touch_time.isoformat(),
                execution_deadline=(b.time+MINUTE).isoformat())
        return b

    def report(self):
        r = super().report()
        r['confirmed_pullback'] = dict(policy=self.confirmation_policy, events=len(self.confirmation_events),
            native_adapter=False, source_bracket_fixed=True, actual_open_quantity_can_only_decrease=True)
        r['passive_pullback'].update(policy=self.confirmation_policy, limit_cannot_slip=False,
            contract_and_bracket_committed_at_source=False, fill_bar_favorable_extreme_censored=False,
            intrabar_fill_time_exact=False,
            note='Source proposals are unsubmitted ideas. Market fills modeled next open after closed reclaim; original bracket retained.')
        return r
