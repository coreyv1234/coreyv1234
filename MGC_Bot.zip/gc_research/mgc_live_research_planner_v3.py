"""Actual-position identity and execution-time checks; strategy math unchanged."""
from dataclasses import replace
from .mgc_live_research_planner import LiveResearchPlanner
from .mgc_sim_execution_v3 import BridgeError,healthy_state


class LiveResearchPlannerV3(LiveResearchPlanner):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.native_model_id=None

    def synchronize(self,state):
        if state['entry_executed']-state['exit_executed']!=state['quantity']:
            raise BridgeError('Cannot adopt inconsistent native execution counts')
        if state['quantity']:
            if state['active_id']!=self.native_model_id or self.native_signal is None:
                raise BridgeError('Native position identity does not match submitted source')
            if state['direction']!=self.native_signal.direction or state['instrument']!=self.native_signal.instrument:
                raise BridgeError('Native position direction/expiry does not match submitted source')
        super().synchronize(state)
        if self.position is not None:
            self.native_entry_time=state['first_fill_utc']
            self.position=replace(self.position,entry_time=state['first_fill_utc'])

    def on_bar(self,bar):
        position=self.position
        if position is not None and bar.time<=position.entry_time:
            self.position=None
            try:return super().on_bar(bar)
            finally:self.position=position
        return super().on_bar(bar)

    def prepare_entry(self,state,now,config):
        healthy_state(state,now,config)
        if state['pending_exit_callbacks']:return None
        row=super().prepare_entry(state,now,config)
        if row is not None:
            row['version']=3
            self.native_model_id=row['model_id']
        return row
