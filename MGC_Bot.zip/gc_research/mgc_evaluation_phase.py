"""Phase-aware entry combination; source-close cash only, offline research."""
from .mgc_evaluation_stage import EvaluationStageMgc


class EvaluationPhaseMgc(EvaluationStageMgc):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        if self.entry_policy!='confirmed':
            raise ValueError('Phase arm starts with confirmed entries')
        self.phase_entry_events=[]

    def place_limit(self,bar):
        cushion=self.balance-self.account_stop_floor()
        required=4*self.risk.risk_per_trade
        accelerate=self.unlimited_stage and cushion>=required-1e-8
        original=self.entry_policy
        self.entry_policy='scalp_next_open' if accelerate else 'confirmed'
        try:
            order=super().place_limit(bar)
            if order is not None:
                self.phase_entry_events.append(dict(order_id=order.order_id,source_time=bar.time.isoformat(),
                    selected_policy=self.entry_policy,unlimited_stage=self.unlimited_stage,
                    settled_cash=self.balance,account_stop_floor=self.account_stop_floor(),
                    reserved_cushion=cushion,required_cushion=required))
            return order
        finally:
            self.entry_policy=original

    def fill_limit(self,bar):
        result=super().fill_limit(bar)
        if self.position is not None and self.fills and self.fills[-1]['fill_bar_end']==bar.time.isoformat():
            row=self.fills[-1]
            row['entry_policy']='source_next_open' if row['source_time']==row['confirmation_time'] else 'confirmed'
        return result
