"""Regularized past-only expected-net-R veto and fixed native MGC targets."""
from datetime import datetime,timedelta
import math,json,hashlib
import numpy as np
from .mgc_v126_replay import MgcV126Backtest
from .targets import TargetPlanner,TargetDecision
from .market import CT

STYLES=('net1_5r','net2r','partial1r_runner2r')

FEATURES=('body_signed','momentum1_signed','momentum3_signed','extension_signed',
 'ema_slope_signed','kalman_signed','vwap_distance_signed','adx','efficiency',
 'atr_ratio','yz_ratio','momentum_z_signed','range_z','variance4','variance12',
 'volume_ratio','close_location_aligned','invalidation_atr','long','hour_sin','hour_cos',
 'core','scalp','probe','addon','flow_available','flow_fraction','delta_signed','spread_ticks')

def feature_values(payload,row,flow,stamp):
    d=1 if payload['direction']=='LONG' else -1
    def value(name,lo=-5,hi=5):
        v=float(row.get(name,0));return min(hi,max(lo,v)) if math.isfinite(v) else 0.
    atr=max(float(payload['atr']),1e-9);loc=value('close_location',0,1)
    hour=stamp.tz_convert('America/Chicago').hour+stamp.tz_convert('America/Chicago').minute/60
    kind=payload['source_kind'];fraction=float(flow.get('classified_fraction',0))
    available=fraction>=.1
    out=[d*value('body_atr'),d*value('momentum1_atr'),d*value('momentum3_atr'),d*value('extension_atr'),
        d*value('ema20_slope6_atr'),d*value('kalman_slope_atr'),d*value('distance_vwap_atr'),value('adx14',0,100)/100,
        value('efficiency20',0,1),value('atr_ratio100',0,5),value('yz_vol_ratio100',0,5),d*value('robust_momentum_z60'),
        value('robust_range_z60'),value('variance_ratio4',0,5),value('variance_ratio12',0,5),value('volume_ratio20',0,5),
        loc if d==1 else 1-loc,min(10,abs(float(payload['signal_close'])-float(payload['invalidation_price']))/atr),
        int(d==1),math.sin(hour*2*math.pi/24),math.cos(hour*2*math.pi/24),
        *[int(kind==v) for v in ('core','scalp','probe','addon')],int(available),fraction,
        d*float(flow.get('delta_fraction',0)) if available else 0.,
        min(50,float(flow.get('spread_ticks',0))) if available else 0.]
    assert len(out)==len(FEATURES) and all(math.isfinite(v) for v in out)
    return out

def fit_model(rows,available_from):
    from sklearn.preprocessing import StandardScaler
    from sklearn.linear_model import Ridge
    if len(rows)<30:raise ValueError('Insufficient chronological training labels')
    cutoff=datetime.fromisoformat(available_from).replace(tzinfo=CT)-timedelta(hours=7)
    if any(datetime.fromisoformat(r['exit_time'])>=cutoff for r in rows):
        raise ValueError('Training labels must be complete before the model session opens')
    x=np.array([r['features'] for r in rows]);y=np.array([r['net_r'] for r in rows])
    scale=StandardScaler().fit(x);model=Ridge(alpha=100).fit(scale.transform(x),y)
    out={'kind':'standardized_ridge_expected_net_r','alpha':100,'features':FEATURES,
        'mean':scale.mean_.tolist(),'scale':scale.scale_.tolist(),'weights':model.coef_.tolist(),'intercept':float(model.intercept_),
        'available_from_session':available_from,'training_rows':len(rows),
        'last_label_exit':max(r['exit_time'] for r in rows),'label':'Isolated cost-inclusive realized netR; no account PnL in input features.'}
    out['sha256']=hashlib.sha256(json.dumps(out,sort_keys=True).encode()).hexdigest()
    return out

def predict(model,features):
    return model['intercept']+sum(w*(v-m)/s for w,v,m,s in zip(model['weights'],features,model['mean'],model['scale']))

class NativeMgcReplay(MgcV126Backtest):
    def __init__(self,*args,exit_style='net2r',model=None,**kwargs):
        if exit_style not in STYLES:raise ValueError('Unregistered target style')
        super().__init__(*args,plan='net2r',stop_mode='full_structure',**kwargs)
        self.exit_style=exit_style;self.model=model;self.model_decisions=[]

    def __call__(self,ctx):
        r=1.5 if self.exit_style=='net1_5r' else 2
        target,reward=TargetPlanner.net_target(ctx,r)
        return TargetDecision(True,'native_fixed_net_'+str(r)+'r',target,r,reward,reward/ctx.planned_risk)

    def entry_payloads(self,stamp):
        source=super().entry_payloads(stamp)
        if self.model is None:return source
        allowed=[]
        for p in source:
            if p['session_date']<self.model['available_from_session']:raise ValueError('Model used before chronological availability')
            if datetime.fromisoformat(self.model['last_label_exit'])>=stamp:raise ValueError('Training label overlaps decision')
            score=predict(self.model,p['features'])
            self.model_decisions.append({'signal_time':stamp.isoformat(),'family':p['event_family'],'expected_net_r':score,
                'accepted':score>0,'model_sha256':self.model['sha256']})
            if score>0:allowed.append(p)
            else:self.rejections['trained_expected_net_r_nonpositive']+=1
        return allowed

    def open_position(self,signal,bar):
        p=super().open_position(signal,bar)
        if p is not None and self.exit_style=='partial1r_runner2r':self.scale_state.partial_quantity=p.quantity//2
        return p

    def report(self):
        r=super().report();r['native_target_style']=self.exit_style
        r['learned_model']=None if self.model is None else {k:self.model[k] for k in ('sha256','training_rows','last_label_exit','available_from_session')}
        r['scaleout']['runner_net_r']=1.5 if self.exit_style=='net1_5r' else 2
        r['v126_corrected']['gap_evidence']='Exporter Last-request attestation and exact summary trade-count reconciliation; raw confirmation pending.'
        return r
