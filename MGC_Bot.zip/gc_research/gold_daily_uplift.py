"""Product-aware gold replay and causal day-level policy-improvement inputs.

The retained modules remain frozen. New GC research uses actual GC bars,
contract values and structural stops; it never relabels MGC history as GC.
No brokerage or notification interface is provided here.
"""
from collections import Counter,deque
import copy,hashlib,json,math
from datetime import datetime,timedelta

import numpy as np

from .market import CT,MINUTE,INSTRUMENTS,instrument_root
from .strategy import Signal
from .scaleout import ScaleOutBacktest
from .mgc_forest_session_target import ForestSessionTargetMgc
from .mgc_trade_selection import TRADE_FEATURES,trade_features
from .targets import TargetDecision,TargetPlanner


def setup_key(stamp,family,direction):
    phase=stamp.minute%5
    close=stamp+timedelta(minutes=5-phase) if phase else stamp
    return close,family.removesuffix('_1M_EXEC'),direction


def cash_goal_r(needed,planned,minimum):
    # Sub-cent binary representation noise must not switch a 3R cash goal to
    # the 2R fallback. The threshold remains fixed; this is numerical hygiene.
    return min(3.,needed/planned) if planned>0 and needed>minimum*planned+1e-7 and needed<=3*planned+1e-7 else 2.


class GoldSessionRuntime(ForestSessionTargetMgc):
    def __init__(self,root,risk,payloads,*,features,models=(),trade_models=(),
                 zero_trade_gaps=(),blocked_dates=(),start=None,end=None,
                 minimum_stop_points=None,minimum_goal_r=2.,deduplicate_entries=False):
        if root not in INSTRUMENTS:raise ValueError('Unsupported gold contract')
        if risk.max_contracts>(4 if root=='GC' else 10):raise ValueError('Outside authorized product contract cap')
        if not 1<=minimum_goal_r<=2:raise ValueError('Unsupported minimum cash-goal R')
        super().__init__(risk,payloads,{},features=features,models=models,trade_models=trade_models,
            zero_trade_gaps=zero_trade_gaps,blocked_dates=blocked_dates)
        self.instrument=INSTRUMENTS[root];self.root=root
        self.minimum_stop_points=minimum_stop_points if minimum_stop_points is not None else (.1 if root=='GC' else 1.2)
        if self.minimum_stop_points<.1:raise ValueError('Stop must span at least one tick')
        self.minimum_goal_r=minimum_goal_r
        self.deduplicate_entries=deduplicate_entries
        self.start,self.end=start,end;self.finished=False;self.bars_processed=0
        self.forced_time=None;self.forced_source=None;self.forced_entered=False
        self.consumed_setups=set()

    def __call__(self,ctx):
        need=max(0.,500.-(self.balance-self.session_open))
        r=cash_goal_r(need,ctx.planned_risk,self.minimum_goal_r)
        target,reward=TargetPlanner.net_target(ctx,r)
        return TargetDecision(True,'cash_goal_exact_policy',target,r,reward,reward/ctx.planned_risk)

    def entry_guard(self,bar):
        if self.forced_time==bar.time-MINUTE:return True
        return super().entry_guard(bar)

    def entry_payloads(self,stamp):
        if stamp==self.forced_time:return [self.forced_source]
        return [p for p in super().entry_payloads(stamp)
            if setup_key(stamp,p['event_family'],p['direction']) not in self.consumed_setups]

    def open_position(self,ignored,b):
        if b.session in self.blocked_dates:
            self.rejections['published_holiday_blackout']+=1;return None
        stamp=b.time-MINUTE
        for payload in self.entry_payloads(stamp):
            family=payload['event_family']
            if family.startswith('ADDON_') and self.session_count>=4:continue
            self.family_cap=min(300.,float(payload.get('risk_budget_dollars',300.)))
            self.payload=payload;d=1 if payload['direction']=='LONG' else -1
            atr=float(payload['atr']);raw=float(payload['invalidation_price'])
            entry=self.instrument.price(b.open+d*self.risk.slippage_ticks_per_side*.1,up=d==1)
            distance=d*(entry-raw)
            if distance<=0:
                self.rejections['source_invalidation_already_passed']+=1;continue
            floor=.42 if family.startswith(('SCALP_','ADDON_')) else .62 if not family.startswith('PROBE_') else 0.
            distance=max(distance,floor*atr,self.minimum_stop_points)
            stop=self.instrument.price(entry-d*distance,up=d==-1)
            signal=Signal(stamp,b.instrument,d,family,float(payload['signal_close']),stop,atr)
            before=dict(self.rejections)
            p=ScaleOutBacktest.open_position(self,signal,b)
            self.attempts.append(dict(signal_time=stamp.isoformat(),session=b.session,family=family,direction=d,
                raw_invalidation=raw,stop=stop,entry_estimate=entry,family_budget=self.family_cap,
                accepted=p is not None,quantity=p.quantity if p else 0,
                reason='entered' if p else '|'.join(k for k,v in self.rejections.items() if v>before.get(k,0))))
            if p is not None:
                self.entry_bars.clear();self.initial_stop=p.stop;self.scale_state.partial_quantity=0
                if self.deduplicate_entries:self.consumed_setups.add(setup_key(stamp,family,payload['direction']))
                if self.forced_time==stamp:
                    self.forced_entered=True
                    self.consumed_setups.add(setup_key(stamp,family,payload['direction']))
                return p
        return None

    def manage(self,b):
        p=self.position
        if p is None:return
        if self.scale_state.partial_quantity:raise RuntimeError('Daily-uplift study has no partial exits')
        adverse=self.balance+((b.low if p.signal.direction==1 else b.high)-p.entry)*p.signal.direction*self.instrument.point_value*p.quantity
        adverse-=(self.risk.commission_round_trip+self.risk.slippage_ticks_per_side*self.instrument.tick_size*self.instrument.point_value)*p.quantity
        self.max_adverse_drawdown=max(self.max_adverse_drawdown,self.peak-adverse)
        self.base_manage(b)

    def on_bar(self,b):
        p=self.position
        if p is None:return
        self.entry_bars.append(b);d=p.signal.direction
        charges=self.risk.commission_round_trip+self.risk.slippage_ticks_per_side*self.instrument.tick_size*self.instrument.point_value
        net=d*(b.close-p.entry)*self.instrument.point_value-charges
        if net<p.planned_risk/self.scale_state.original_quantity-1e-8:return
        candidate=self.instrument.price(p.entry+d*charges/self.instrument.point_value,up=d==1)
        proposed=max(p.stop,candidate) if d==1 else min(p.stop,candidate)
        if d*(proposed-p.stop)>1e-8 and d*(b.close-proposed)>=.1-1e-8:
            self.stop_updates.append(dict(entry_time=p.entry_time.isoformat(),bar_end=b.time.isoformat(),
                previous_stop=p.stop,new_stop=proposed,effective_after_this_bar=True,
                policy='day_tree_protect2r' if self.root=='MGC' else 'product_correct_cost_BE',inputs_end=b.time.isoformat()))
            p.stop=proposed

    def step(self,b):
        if self.finished:raise RuntimeError('Finalized gold replay')
        if b.time.tzinfo is None or b.time.utcoffset().total_seconds()!=0 or b.time.second or b.time.microsecond:
            raise ValueError('Expected UTC minute end')
        if instrument_root(b.instrument)!=self.root or b.instrument==self.root:raise ValueError('Wrong root or missing expiry')
        if self.previous is not None and b.time<=self.previous.time:raise ValueError('Gold replay requires strictly increasing bars')
        selected=(self.start is None or b.session>=self.start) and (self.end is None or b.session<self.end)
        gap=self.previous is not None and (b.time-self.previous.time!=MINUTE or b.instrument!=self.previous.instrument or b.session!=self.previous.session)
        if b.session!=self.session:
            self.finish_session();self.session,self.session_open=b.session,self.balance
            self.daily_halted,self.session_count=False,0
        if self.position is not None and gap:
            resolved=(self.previous.time,b.time) in self.zero_trade_gaps
            self.gap_events.append(dict(entry_time=self.position.entry_time.isoformat(),previous_bar=self.previous.time.isoformat(),next_bar=b.time.isoformat(),resolved_zero_trade=resolved))
            if not resolved:self.close_position(b.open,b.time-MINUTE,'DATA_GAP_NEXT_QUOTE')
        if self.position is not None and not selected:self.close_position(b.open,b.time-MINUTE,'EVALUATION_BOUNDARY')
        if selected:
            self.active_sessions.add(b.session)
            local=(b.time-MINUTE).astimezone(CT);minute=local.hour*60+local.minute
            locked=self.risk.daily_profit_target is not None and self.balance-self.session_open>=self.risk.daily_profit_target-1e-8
            if locked:self.profit_locked_sessions.add(b.session)
            eligible=(not self.halted and not self.daily_halted and self.position is None and not locked and
                local.weekday()<5 and self.risk.entry_start_ct<=minute<self.risk.entry_end_ct and
                self.session_count<self.risk.max_trades_per_session and b.session not in self.blocked_dates)
            if eligible:eligible=self.entry_guard(b)
            if self.pending is not None and not gap and eligible:self.position=self.open_position(self.pending,b)
            self.manage(b)
            equity=self.balance
            if self.position is not None:
                p=self.position
                equity+=((b.close-p.entry)*p.signal.direction*self.instrument.point_value-
                    self.risk.commission_round_trip-self.risk.slippage_ticks_per_side*self.instrument.tick_size*self.instrument.point_value)*p.quantity
            self.check_equity(equity);self.equity_curve.append((b.time.isoformat(),equity))
        self.on_bar(b)
        source=self.engine.on_bar(b)
        if source is not None and selected:self.signals.append(source)
        self.pending=source if selected else None;self.pending_features=None;self.pending_history=tuple(self.engine.history)
        self.previous=b;self.bars_processed+=1

    def finish(self):
        if self.finished:raise RuntimeError('Already finalized')
        if self.position is not None:
            self.close_position(self.previous.close,self.previous.time,'DATA_END')
            self.equity_curve.append((self.previous.time.isoformat(),self.balance))
        if self.previous is not None:
            local=self.previous.time.astimezone(CT)
            if local.hour*60+local.minute>=self.risk.flatten_ct:self.finish_session()
        self.finished=True
        return self.report()

    def run(self,bars,start=None,end=None):
        if self.previous is not None:raise RuntimeError('Single-use gold runtime')
        self.start,self.end=start,end
        for b in bars:self.step(b)
        return self.finish()

    def report(self):
        r=super().report()
        r['gold_product']=dict(root=self.root,point_value=self.instrument.point_value,tick_value=self.instrument.point_value*.1,
            structural_minimum_points=self.minimum_stop_points,cash_goal_minimum_r=self.minimum_goal_r,
            source_model_transfer='Original numerical setup definitions; product-specific research required',broker_orders=False)
        return r


def fork_flat(parent,risk=None):
    if parent.position is not None:raise ValueError('Only a flat closed-prefix checkpoint can be forked')
    branch=copy.copy(parent)
    immutable={'payloads','canonical_payloads','candidate_payloads','daily_features','daily_models','trade_models',
        'zero_trade_gaps','blocked_dates','pivots','uplift_models'}
    for name,value in vars(parent).items():
        if name not in immutable and isinstance(value,(list,dict,set,deque)):
            setattr(branch,name,value.copy())
    branch.engine=copy.copy(parent.engine);branch.engine.history=parent.engine.history.copy();branch.engine.account=branch
    branch.target_policy=branch
    branch.risk=risk or parent.risk
    branch.forced_time=None;branch.forced_source=None;branch.forced_entered=False;branch.finished=False
    return branch


STATE_FEATURES=('minute_phase','daily_realized_r300','daily_loss_room_fraction','eod_room_fraction',
    'session_trade_fraction','last_day_trade_net_r','day_losing_streak_fraction','pre02_day_score',
    'estimated_qty_fraction','estimated_contract_risk_fraction','estimated_target_r','current_fee_fraction','current_slip_fraction')
UPLIFT_FEATURES=tuple(TRADE_FEATURES)+STATE_FEATURES


def decision_features(runtime,source,stamp):
    day=runtime.daily_features.get(source['session_date'])
    if day is None:raise ValueError('Missing pre02 day features')
    x=trade_features(source,day,stamp)
    r=runtime.risk;inst=runtime.instrument;d=1 if source['direction']=='LONG' else -1
    # Use the completed source close, never the following minute's future open.
    entry=inst.price(float(source['signal_close'])+d*r.slippage_ticks_per_side*.1,up=d==1)
    raw=d*(entry-float(source['invalidation_price']))
    family=source['event_family'];floor=.42 if family.startswith(('SCALP_','ADDON_')) else .62 if not family.startswith('PROBE_') else 0.
    distance=max(raw,floor*float(source['atr']),runtime.minimum_stop_points)
    stop=inst.price(entry-d*distance,up=d==-1)
    per=(d*(entry-stop)+r.slippage_ticks_per_side*.1)*inst.point_value+r.commission_round_trip
    daily_room=runtime.balance-runtime.session_open+r.daily_loss_limit-r.drawdown_reserve
    eod_room=runtime.balance-runtime.account_stop_floor()
    budget=max(0.,min(r.risk_per_trade,float(source.get('risk_budget_dollars',300)),daily_room,eod_room))
    qty=min(r.max_contracts,int((budget+1e-8)//per)) if raw>0 and per>0 else 0
    net=runtime.balance-runtime.session_open
    need=max(0.,500-net);planned=per*qty
    target_r=cash_goal_r(need,planned,runtime.minimum_goal_r)
    past=[t for t in runtime.trades if t.session==source['session_date']]
    last=past[-1].net_pnl/past[-1].planned_risk if past else 0.
    streak=0
    for t in reversed(past):
        if t.net_pnl>0:break
        streak+=1
    score=runtime.day_decisions.get(source['session_date'],{}).get('expected_day_net_r') or 0.
    values=[(stamp.minute%5)/5,net/300,max(0,daily_room)/900,max(0,eod_room)/900,
        runtime.session_count/20,max(-5,min(5,last)),min(streak,5)/5,float(score),qty/r.max_contracts,
        min(per/300,10),target_r,r.commission_round_trip/10,r.slippage_ticks_per_side/4]
    x+=values
    if len(x)!=len(UPLIFT_FEATURES) or not all(math.isfinite(v) for v in x):raise ValueError('Invalid daily-uplift inputs')
    return x,qty


def uplift_score(model,features):
    x=np.asarray(features,dtype=np.float32)
    if x.shape!=(60,) or tuple(model['features'])!=UPLIFT_FEATURES or not np.isfinite(x).all():raise ValueError('Invalid uplift features')
    values=[]
    for tree in model['trees']:
        n=0
        while tree['left'][n]!=-1:n=tree['left'][n] if float(x[tree['feature'][n]])<=tree['threshold'][n] else tree['right'][n]
        values.append(tree['value'][n])
    out=np.mean(values,axis=0)
    if out.shape!=(4,) or not np.isfinite(out).all():raise ValueError('Invalid uplift predictions')
    return out.tolist()


def fit_uplift(rows,start):
    from sklearn.tree import DecisionTreeRegressor
    cutoff=datetime.fromisoformat(start).replace(tzinfo=CT)-timedelta(hours=7)
    if len(rows)<60 or any(datetime.fromisoformat(r['available_at'])>=cutoff for r in rows):raise ValueError('Insufficient or future whole-day labels')
    x=np.asarray([r['features'] for r in rows],dtype=np.float32);y=np.asarray([r['delta_day_r_heads'] for r in rows])
    if x.shape!=(len(rows),60) or y.shape!=(len(rows),4) or not np.isfinite(x).all() or not np.isfinite(y).all():raise ValueError('Invalid whole-day training labels')
    counts=Counter(r['session'] for r in rows);sessions=sorted(counts)
    rng=np.random.RandomState(7193);trees=[];fitted=[]
    for _ in range(64):
        sampled=Counter(rng.choice(sessions,len(sessions),replace=True))
        weights=np.asarray([sampled[r['session']]/counts[r['session']] for r in rows])
        seed=int(rng.randint(0,2**31-1))
        est=DecisionTreeRegressor(max_depth=3,min_samples_leaf=30,max_features=.7,random_state=seed).fit(x,y,sample_weight=weights)
        t=est.tree_;trees.append(dict(left=t.children_left.tolist(),right=t.children_right.tolist(),feature=t.feature.tolist(),
            threshold=t.threshold.tolist(),value=t.value[:,:,0].tolist(),seed=seed));fitted.append(est)
    model=dict(kind='daily_cash_uplift_group_bagged_trees',features=UPLIFT_FEATURES,trees=trees,
        params=dict(trees=64,max_depth=3,min_samples_leaf=30,max_features=.7,seed=7193,bootstrap_unit='session'),
        training_rows=len(rows),training_sessions=len(sessions),available_from_session=start,
        last_label_available=max(r['available_at'] for r in rows),
        label='First2 heads: take-versus-wait terminal daily cash difference/300 under normal/stress future costs. Last2: forced current trade net/300 under the same profiles. Require all4 positive to avoid selecting a losing trade merely because it blocks worse trades.',
        weighting='session-level bootstrap, equal total original weight per session; repeated states are not independent days',
        limitation='Approximate one-step improvement; deployed repeated interventions can change later states. Full account replay is required.')
    model['sha256']=hashlib.sha256(json.dumps(model,sort_keys=True).encode()).hexdigest()
    expected=np.mean([m.predict(x) for m in fitted],axis=0)
    assert np.allclose([uplift_score(model,v) for v in x],expected,rtol=1e-10,atol=1e-10)
    return model




class FilteredDailyRuntime(GoldSessionRuntime):
    """Keep the simple setup rules; take a setup only on predicted daily uplift."""
    def __init__(self,*args,uplift_models,**kwargs):
        super().__init__(*args,**kwargs)
        self.uplift_models=sorted(uplift_models,key=lambda m:m['available_from_session'])
        self.uplift_decisions=[]

    def entry_payloads(self,stamp):
        candidates=super().entry_payloads(stamp);allowed=[]
        for source in candidates:
            available=[m for m in self.uplift_models if m['available_from_session']<=source['session_date']]
            model=available[-1] if available else None;scores=None;qty=0
            if model is not None and source['session_date'] in self.daily_features:
                if datetime.fromisoformat(model['last_label_available'])>=stamp:raise ValueError('Future daily training reward')
                features,qty=decision_features(self,source,stamp)
                scores=uplift_score(model,features)
            accepted=bool(qty>0 and scores is not None and min(scores)>0)
            self.uplift_decisions.append(dict(signal_time=stamp.isoformat(),session=source['session_date'],
                family=source['event_family'],accepted=accepted,predicted_daily_increment_r=scores,
                model_sha256=model['sha256'] if model else None))
            if accepted:allowed.append(source)
        return allowed

    def report(self):
        r=super().report();r['daily_uplift']=dict(policy='simple_trend_take_or_wait',
            source_rules_unchanged=True,initial_risk_increased=False,training_reward='terminal daily cash difference',
            expected_current_trade_and_daily_increment_positive_both_costs=True,
            pre_first_model='no trades; training dates are not claimed as deployed learner profits',
            inference_has_future_outcome_lookup=False,
            models=[{k:m[k] for k in ('sha256','available_from_session','last_label_available','training_rows','training_sessions')} for m in self.uplift_models])
        return r
