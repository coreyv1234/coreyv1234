"""Pre-entry day-quality forecasts; no current-session outcome in features."""
from datetime import datetime,timedelta
import hashlib,json,math
import numpy as np
import pandas as pd
from .market import CT,MINUTE
from .mgc_native_model import NativeMgcReplay
from .mgc_learned_longs import fit_long,long_score

DAY_FEATURES=('overnight_return_range','overnight_efficiency','overnight_close_location',
 'overnight_range_previous','opening_gap_previous_range','overnight_volume_ratio','overnight_volatility_ratio',
 'previous_return_range','previous_close_location','previous_efficiency','current_vs_previous_ema5',
 'prior3trend','has_previous','has_prior4','overnight_coverage','weekday_sin','weekday_cos','previous_range_bps')

def day_features(one):
    output={}
    def clip(v):return float(np.clip(v,-5,5)) if np.isfinite(v) else 0.
    for symbol,d in one.groupby('instrument',sort=False):
        previous=[]
        for session,day in d.groupby('session_date',sort=True):
            cutoff=pd.Timestamp(session+' 02:00:00',tz=CT).tz_convert('UTC')
            night=day.loc[day.index<=cutoff]
            if len(night)<2:continue
            prev=previous[-1] if previous else None
            scale=max(float(prev['range']) if prev else float(night.high.max()-night.low.min()),.1)
            nrange=max(float(night.high.max()-night.low.min()),.1);last=float(night.close.iloc[-1]);first=float(night.open.iloc[0])
            npath=max(float(night.close.diff().abs().sum()),.1)
            nrvol=float(np.sqrt(np.square(np.diff(np.log(night.close))).mean()))
            denom_vol=(prev['volume']/prev['minutes']) if prev else 0
            prior_ema=float(pd.Series([p['close'] for p in previous]).ewm(span=5,adjust=False).mean().iloc[-1]) if previous else last
            weekday=pd.Timestamp(session).weekday()
            values=[(last-first)/scale,(last-first)/npath,(last-float(night.low.min()))/nrange,
                nrange/scale,(first-prev['close'])/scale if prev else 0.,
                float(night.volume.sum()/len(night))/denom_vol if denom_vol else 0.,nrvol/prev['rvol'] if prev and prev['rvol'] else 0.,
                (prev['close']-prev['open'])/max(prev['range'],.1) if prev else 0.,
                (prev['close']-prev['low'])/max(prev['range'],.1) if prev else 0.,
                (prev['close']-prev['open'])/max(prev['path'],.1) if prev else 0.,(last-prior_ema)/scale,
                (previous[-1]['close']-previous[-4]['close'])/scale if len(previous)>=4 else 0.,
                float(prev is not None),float(len(previous)>=4),len(night)/540,
                math.sin(weekday*2*math.pi/7),math.cos(weekday*2*math.pi/7),prev['range']/prev['close']*1000 if prev else 0.]
            assert len(values)==len(DAY_FEATURES)
            output[session]={'session':session,'instrument':symbol,'available_at':cutoff.isoformat(),
                'last_input_bar':night.index[-1].isoformat(),'features':[clip(v) for v in values]}
            prices=day.close.to_numpy(float)
            previous.append({'open':float(day.open.iloc[0]),'high':float(day.high.max()),'low':float(day.low.min()),
                'close':float(day.close.iloc[-1]),'range':float(day.high.max()-day.low.min()),'volume':float(day.volume.sum()),
                'minutes':len(day),'path':float(day.close.diff().abs().sum()),'rvol':float(np.sqrt(np.square(np.diff(np.log(prices))).mean()))})
    return output

def fit_day(rows,start,kind):
    model=fit_long(rows,start,kind)
    model.pop('sha256',None);model['features']=DAY_FEATURES
    model['label']='isolated_day_net_divided_by300; daily resets only construct training outcomes, not portfolio results'
    model['sha256']=hashlib.sha256(json.dumps(model,sort_keys=True).encode()).hexdigest();return model

class DayPrecisionMgc(NativeMgcReplay):
    def __init__(self,*args,features,models,**kwargs):
        super().__init__(*args,exit_style='net2r',**kwargs)
        self.daily_features=features;self.daily_models=sorted(models,key=lambda m:m['available_from_session'])
        self.day_decisions={}

    def entry_guard(self,bar):
        if bar.session in self.day_decisions:return self.day_decisions[bar.session]['accepted']
        feature=self.daily_features.get(bar.session)
        available=[m for m in self.daily_models if m['available_from_session']<=bar.session]
        model=available[-1] if available else None;score=None;accepted=True
        if feature is not None and model is not None:
            if datetime.fromisoformat(feature['available_at'])>bar.time-MINUTE:raise ValueError('Future day context')
            if datetime.fromisoformat(model['last_label_exit'])>=datetime.fromisoformat(feature['available_at']):raise ValueError('Future day label')
            score=long_score(model,feature['features']);accepted=score>0
        self.day_decisions[bar.session]={'session':bar.session,'accepted':accepted,'expected_day_net_r':score,
            'features_available_at':feature['available_at'] if feature else None,'model_sha256':model['sha256'] if model else None}
        return accepted

    def report(self):
        r=super().report();r['day_quality_skipped_sessions']=sum(not d['accepted'] for d in self.day_decisions.values())
        r['day_gate_uses_current_day_pnl']=False;return r
