"""Exact-account execution planning for independent range targets and capital sizing.

No fills are fabricated here. Native NinjaTrader callbacks own all balances,
positions, protective orders and persistent trailing/daily account state.
"""
from dataclasses import dataclass
from datetime import datetime
import hashlib
import math
from pathlib import Path

from .market import instrument_root
from . import mgc_execution as old

BridgeError=old.BridgeError
POLICY_ID='MGC_RED_CONTEXT800_SIM_20261106'
# User explicitly chose the same strategy and risk cap for either account.
# Only the existing daily/EOD limits constrain its fixed400 allocation.
GOAL_BALANCE=53000.
STATE_FIELDS=old.STATE_FIELDS+('policy_id','max_contracts','risk_limit','protected_room','risk_fraction','evaluation_enabled','goal_balance','goal_reached','first_fill_utc','entry_executed','exit_executed','entry_reported_filled','entry_terminal','entry_terminal_filled','submitted_quantity','pending_exit_callbacks','ledger_uncertain','account_signed_quantity')
COMMAND_FIELDS=old.COMMAND_FIELDS+('budget_ceiling',)


@dataclass(frozen=True)
class ExecutionConfig:
    expected_account: str = 'Sim101'
    account_mode: str = 'simulation'
    max_contracts: int = 10

    def __post_init__(self):
        if not self.expected_account or any(c in self.expected_account for c in ';\r\n'):
            raise BridgeError('Set one exact NinjaTrader account name')
        if self.account_mode!='simulation' or self.expected_account!='Sim101':
            raise BridgeError('This package requires Sim101 simulation mode')
        is_sim=self.expected_account in ('Sim101','Playback101')
        if (self.account_mode=='simulation') != is_sim:
            raise BridgeError('Account name and simulation/evaluation mode disagree')
        if isinstance(self.max_contracts,bool) or not isinstance(self.max_contracts,int) or not 1<=self.max_contracts<=10:
            raise BridgeError('Contract ceiling must be an integer1..10')


def parse_state(text,cfg):
    lines=text.strip().splitlines()
    if len(lines)!=2 or tuple(lines[0].split(';'))!=STATE_FIELDS:
        raise BridgeError('Use SovereignMgcResearchSimBridgeV3 build20261106SIM3')
    values=lines[1].split(';')
    if len(values)!=len(STATE_FIELDS):raise BridgeError('Incomplete range-bridge snapshot')
    s=dict(zip(STATE_FIELDS,values))
    if s['version']!='3' or not old.ID.fullmatch(s['run_id']) or s['policy_id']!=POLICY_ID:
        raise BridgeError('Wrong native model/profile/run')
    if s['account']!=cfg.expected_account:raise BridgeError('Native account does not match execution_config.json')
    if instrument_root(s['instrument'])!='MGC' or s['instrument']=='MGC':raise BridgeError('Use an actual MGC expiry')
    for k in ('quantity','direction','entry_working','session_count','slip','blocked','orders_working','flatten_ct','max_contracts','evaluation_enabled','goal_reached','entry_executed','exit_executed','entry_reported_filled','entry_terminal','entry_terminal_filled','submitted_quantity','pending_exit_callbacks','ledger_uncertain','account_signed_quantity'):
        s[k]=int(s[k])
    for k in ('last','bid','ask','average_entry','stop','target','realized_net','session_open_cash','highwater','fee','initial_risk','risk_limit','protected_room','risk_fraction','goal_balance'):
        s[k]=float(s[k])
        if not math.isfinite(s[k]):raise BridgeError('Nonfinite account/quote state')
    for k in ('updated_utc','last_bar_utc','quote_utc','first_fill_utc'):s[k]=old.utc(s[k])
    if (s['max_contracts']!=cfg.max_contracts or s['risk_limit']!=800 or s['protected_room']!=0 or s['risk_fraction']!=1 or
        s['evaluation_enabled']!=int(cfg.account_mode=='evaluation') or not 0<=s['quantity']<=cfg.max_contracts or
        s['direction'] not in (-1,0,1) or (s['quantity']==0)!=(s['direction']==0) or s['slip']!=1 or
        s['flatten_ct']!=955 or s['session_count']<0 or abs(s['fee']-2.8)>1e-8 or s['session_open_cash']<=0 or
        not 50000<=s['highwater']<=52000 or s['goal_balance']!=GOAL_BALANCE or
        any(s[k] not in (0,1) for k in ('blocked','entry_working','orders_working','goal_reached','entry_terminal','entry_terminal_filled','ledger_uncertain'))):
        raise BridgeError('Native account/profile violates configured limits')
    datetime.fromisoformat(s['session'])
    if min(s[k] for k in ('entry_executed','exit_executed','entry_reported_filled','submitted_quantity','pending_exit_callbacks'))<0:
        raise BridgeError('Negative execution callback count')
    if s['quantity'] and (s['first_fill_utc']>s['updated_utc'] or s['first_fill_utc'].year<2020):
        raise BridgeError('Missing/future actual first-fill time')
    return s


def healthy_state(s,now,cfg):
    if s['account']!=cfg.expected_account or s['policy_id']!=POLICY_ID:
        raise BridgeError('Account or policy changed')
    old.healthy_state(s,now)
    if s['ledger_uncertain']:raise BridgeError('Native ledger is uncertain')
    if s['entry_executed']-s['exit_executed']!=s['quantity']:raise BridgeError('Execution counts and position do not reconcile')
    if not 0<=s['exit_executed']<=s['entry_executed']<=s['submitted_quantity']<=cfg.max_contracts:raise BridgeError('Invalid execution quantities')
    if s['account_signed_quantity']!=s['direction']*s['quantity']:raise BridgeError('Account position callbacks have not reconciled')
    if s['entry_reported_filled']>s['submitted_quantity']:raise BridgeError('Order acknowledgement exceeds submitted size')
    if s['quantity'] and (not old.ID.fullmatch(s['active_id']) or min(s['average_entry'],s['stop'],s['target'],s['initial_risk'])<=0):
        raise BridgeError('Native filled-position protection state is incomplete')


def command(s,kind,model_id,now,**values):
    row=old.command(s,kind,model_id,now,budget_ceiling=values.pop('budget_ceiling',0),**values)
    row['version']=3
    assert tuple(row)==COMMAND_FIELDS
    return row


def write_command(folder,row):
    if tuple(row)!=COMMAND_FIELDS or not old.ID.fullmatch(str(row['command_id'])):
        raise BridgeError('Wrong range command schema')
    values=[str(row[k]) for k in COMMAND_FIELDS]
    if any(any(c in v for c in ';\r\n') for v in values):raise BridgeError('Unsafe command field')
    path=Path(folder)/'commands'/(row['command_id']+'.cmd')
    if path.exists():raise BridgeError('Duplicate command identity')
    old.atomic_text(path,';'.join(COMMAND_FIELDS)+'\n'+';'.join(values)+'\n')
    return path


def protective_stop(s,closed_bar,now,config):
    healthy_state(s,now,config)
    if s['pending_exit_callbacks'] or s['entry_working'] or closed_bar.time<=s['first_fill_utc']:
        return None
    row=old.protective_stop(s,closed_bar,now)
    if row is None:return None
    row['version']=3;row['budget_ceiling']=0
    return row
