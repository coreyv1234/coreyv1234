"""Normalize the research risk-cap type to preserve original journal bytes."""
from dataclasses import replace
from .mgc_native_scale import NativeScaleMgc


class NativeScaleV2Mgc(NativeScaleMgc):
    def __init__(self,risk,payloads,**kwargs):
        super().__init__(replace(risk,risk_per_trade=float(risk.risk_per_trade)),payloads,**kwargs)
