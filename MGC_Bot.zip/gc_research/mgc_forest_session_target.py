"""Frozen forest/day gate plus the fixed cash-target rule; exploratory transfer."""
from .mgc_trade_selection import TradeSelectionMgc
from .mgc_session_target import SessionTargetMgc

class ForestSessionTargetMgc(TradeSelectionMgc):
    def __init__(self,*args,**kwargs):super().__init__(*args,trade_policy='forest_with_day',**kwargs)

    __call__=SessionTargetMgc.__call__

    def report(self):
        r=super().report();r['session_target_extension']={'goal':500.,'max_target_r':3.,
            'extended_entries':sum(v['requested_net_r']>2 for v in self.target_decisions if v['accepted']),
            'forest_label_transfer':'Fixed2R training applied to2R..3R exits; exploratory, not independently validated.'};return r
