"""Targeted source confirmation and stale day-forecast ablations; research only."""
from dataclasses import replace

from .mgc_evaluation_phase import EvaluationPhaseMgc

POLICIES=('reference','break_reclaim','day_gate_off','combined')


class LossFlatRepairMgc(EvaluationPhaseMgc):
    def __init__(self,*args,repair_policy,**kwargs):
        if repair_policy not in POLICIES:
            raise ValueError('Unknown fixed repair policy')
        if repair_policy in ('day_gate_off','combined'):
            kwargs['models']=[]
        super().__init__(*args,**kwargs)
        self.repair_policy=repair_policy
        self.entry_repair_events=[]

    def place_limit(self,bar):
        order=super().place_limit(bar)
        if order is None:
            return None
        if (self.repair_policy in ('break_reclaim','combined')
                and order.signal.family=='SCALP_BREAK_LOW_RANGE_SHORT'
                and self.confirmation_time==bar.time):
            # Revert only this family's early submission to the original
            # source-time three-minute confirmation deadline. Never use an
            # entry candle to invent confirmation of the source candle.
            self.confirmation_time=self.touch_time=None
            self.limit_order=order=replace(order,expiry=self.confirmation_deadline)
            self.orders[-1].update(expiry=order.expiry.isoformat(),
                confirmation_time='',touch_time='',execution_rule='break_requires_original_reclaim')
            self.entry_repair_events.append(dict(order_id=order.order_id,
                source_time=bar.time.isoformat(),family=order.signal.family,
                confirmation_deadline=self.confirmation_deadline.isoformat(),
                stop=order.stop,target=order.target,quantity=order.quantity))
        return order

    def report(self):
        report=super().report()
        report['loss_flat_repair']=dict(policy=self.repair_policy,
            day_forecast_removed=self.repair_policy in ('day_gate_off','combined'),
            trade_forest_retained=True,holiday_block_retained=True,
            stop_target_risk_unchanged=True,entry_repair_events=self.entry_repair_events,
            outcome_conditioned_day_selection=False)
        return report
