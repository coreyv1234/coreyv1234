"""Offline gate experiments for the actual range-target exit, not legacy 2R.

The frozen execution release is deliberately untouched. No brokerage interface
is provided here, and income replays do not imply evaluation qualification.
"""
from collections import Counter
from datetime import datetime, timedelta
import hashlib
import json
import math

import numpy as np

from .market import CT, MINUTE, INSTRUMENTS
from .mgc_range_execution import ExecutableRangeMgc
from .mgc_range_projection import range_target
from .mgc_trade_selection import TRADE_FEATURES, trade_features

POLICIES = ('incumbent', 'without_day_gate', 'without_trade_gate', 'source_only',
            'matched_range_gate', 'matched_range_with_day')
EXTRA_FEATURES = ('target_distance_atr', 'full_stop_distance_atr',
    'target_net_over_contract_risk', 'prior_range_atr',
    'entry_location_in_prior_range_signed', 'target_distance_over_range',
    'fee_fraction_of_contract_risk', 'source_quality', 'confirmation_strength',
    'trend_aligned')
RANGE_FEATURES = tuple(TRADE_FEATURES) + EXTRA_FEATURES


def range_features(source, day, stamp, history):
    """Features known at source close; never the next minute open or outcome."""
    if any(b.time > stamp for b in history):
        raise ValueError('Future range-feature candle')
    x = trade_features(source, day, stamp)
    inst = INSTRUMENTS['MGC']
    d = 1 if source['direction'] == 'LONG' else -1
    atr = float(source['atr'])
    if not math.isfinite(atr) or atr <= 0:
        raise ValueError('Invalid source ATR')
    entry = inst.price(float(source['signal_close']) + d * .1, up=d == 1)
    raw = d * (entry - float(source['invalidation_price']))
    if raw <= 0:
        return None
    family = source['event_family']
    floor = .42 if family.startswith(('SCALP_', 'ADDON_')) else .62 if not family.startswith('PROBE_') else 0.
    stop = inst.price(entry - d * max(raw, floor * atr, 1.2), up=d == -1)
    target = range_target(history, stamp, entry, d)
    if target is None:
        return None
    dist = d * (target['price'] - entry)
    per_risk = d * (entry - stop) * 10 + 3.8
    width = max(.1, target['box_high'] - target['box_low'])
    location = (entry - target['box_low']) / width if d == 1 else (target['box_high'] - entry) / width
    extra = [dist / atr, d * (entry - stop) / atr, (dist * 10 - 2.8) / per_risk,
        width / atr, location, dist / width, 2.8 / per_risk,
        float(source.get('quality_score', 0)), float(source.get('confirmation_strength', 0)),
        float(bool(source.get('trend_aligned', False)))]
    if not all(math.isfinite(v) for v in extra):
        raise ValueError('Nonfinite range gate feature')
    x += [max(-20., min(20., v)) for v in extra]
    assert len(x) == len(RANGE_FEATURES)
    return x


def range_score(model, values):
    x = np.asarray(values, dtype=np.float32)
    if tuple(model['features']) != RANGE_FEATURES or x.shape != (len(RANGE_FEATURES),) or not np.isfinite(x).all():
        raise ValueError('Wrong range feature schema')
    predictions = []
    for t in model['trees']:
        i = 0
        while t['left'][i] != -1:
            i = t['left'][i] if float(x[t['feature'][i]]) <= t['threshold'][i] else t['right'][i]
        predictions.append(t['value'][i])
    scores = np.mean(predictions, axis=0)
    if scores.shape != (2,) or not np.isfinite(scores).all():
        raise ValueError('Invalid dual-cost prediction')
    return scores.tolist()


def fit_range_gate(rows, available):
    from sklearn.ensemble import RandomForestRegressor
    cutoff = datetime.fromisoformat(available).replace(tzinfo=CT) - timedelta(hours=7)
    if len(rows) < 60 or any(datetime.fromisoformat(r['available_at']) >= cutoff for r in rows):
        raise ValueError('Insufficient or future range labels')
    x = np.asarray([r['features'] for r in rows])
    y = np.asarray([r['net_r_heads'] for r in rows])
    if x.shape != (len(rows), len(RANGE_FEATURES)) or y.shape != (len(rows), 2) or not np.isfinite(y).all():
        raise ValueError('Malformed range training labels')
    counts = Counter(r['session'] for r in rows)
    weights = [1. / counts[r['session']] for r in rows]
    params = dict(n_estimators=128, max_depth=3, min_samples_leaf=30,
        max_features=.7, bootstrap=True, random_state=7193, n_jobs=1)
    fitted = RandomForestRegressor(**params).fit(x, y, sample_weight=weights)
    trees = []
    for est in fitted.estimators_:
        t = est.tree_
        trees.append(dict(left=t.children_left.tolist(), right=t.children_right.tolist(),
            feature=t.feature.tolist(), threshold=t.threshold.tolist(), value=t.value[:, :, 0].tolist()))
    model = dict(kind='dual_cost_range_exit_forest', features=RANGE_FEATURES, trees=trees, params=params,
        available_from_session=available, last_label_exit=max(r['available_at'] for r in rows),
        training_rows=len(rows), training_sessions=len(counts),
        label='Isolated actual range-TP/full-stop/cost-BE net divided by initial planned risk, normal and doubled costs.',
        weighting='Each observed training session has equal total sample weight. Repeated rows are not independent sessions.',
        threshold='Both predicted cost heads strictly positive; no threshold search')
    model['sha256'] = hashlib.sha256(json.dumps(model, sort_keys=True).encode()).hexdigest()
    assert np.allclose([range_score(model, v) for v in x], fitted.predict(x), rtol=1e-10, atol=1e-10)
    return model


class RangeOpportunityMgc(ExecutableRangeMgc):
    def __init__(self, risk, payloads, *, policy, range_models=(), goal_lock=False, **kwargs):
        if policy not in POLICIES:
            raise ValueError('Unregistered opportunity policy')
        if policy in ('without_day_gate', 'source_only', 'matched_range_gate'):
            kwargs['models'] = []
        if policy in ('without_trade_gate', 'source_only', 'matched_range_gate', 'matched_range_with_day'):
            kwargs['trade_models'] = []
        super().__init__(risk, payloads, **kwargs)
        self.opportunity_policy = policy
        self.range_models = sorted(range_models, key=lambda m: m['available_from_session'])
        self.range_decisions = []
        self.dispositions = []
        self.goal_lock = goal_lock

    def entry_guard(self, bar):
        if self.goal_lock and self.balance >= 53000:
            return False
        return super().entry_guard(bar)

    def entry_payloads(self, stamp):
        candidates = super().entry_payloads(stamp)
        if not self.opportunity_policy.startswith('matched_range'):
            return candidates
        result = []
        for p in candidates:
            available = [m for m in self.range_models if m['available_from_session'] <= p['session_date']]
            m = available[-1] if available else None
            scores = None
            accepted = m is None
            if m is not None:
                if datetime.fromisoformat(m['last_label_exit']) >= stamp:
                    raise ValueError('Future range outcome used for decision')
                day = self.daily_features.get(p['session_date'])
                features = range_features(p, day, stamp, self.structure_history) if day is not None else None
                if features is not None:
                    scores = range_score(m, features)
                    accepted = min(scores) > 0
            self.range_decisions.append(dict(signal_time=stamp.isoformat(), session=p['session_date'],
                family=p['event_family'], accepted=accepted, predicted_net_r_heads=scores,
                model_sha256=m['sha256'] if m else None))
            if accepted:
                result.append(p)
            else:
                self.rejections['matched_range_nonpositive_or_missing_context'] += 1
        return result

    def step(self, b):
        selected = (self.start is None or b.session >= self.start) and (self.end is None or b.session < self.end)
        pending = self.pending
        count = self.session_count if self.session == b.session else 0
        before = self.rejections.copy()
        reason = None
        if pending is not None and selected:
            local = (b.time - MINUTE).astimezone(CT)
            minute = local.hour * 60 + local.minute
            if local.weekday() >= 5 or not 120 <= minute < 720: reason = 'outside_entry_window'
            elif b.session in self.blocked_dates: reason = 'holiday'
            elif self.halted: reason = 'account_halted'
            elif self.daily_halted and self.session == b.session: reason = 'daily_halted'
            elif self.position is not None: reason = 'position_already_open'
            elif self.previous is not None and (b.time - self.previous.time != MINUTE or b.instrument != self.previous.instrument or b.session != self.previous.session): reason = 'data_or_expiry_boundary'
            elif self.goal_lock and self.balance >= 53000: reason = 'evaluation_target_reached'
            elif count >= self.risk.max_trades_per_session: reason = 'session_count_limit'
        super().step(b)
        if pending is not None and selected:
            delta = {k: v - before[k] for k, v in self.rejections.items() if v > before[k]}
            if self.session_count > count: reason = 'entered'
            elif reason is None:
                if not self.day_decisions.get(b.session, {'accepted': True})['accepted']: reason = 'day_gate_rejected'
                elif delta: reason = 'entry_rejected'
                else: reason = 'no_entry_without_rejection'
            self.dispositions.append(dict(signal_time=pending.time.isoformat(), session=b.session,
                reason=reason, rejections=delta, cash=self.balance,
                eod_room=self.balance - self.account_stop_floor()))

    def report(self):
        r = super().report()
        r['range_opportunity'] = dict(policy=self.opportunity_policy,
            disposition_counts=dict(Counter(v['reason'] for v in self.dispositions)),
            matched_gate_decisions=len(self.range_decisions), goal_lock=self.goal_lock,
            source_stop_target_risk_unchanged=True, orders=False)
        return r
