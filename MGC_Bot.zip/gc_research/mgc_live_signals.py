"""Generate only the latest closed five-minute source packet, without a future row."""
from __future__ import annotations

import pandas as pd
import numpy as np

from .market import CT
from .mgc_day_precision import day_features
from .mgc_native_model import feature_values


def normalized_minutes(frame):
    frame = frame.copy()
    frame.index = pd.to_datetime(frame.time_utc, utc=True)
    if not frame.index.is_unique or not frame.index.is_monotonic_increasing:
        raise ValueError("History must be unique and chronological")
    frame["session_date"] = [(t.tz_convert(CT)+pd.Timedelta(days=int(t.tz_convert(CT).hour>=17))).date().isoformat() for t in frame.index]
    for name, default in (("ask_hit_volume_inferred", 0.), ("bid_hit_volume_inferred", 0.),
                          ("mean_spread_ticks_at_valid_trade", np.nan)):
        if name not in frame:
            frame[name] = default
    return frame


def latest_source(brain, one, stamp, symbol):
    stamp = pd.Timestamp(stamp)
    if one.index[-1] != stamp or (one.index > stamp).any():
        raise ValueError("Latest source must use exactly a closed historical prefix")
    if stamp.minute % 5 or stamp.second or stamp.microsecond:
        return []
    if not brain.entry_session_open(stamp) or brain.friday_entry_block(stamp):
        return []
    d = one.loc[one.instrument == symbol]
    groups = d.groupby(d.index.ceil("5min"))
    five = groups.agg(open=("open","first"), high=("high","max"), low=("low","min"), close=("close","last"),
        volume=("volume","sum"), buy=("ask_hit_volume_inferred","sum"), sell=("bid_hit_volume_inferred","sum"),
        spread_ticks=("mean_spread_ticks_at_valid_trade","mean"))
    if len(five) < 226 or five.index[-1] != stamp:
        return []
    five["classified_fraction"] = (five.buy+five.sell)/five.volume
    five["delta_fraction"] = (five.buy-five.sell)/five.volume
    five["segment_id"] = "native_"+symbol
    five["source_file"] = "native_tick_summary_"+symbol
    frame = brain.build_indicators(five)
    i = len(frame)-1
    candidates = []
    for kind, fn in (("core", lambda:brain.choose_event(frame,i,brain.strategy_configs()[0].event_rule)),
                     ("scalp",lambda:brain.detect_scalp_event(frame,i)),
                     ("probe",lambda:brain.detect_probe_event(frame,i)),
                     ("addon",lambda:brain.detect_addon_event(frame,i))):
        payload = fn()
        if payload:
            payload = dict(payload, source_kind=kind, session_date=stamp.tz_convert(CT).date().isoformat())
            payload["features"] = feature_values(payload, frame.iloc[-1], five.iloc[-1], stamp)
            candidates.append(payload)
    return candidates
