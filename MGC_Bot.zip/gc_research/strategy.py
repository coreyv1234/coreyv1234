from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass
from datetime import datetime

from .market import Bar, MINUTE
from .features import CausalFeatures, accepts


@dataclass(frozen=True)
class StrategyConfig:
    family: str = "breakout"
    lookback: int = 12
    atr_period: int = 14
    fast_ema: int = 9
    slow_fast_ema: int = 8
    slow_slow_ema: int = 21
    stop_atr: float = 1.2
    target_r: float = 1.5
    max_extension_atr: float = 1.5
    max_hold_minutes: int = 30
    max_gap_atr: float = 0.25
    entry_filter: str = "none"

    def __post_init__(self):
        if self.family not in {"breakout", "pullback", "breakout_retest", "failed_break", "trend_reclaim", "compression_impulse", "sweep_reclaim"}:
            raise ValueError("unknown strategy family")
        if self.entry_filter not in {"none", "momentum", "efficiency", "combined"}:
            raise ValueError("unknown entry filter")
        for name in ("lookback", "atr_period", "fast_ema", "slow_fast_ema", "slow_slow_ema", "max_hold_minutes"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 2:
                raise ValueError(f"{name} must be an integer >= 2")
        if self.slow_fast_ema >= self.slow_slow_ema:
            raise ValueError("slow fast EMA must be shorter than slow slow EMA")
        for name in ("stop_atr", "target_r", "max_extension_atr", "max_gap_atr"):
            if not math.isfinite(getattr(self, name)) or getattr(self, name) <= 0:
                raise ValueError(f"{name} must be positive and finite")


@dataclass(frozen=True)
class Signal:
    time: datetime
    instrument: str
    direction: int
    family: str
    reference: float
    stop: float
    atr: float


class EMA:
    def __init__(self, period: int):
        self.alpha = 2 / (period + 1)
        self.value: float | None = None
        self.count = 0

    def push(self, value: float) -> float:
        self.value = value if self.value is None else self.alpha * value + (1 - self.alpha) * self.value
        self.count += 1
        return self.value


class SignalEngine:
    """The only strategy implementation, shared by logic-test and signal replay.

    Consumes COMPLETED one-minute bars. Five-minute context becomes available
    only after five contiguous one-minute bars end on a five-minute boundary.
    No order placement, retrospective feature frames, or future-bar access.
    """

    def __init__(self, config: StrategyConfig):
        self.config = config
        self.reset()

    def reset(self):
        c = self.config
        self.fast = EMA(c.fast_ema)
        self.slow_fast = EMA(c.slow_fast_ema)
        self.slow_slow = EMA(c.slow_slow_ema)
        self.history: deque[Bar] = deque(maxlen=c.lookback)
        self.range_history: deque[float] = deque(maxlen=c.atr_period)
        self.five: list[Bar] = []
        self.previous: Bar | None = None
        self.atr: float | None = None
        self.features = CausalFeatures()
        self.last_features = None
        self.armed = {}
        self.last_pattern_diagnostics = None

    def on_bar(self, bar: Bar) -> Signal | None:
        c = self.config
        prev = self.previous
        if prev and bar.time <= prev.time:
            raise ValueError("signal input must advance in time")
        if prev and (bar.time - prev.time != MINUTE or bar.instrument != prev.instrument or bar.session != prev.session):
            self.reset()
            prev = None
        self.last_pattern_diagnostics = None
        prior_atr = self.atr
        self.last_features = self.features.push(bar)
        tr = max(bar.high - bar.low, abs(bar.high - prev.close), abs(bar.low - prev.close)) if prev else bar.high - bar.low
        self.range_history.append(tr)
        if self.atr is None and len(self.range_history) == c.atr_period:
            self.atr = sum(self.range_history) / c.atr_period
        elif self.atr is not None:
            self.atr = (self.atr * (c.atr_period - 1) + tr) / c.atr_period
        fast = self.fast.push(bar.close)
        self.five.append(bar)
        if bar.time.minute % 5 == 0:
            if len(self.five) == 5:
                self.slow_fast.push(bar.close)
                self.slow_slow.push(bar.close)
            self.five.clear()
        elif len(self.five) > 5:
            raise ValueError("five-minute aggregation alignment failure")
        signal = None
        early_family = c.family in {'compression_impulse', 'sweep_reclaim'}
        ready = (len(self.history) == c.lookback and self.atr is not None and self.atr > .1
                 and self.fast.count >= c.fast_ema and
                 (early_family or self.slow_slow.count >= c.slow_slow_ema))
        if ready and early_family:
            signal = self.early_playbook(bar, prior_atr)
        elif ready:
            atr = self.atr
            sf, ss = self.slow_fast.value, self.slow_slow.value
            direction = 1 if sf > ss and bar.close > ss else -1 if sf < ss and bar.close < ss else 0
            if c.family in {"breakout_retest", "failed_break", "trend_reclaim"}:
                signal = self.playbook(bar, prev, direction, fast, sf, ss)
            elif direction and abs(bar.close - fast) / atr <= c.max_extension_atr:
                if c.family == "breakout":
                    trigger = (bar.close >= max(b.high for b in self.history) + .1 - 1e-8 if direction == 1
                               else bar.close <= min(b.low for b in self.history) - .1 + 1e-8)
                else:
                    trigger = (bar.low <= fast and bar.close > fast and bar.close > prev.high if direction == 1
                               else bar.high >= fast and bar.close < fast and bar.close < prev.low)
                if trigger:
                    stop = min(bar.low - .1, bar.close - c.stop_atr * atr) if direction == 1 else max(bar.high + .1, bar.close + c.stop_atr * atr)
                    signal = Signal(bar.time, bar.instrument, direction, c.family, bar.close, stop, atr)
        if signal and not accepts(self.last_features, signal.direction, c.entry_filter):
            signal = None
        self.history.append(bar)
        self.previous = bar
        return signal

    def early_playbook(self, bar, prior_atr):
        """Explicit price-action hypotheses; no slow-EMA waiting or future bars.

        Both require at-least-average volume against the prior 20-minute
        distribution. These thresholds are fixed hypotheses, not proven edges.
        """
        if prior_atr is None or prior_atr <= .1 or len(self.history) < 12:
            return None
        volume_z = self.last_features.volume_z_prior20
        if volume_z is None or volume_z < 0:
            return None
        span = bar.high-bar.low
        if span <= 0:
            return None
        body = abs(bar.close-bar.open)/span
        location = (bar.close-bar.low)/span
        recent = list(self.history)[-3:]
        compression = (max(b.high for b in recent)-min(b.low for b in recent))/prior_atr
        d = 0
        if self.config.family == 'compression_impulse':
            if compression > 1.5 or not 1-1e-8 <= span/prior_atr <= 2+1e-8 or body < .60:
                return None
            if bar.close >= max(b.high for b in recent)+.1-1e-8 and bar.close > bar.open and location >= .80:
                d = 1
            elif bar.close <= min(b.low for b in recent)-.1+1e-8 and bar.close < bar.open and location <= .20:
                d = -1
            stop = min(bar.low, recent[-1].low)-.1 if d == 1 else max(bar.high, recent[-1].high)+.1
        else:
            high = max(b.high for b in self.history)
            low = min(b.low for b in self.history)
            if not .5-1e-8 <= span/prior_atr <= 2+1e-8:
                return None
            if bar.low <= low-.1+1e-8 and bar.close >= low+.1-1e-8 and bar.close > bar.open and location >= .70:
                d = 1
            elif bar.high >= high+.1-1e-8 and bar.close <= high-.1+1e-8 and bar.close < bar.open and location <= .30:
                d = -1
            stop = bar.low-.1 if d == 1 else bar.high+.1
        if not d:
            return None
        self.last_pattern_diagnostics = {'prior_atr': prior_atr,
            'prior3_compression_atr': compression, 'signal_range_atr': span/prior_atr,
            'body_fraction': body, 'close_location': location, 'volume_z_prior20': volume_z,
            'prior3_high': max(b.high for b in recent), 'prior3_low': min(b.low for b in recent),
            'prior12_high': max(b.high for b in self.history), 'prior12_low': min(b.low for b in self.history)}
        return Signal(bar.time, bar.instrument, d, self.config.family, bar.close, stop, self.atr)

    def playbook(self, bar, previous, direction, fast, slow_fast, slow_slow):
        c, atr = self.config, self.atr
        high = max(b.high for b in self.history)
        low = min(b.low for b in self.history)
        if c.family == "failed_break":
            d = (-1 if slow_fast <= slow_slow and bar.high >= high + .1 - 1e-8
                 and bar.close <= high - .1 + 1e-8 and bar.close < bar.open else
                 1 if slow_fast >= slow_slow and bar.low <= low - .1 + 1e-8
                 and bar.close >= low + .1 - 1e-8 and bar.close > bar.open else 0)
            if d:
                stop = bar.low - .1 if d == 1 else bar.high + .1
                return Signal(bar.time, bar.instrument, d, c.family, bar.close, stop, atr)
        elif c.family == "trend_reclaim":
            if not direction or abs(bar.close - fast) / atr > c.max_extension_atr:
                return None
            trigger = (bar.low <= fast and bar.close > fast and bar.close > previous.high
                       and bar.close > bar.open if direction == 1 else
                       bar.high >= fast and bar.close < fast and bar.close < previous.low
                       and bar.close < bar.open)
            if trigger:
                recent = list(self.history)[-2:] + [bar]
                stop = min(b.low for b in recent)-.1 if direction == 1 else max(b.high for b in recent)+.1
                return Signal(bar.time, bar.instrument, direction, c.family, bar.close, stop, atr)
        elif c.family == "breakout_retest":
            result = None
            for d, setup in list(self.armed.items()):
                setup["age"] += 1
                setup["low"] = min(setup["low"], bar.low)
                setup["high"] = max(setup["high"], bar.high)
                level, band = setup["level"], .15 * setup["atr"]
                invalid = (d != direction or setup["age"] > 3
                           or d*(bar.close-level) < -.5*setup["atr"])
                if invalid:
                    del self.armed[d]
                    continue
                extreme = bar.low if d == 1 else bar.high
                trigger = (level-band <= extreme <= level+band
                           and d*(bar.close-level) >= .1-1e-8
                           and d*(bar.close-bar.open) > 0
                           and abs(bar.close-fast)/atr <= c.max_extension_atr)
                if trigger:
                    stop = setup["low"]-.1 if d == 1 else setup["high"]+.1
                    result = Signal(bar.time, bar.instrument, d, c.family, bar.close, stop, atr)
                    del self.armed[d]
                elif setup["age"] == 3:
                    del self.armed[d]
            # A breakout bar cannot be its own retest. Existing setups are not refreshed.
            if result is None and direction and direction not in self.armed:
                level = high if direction == 1 else low
                if direction*(bar.close-level) >= .1-1e-8:
                    self.armed[direction] = {"age": 0, "level": level, "atr": atr,
                                             "low": bar.low, "high": bar.high}
            return result
        return None
