"""One exploratory refinement: source-location confirmation only while down today."""
from .mgc_source_quality_repair import SourceQualityRepairMgc


class RedContextQualityMgc(SourceQualityRepairMgc):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,source_quality_policy='location_reclaim',**kwargs)

    def place_limit(self,bar):
        original=self.source_quality_policy
        realized=self.balance-self.session_open
        active=realized<-1e-8
        self.source_quality_policy='location_reclaim' if active else 'reference'
        n=len(self.source_quality_events)
        try:
            order=super().place_limit(bar)
            if len(self.source_quality_events)>n:
                self.source_quality_events[-1].update(red_context_active=active,
                    settled_cash=self.balance,session_open=self.session_open,
                    realized_session_pnl=realized)
            return order
        finally:
            self.source_quality_policy=original

    def report(self):
        report=super().report()
        report['red_context_quality']=dict(condition='Realized session PnL strictly negative at source close',
            unrealized_or_future_pnl_used=False,zero_and_positive_session_keep_original_entries=True)
        return report
