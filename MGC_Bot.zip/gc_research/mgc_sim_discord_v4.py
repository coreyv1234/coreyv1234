"""Required trading startup delivery; visible async health without order retries."""
import getpass
import json
import os
import sys
from pathlib import Path
from .execution_notifications import ExecutionNotifications
from .notifications import DiscordNotifier
from .mgc_execution import BridgeError,atomic_text


def confirmed_notifications(enabled=True):
    if not enabled:return ExecutionNotifications()
    value=os.environ.get('DISCORD_WEBHOOK_URL','').strip()
    if not value:
        if not sys.stdin.isatty():
            raise BridgeError('Discord is required. Set DISCORD_WEBHOOK_URL locally or run in a terminal for hidden entry.')
        value=getpass.getpass('Discord webhook URL (hidden; used for this run only): ').strip()
    try:
        sender=DiscordNotifier(value)
        sender.send('MGC Sim101 | Discord startup check delivered. Controller is preparing; no trade is implied.')
    except Exception:
        raise BridgeError('Discord startup delivery failed. Check your local webhook/network; no controller was armed. Details omitted.') from None
    notifications=ExecutionNotifications(sender)
    notifications.sent=1
    print('Discord enabled: startup delivery confirmed.',flush=True)
    return notifications


class NotificationHealth:
    def __init__(self,folder,notifications):
        self.path=Path(folder)/'notification_status.json'
        self.notifications=notifications
        self.last=None

    def update(self):
        n=self.notifications
        status=dict(enabled=n.sender is not None,startup_delivery_confirmed=n.sender is not None,
            sent=n.sent,failed=n.failed,dropped=n.dropped,pending=n.queue.qsize())
        if status!=self.last:
            atomic_text(self.path,json.dumps(status,indent=2)+'\n')
            if status['failed'] or status['dropped']:
                if self.last is None or (status['failed'],status['dropped'])!=(self.last['failed'],self.last['dropped']):
                    print('Discord delivery problem: failed='+str(status['failed'])+' dropped='+str(status['dropped'])+'. See notification_status.json; native protection continues.',flush=True)
            self.last=status
        return status
