"""Join from a flat native state; only fresh post-start sources may trade."""
from .market import CT
from .mgc_live_research_planner_v3 import LiveResearchPlannerV3
from .mgc_sim_execution_v3 import BridgeError


class LiveResearchPlannerV4(LiveResearchPlannerV3):
    def seed_for_startup(self,bars,state):
        bars=list(bars);cutoff=state['last_bar_utc']
        if not bars or bars[-1].time!=cutoff or any(b.time>cutoff for b in bars):
            raise BridgeError('Startup seed must end at native last closed candle without future bars')
        if any(state[k] for k in ('quantity','entry_working','orders_working','active_id','blocked','account_signed_quantity','ledger_uncertain')):
            raise BridgeError('Mid-session startup requires a flat reconciled native account')
        self.startup_watermark=cutoff
        self.seed(bars)
        self.synchronize(state)
        self.limit_order=None
        self.confirmation_time=self.touch_time=None
        local=cutoff.astimezone(CT)
        # Earlier source/attempt state is unknowable from prices alone. A late
        # start skips this one family rather than assuming its attempt is free.
        self.startup_or_skipped=(local.date().isoformat()==state['session']
            and local.hour*60+local.minute>135)
        if self.startup_or_skipped:self.or_attempted.add(state['session'])
        return dict(startup_watermark=cutoff.isoformat(),session=state['session'],
            opening_range_skipped=self.startup_or_skipped,seeded_bars=len(bars),
            earlier_trades_inferred=False,historical_orders_submitted=False,
            ledger_cash=50000+state['realized_net'],session_count=state['session_count'])

    def observe(self,bar,state,payloads):
        if hasattr(self,'startup_watermark') and bar.time<=self.startup_watermark:
            raise BridgeError('Historical/cutoff candle cannot be observed as a new live candle')
        return super().observe(bar,state,payloads)

    def prepare_entry(self,state,now,config):
        order=self.limit_order
        if order is not None and hasattr(self,'startup_watermark'):
            if order.signal.time<=self.startup_watermark or (self.confirmation_time is not None and self.confirmation_time<=self.startup_watermark):
                self.cancel_limit(now,'prestartup_source_or_confirmation')
                return None
        return super().prepare_entry(state,now,config)
