from __future__ import annotations

import math
import random


def day_block_bootstrap(values: list[float], *, block: int = 5, iterations: int = 2000, seed: int = 7193) -> dict | None:
    """Descriptive uncertainty under resampling, not a future-success probability.

    Moving blocks retain some adjacent-day dependence. The trading process and
    account ledger are not refit/replayed within each sample. All observed days,
    including inactive and halted days, belong in values.
    """
    if block < 1 or iterations < 100:
        raise ValueError("block must be positive; iterations must be at least 100")
    if any(not math.isfinite(v) for v in values):
        raise ValueError("bootstrap data must be finite")
    if len(values) < max(10, block * 2):
        return None
    rng = random.Random(seed)
    n = len(values)
    means = []
    for _ in range(iterations):
        sample = []
        while len(sample) < n:
            start = rng.randrange(n - block + 1)
            sample.extend(values[start:start+block])
        means.append(sum(sample[:n]) / n)
    means.sort()
    return {
        "method": "moving blocks of observed daily net PnL; no strategy refitting",
        "sessions_per_block": block, "iterations": iterations, "seed": seed,
        "mean_daily_net_ci95": [means[int(.025 * (iterations - 1))], means[int(.975 * (iterations - 1))]],
        "resamples_with_positive_mean_fraction": sum(v > 0 for v in means) / iterations,
        "warning": "Conditional on this sample and block length; does not undo selection bias or estimate guaranteed future profitability.",
    }
