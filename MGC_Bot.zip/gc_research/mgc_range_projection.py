"""Independent price-range TP; avoid treating every minor pivot as final TP."""
from dataclasses import replace
from datetime import timedelta

from .mgc_price_target import PriceTargetMgc
from .targets import TargetDecision


def range_target(history,stamp,entry,direction):
    """The existing prior-30m measured-move fallback, without a pivot veto.

    Stop, dollar risk, quantity and daily P&L are deliberately not inputs.
    """
    if not history or history[-1].time!=stamp:return None
    bins={}
    for b in history:
        if b.time>stamp:raise ValueError('Future range-target candle')
        phase=b.time.minute%5
        end=b.time+timedelta(minutes=5-phase) if phase else b.time
        if end>stamp:continue
        if end not in bins:bins[end]=[b.high,b.low]
        else:bins[end]=[max(bins[end][0],b.high),min(bins[end][1],b.low)]
    five=sorted(bins.items())[1:]
    if len(five)<12:return None
    prior=five[-7:-1]
    high=max(v[1][0] for v in prior);low=min(v[1][1] for v in prior)
    width=high-low
    if width<.1:return None
    raw=round(high+width-.1 if direction==1 else low-width+.1,10)
    if direction*(raw-entry)<.1-1e-8:return None
    return dict(price=raw,reason='prior30m_measured_move_no_minor_pivot_veto',box_high=high,box_low=low,
        projection_origin=prior[-1][0].isoformat(),inputs_end=stamp.isoformat())


class RangeProjectionMgc(PriceTargetMgc):
    def __init__(self,risk,payloads,*,explicit_research_risk=False,**kwargs):
        if not explicit_research_risk or risk.risk_per_trade not in (300,400) or risk.max_contracts!=40:
            raise ValueError('Explicit300/400total risk and40MGC research ceiling required')
        super().__init__(replace(risk,risk_per_trade=300),payloads,target_mode='structure',explicit_research_risk=True,**kwargs)
        self.risk=risk

    def __call__(self,ctx):
        result=range_target(self.structure_history,ctx.signal.time,ctx.entry,ctx.signal.direction)
        if result is None:return TargetDecision(False,'no_unexhausted_prior30m_projection',None,None,None,None)
        tp=self.instrument.price(result['price'],up=ctx.signal.direction==-1)
        reward=(ctx.signal.direction*(tp-ctx.entry)*10-self.risk.commission_round_trip)*ctx.quantity
        self.price_targets.append(dict(signal_time=ctx.signal.time.isoformat(),entry=ctx.entry,stop=ctx.stop,
            quantity=ctx.quantity,planned_risk=ctx.planned_risk,net_reward=reward,**result))
        if reward<=0:return TargetDecision(False,'projection_not_profitable_after_cost',None,None,None,None)
        derived=reward/ctx.planned_risk
        return TargetDecision(True,result['reason'],tp,derived,reward,derived)

    def report(self):
        r=super().report()
        r['independent_price_target'].update(mode='range_only',target_rule='Existing prior30m measured move, one tick inside; no nearest-pivot final exit; no stop/risk/quantity/goal input')
        return r
