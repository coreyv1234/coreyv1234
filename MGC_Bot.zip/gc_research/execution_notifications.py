"""Best-effort notifications outside the order/protection thread."""
from __future__ import annotations

import queue
import threading

from .notifications import DiscordNotifier


class ExecutionNotifications:
    def __init__(self, sender=None, capacity=100):
        self.sender = sender
        self.queue = queue.Queue(maxsize=capacity)
        self.sent = self.failed = self.dropped = 0
        self.stopping = threading.Event()
        self.thread = None
        if sender is not None:
            self.thread = threading.Thread(target=self._work, daemon=True, name="mgc-discord")
            self.thread.start()

    @classmethod
    def from_environment(cls, enabled=False):
        # No delivery, URL access, or environment requirement unless explicitly enabled.
        return cls(DiscordNotifier.from_environment() if enabled else None)

    def publish(self, message):
        if self.sender is None or self.stopping.is_set():
            return False
        try:
            self.queue.put_nowait(str(message)[:2000])
            return True
        except queue.Full:
            self.dropped += 1
            return False

    def _work(self):
        while not self.stopping.is_set():
            try:
                message = self.queue.get(timeout=.1)
            except queue.Empty:
                continue
            try:
                self.sender.send(message)
                self.sent += 1
            except Exception:
                # Never expose the exception (it may include a URL). Never retry an order.
                self.failed += 1
            finally:
                self.queue.task_done()

    def close(self):
        self.stopping.set()
        if self.thread is not None:
            self.thread.join(timeout=.2)
