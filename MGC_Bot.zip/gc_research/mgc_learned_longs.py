"""Monthly past-trained gates for added longs; legacy source entries unchanged."""
from datetime import datetime,timedelta
import hashlib,json
import numpy as np
from .market import CT
from .mgc_native_model import FEATURES,fit_model,predict
from .mgc_symmetric_entries import ContextMgcReplay

def fit_long(rows,available,kind):
    if kind=='ridge':return fit_model(rows,available)
    if kind!='tree':raise ValueError('Unregistered model')
    from sklearn.tree import DecisionTreeRegressor
    cutoff=datetime.fromisoformat(available).replace(tzinfo=CT)-timedelta(hours=7)
    if len(rows)<60 or any(datetime.fromisoformat(r['exit_time'])>=cutoff for r in rows):raise ValueError('Insufficient or future training outcomes')
    x=np.asarray([r['features'] for r in rows]);y=np.asarray([r['net_r'] for r in rows])
    model=DecisionTreeRegressor(max_depth=2,min_samples_leaf=30,random_state=7193).fit(x,y);tree=model.tree_
    out={'kind':'shallow_expected_net_r_tree','max_depth':2,'min_samples_leaf':30,'features':FEATURES,
        'left':tree.children_left.tolist(),'right':tree.children_right.tolist(),'feature':tree.feature.tolist(),
        'threshold':tree.threshold.tolist(),'value':tree.value.reshape(-1).tolist(),
        'available_from_session':available,'training_rows':len(rows),'last_label_exit':max(r['exit_time'] for r in rows)}
    out['sha256']=hashlib.sha256(json.dumps(out,sort_keys=True).encode()).hexdigest();return out

def long_score(model,features):
    if model['kind']=='standardized_ridge_expected_net_r':return predict(model,features)
    i=0
    while model['left'][i]!=-1:
        i=model['left'][i] if features[model['feature'][i]]<=model['threshold'][i] else model['right'][i]
    return model['value'][i]

class LearnedLongMgc(ContextMgcReplay):
    def __init__(self,*args,models,**kwargs):
        super().__init__(*args,policy='mirror_longs_only',**kwargs)
        self.long_models=sorted(models,key=lambda m:m['available_from_session']);self.learned_long_decisions=[]

    def entry_payloads(self,stamp):
        source=super().entry_payloads(stamp);allowed=[]
        for p in source:
            if not p.get('mirrored_long',False):allowed.append(p);continue
            models=[m for m in self.long_models if m['available_from_session']<=p['session_date']]
            model=models[-1] if models else None
            score=None
            if model is not None:
                if datetime.fromisoformat(model['last_label_exit'])>=stamp:raise ValueError('Future new-long label used')
                score=long_score(model,p['features'])
            accepted=score is not None and score>0
            self.learned_long_decisions.append({'signal_time':stamp.isoformat(),'family':p['event_family'],'accepted':accepted,
                'expected_net_r':score,'model_sha256':model['sha256'] if model else None})
            if accepted:allowed.append(p)
            else:self.rejections['new_long_no_past_positive_expectancy']+=1
        return allowed

    def report(self):
        r=super().report();r['new_long_model_schedule']=[{k:m[k] for k in ['kind','sha256','available_from_session','training_rows','last_label_exit']} for m in self.long_models]
        return r
