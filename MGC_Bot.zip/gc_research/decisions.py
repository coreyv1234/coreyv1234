"""Immutable entry-time information; intentionally excludes the entry bar close.

Constructed at the next bar's modeled open, from past completed bars and known
entry geometry. Execution adapters must supply the equivalent available inputs.
"""
from dataclasses import dataclass
from datetime import datetime

from .features import FeatureFrame
from .strategy import Signal


@dataclass(frozen=True)
class EntryContext:
    signal: Signal
    entry_time: datetime
    entry: float
    stop: float
    target: float
    quantity: int
    planned_risk: float
    fees_per_contract: float
    exit_slippage_points: float
    features: FeatureFrame | None
    prior_high12: float | None
    prior_low12: float | None
    close_three_minutes_ago: float | None


@dataclass(frozen=True)
class EntryDecision:
    accepted: bool
    reason: str
    probability_win: float | None = None
    expected_net_r: float | None = None
    probability_payoff_net_r: float | None = None
