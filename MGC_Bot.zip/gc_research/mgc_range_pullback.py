"""One preregistered passive entry alternative; offline OHLC research only.

The source gates, independent range target, full invalidation stop and account
controls are inherited. A pending order commits its entire bracket and quantity
at source close; no subsequent quote can resize or replace it.
"""
from dataclasses import asdict, dataclass, replace
from datetime import datetime, timedelta
import hashlib
import math

from .backtest import Position
from .decisions import EntryContext
from .market import CT, MINUTE, instrument_root
from .mgc_range_opportunity import RangeOpportunityMgc
from .scaleout import ScaleState
from .strategy import Signal

POLICY = 'passive_quarter_atr_three_minutes'


@dataclass(frozen=True)
class PendingLimit:
    order_id: str
    signal: Signal
    expiry: datetime
    limit: float
    stop: float
    target: float
    quantity: int
    planned_risk: float
    cash_at_source: float
    highwater_at_source: float
    source_budget: float
    budget_ceiling: float


class RangePullbackMgc(RangeOpportunityMgc):
    """All-or-none limit simulation, requiring one full tick trade-through.

    Intrabar fill times are unknown. The fill bar's favorable extreme is
    restricted to its close and the entry, while its full adverse extreme is
    retained. An opening trade-through has known ordering and uses the full bar.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, policy='incumbent', **kwargs)
        if self.risk.risk_per_trade != 400 or self.risk.max_contracts != 10:
            raise ValueError('Pullback research requires fixed400/max10MGC')
        self.limit_order = None
        self.orders = []
        self.order_events = []
        self.fills = []
        self.pending_gap_events = []
        self.trade_timing = {}

    def _eligible_source(self, b):
        loc = b.time.astimezone(CT)
        locked = self.risk.daily_profit_target is not None and self.balance-self.session_open >= self.risk.daily_profit_target-1e-8
        return (not self.halted and not self.daily_halted and not locked and
            self.position is None and self.limit_order is None and
            loc.weekday() < 5 and self.risk.entry_start_ct <= loc.hour*60+loc.minute < self.risk.entry_end_ct and
            self.session_count < self.risk.max_trades_per_session and b.session not in self.blocked_dates and
            self.entry_guard(replace(b, time=b.time+MINUTE)))

    def place_limit(self, b):
        """Uses only the just-completed source and already known account state."""
        if not self._eligible_source(b):
            return None
        stamp = b.time
        if not self.structure_history or self.structure_history[-1].time != stamp:
            raise ValueError('Source-time target history must end at source close')
        if any(v.time > stamp for v in self.structure_history):
            raise ValueError('Future source-time target history')
        for source in self.entry_payloads(stamp):
            family = source['event_family']
            if source['session_date'] != b.session:
                raise ValueError('Wrong canonical source session')
            if family.startswith('ADDON_') and self.session_count >= 4:
                continue
            d = 1 if source['direction'] == 'LONG' else -1
            atr = float(source['atr'])
            if not math.isfinite(atr) or atr <= 0:
                raise ValueError('Invalid canonical source ATR')
            # Round away from the market: buy down, sell up. Never cross.
            entry = self.instrument.price(float(source['signal_close'])-d*.25*atr, up=d == -1)
            raw = float(source['invalidation_price'])
            distance = d*(entry-raw)
            if distance <= 0:
                self.rejections['source_invalidation_already_passed'] += 1
                continue
            floor = .42 if family.startswith(('SCALP_', 'ADDON_')) else .62 if not family.startswith('PROBE_') else 0.
            stop = self.instrument.price(entry-d*max(distance, floor*atr, 1.2), up=d == -1)
            self.family_cap = min(400., float(source['risk_budget_dollars']))
            budget = self.risk_budget()
            charges = self.risk.commission_round_trip+self.risk.slippage_ticks_per_side*self.instrument.tick_size*self.instrument.point_value
            per = d*(entry-stop)*self.instrument.point_value+charges
            quantity = min(self.risk.max_contracts, int((budget+1e-8)//per))
            if quantity < 1:
                self.rejections['insufficient_risk_budget'] += 1
                continue
            planned = per*quantity
            signal = Signal(stamp, b.instrument, d, family, float(source['signal_close']), stop, atr)
            ctx = EntryContext(signal, stamp, entry, stop, entry, quantity, planned,
                self.risk.commission_round_trip, self.risk.slippage_ticks_per_side*self.instrument.tick_size,
                None, None, None, None)
            decision = self(ctx)
            self.target_decisions.append(dict(signal_time=stamp.isoformat(), entry_time=stamp.isoformat(),
                direction=d, quantity=quantity, entry=entry, stop=stop, planned_risk=planned,
                committed_at_source_close=True, **asdict(decision)))
            if not decision.accepted:
                self.rejections[decision.reason] += 1
                continue
            target = decision.target
            if target is None or not math.isfinite(target) or d*(target-entry) <= 0:
                raise ValueError('Invalid independently calculated target')
            noon = stamp.astimezone(CT).replace(hour=12, minute=0, second=0, microsecond=0)
            expiry = min(stamp+3*MINUTE, noon.astimezone(stamp.tzinfo))
            ident = hashlib.sha256(f'{stamp.isoformat()}|{b.instrument}|{family}|{d}'.encode()).hexdigest()[:32]
            order = PendingLimit(ident, signal, expiry, entry, stop, target, quantity, planned,
                self.balance, self.trailing_peak, float(source['risk_budget_dollars']), budget)
            self.limit_order = order
            self.orders.append(dict(order_id=ident, source_time=stamp.isoformat(), session=b.session,
                instrument=b.instrument, family=family, direction=d, expiry=expiry.isoformat(),
                limit=entry, stop=stop, target=target, quantity=quantity, planned_risk=planned,
                source_budget=order.source_budget, budget_ceiling=budget, cash_at_source=self.balance,
                session_open_at_source=self.session_open, highwater_at_source=self.trailing_peak,
                target_inputs_end=self.structure_history[-1].time.isoformat(), status='working'))
            self.order_events.append(dict(order_id=ident, time=stamp.isoformat(), event='placed'))
            return order
        return None

    def cancel_limit(self, stamp, reason):
        order = self.limit_order
        if order is None:
            return
        self.orders[-1].update(status=reason, cancellation_time=stamp.isoformat())
        self.order_events.append(dict(order_id=order.order_id, time=stamp.isoformat(), event=reason))
        self.limit_order = None

    def fill_limit(self, b):
        order = self.limit_order
        if order is None:
            return b
        if b.time > order.expiry:
            self.cancel_limit(order.expiry, 'expired')
            return b
        if b.time <= order.signal.time:
            raise ValueError('Cannot fill on the source candle')
        if b.instrument != order.signal.instrument or b.session != self.orders[-1]['session']:
            self.cancel_limit(b.time-MINUTE, 'contract_or_session_boundary')
            return b
        d = order.signal.direction
        through = self.instrument.price(order.limit-d*self.instrument.tick_size, up=d == -1)
        traded = b.low <= through+1e-8 if d == 1 else b.high >= through-1e-8
        if not traded:
            return b
        opening = b.open <= through+1e-8 if d == 1 else b.open >= through-1e-8
        timing = 'opening_gap' if opening else 'intrabar_time_unknown'
        stamp = b.time-MINUTE if opening else b.time
        self.position = Position(order.signal, stamp, order.limit, order.stop, order.target,
            order.quantity, order.planned_risk)
        self.initial_stop = order.stop
        self.scale_state = ScaleState(order.quantity, 0, order.target)
        self.entry_bars.clear()
        self.session_count += 1
        if order.quantity == 1:
            self.one_contract_fallback_entries += 1
        row = dict(order_id=order.order_id, source_time=order.signal.time.isoformat(),
            fill_time=stamp.isoformat(), fill_bar_end=b.time.isoformat(), entry_timing=timing,
            entry=order.limit, stop=order.stop, target=order.target, quantity=order.quantity,
            planned_risk=order.planned_risk, favorable_extreme_censored=not opening,
            full_observed_high=b.high, full_observed_low=b.low)
        self.fills.append(row)
        self.trade_timing[(order.signal.time.isoformat(), stamp.isoformat())] = row
        self.orders[-1].update(status='filled', fill_time=stamp.isoformat(), fill_bar_end=b.time.isoformat(), entry_timing=timing)
        self.order_events.append(dict(order_id=order.order_id, time=stamp.isoformat(), event='filled'))
        self.limit_order = None
        if opening:
            return b
        # The pre-fill favorable high/low cannot earn a TP after entry.
        return replace(b, open=order.limit,
            high=max(order.limit, b.close) if d == 1 else b.high,
            low=b.low if d == 1 else min(order.limit, b.close))

    def step(self, b):
        if self.finished:
            raise RuntimeError('Finalized pullback replay')
        if b.time.tzinfo is None or b.time.utcoffset() != timedelta() or b.time.second or b.time.microsecond:
            raise ValueError('Expected UTC minute end')
        if instrument_root(b.instrument) != 'MGC' or b.instrument == 'MGC':
            raise ValueError('Wrong root or missing expiry')
        if self.previous is not None and b.time <= self.previous.time:
            raise ValueError('Pullback replay requires strictly increasing bars')
        selected = (self.start is None or b.session >= self.start) and (self.end is None or b.session < self.end)
        gap = self.previous is not None and (b.time-self.previous.time != MINUTE or b.instrument != self.previous.instrument or b.session != self.previous.session)
        if gap and self.limit_order is not None:
            order = self.limit_order
            resolved = ((self.previous.time, b.time) in self.zero_trade_gaps and
                self.previous.instrument == b.instrument and self.previous.session == b.session)
            self.pending_gap_events.append(dict(order_id=order.order_id, source_time=order.signal.time.isoformat(),
                previous_bar=self.previous.time.isoformat(), next_bar=b.time.isoformat(), expiry=order.expiry.isoformat(),
                resolved_zero_trade=resolved, expiry_inside_gap=order.expiry < b.time))
            if not resolved:
                # A cancellation after unknown minutes cannot erase a possible
                # missing fill. The run remains disqualified even without PnL.
                self.cancel_limit(b.time-MINUTE, 'unknown_pending_gap_disqualified')
            elif b.time > order.expiry:
                self.cancel_limit(order.expiry, 'expired_during_attested_zero_trade_gap')
        if b.session != self.session:
            self.finish_session()
            self.session, self.session_open = b.session, self.balance
            self.daily_halted, self.session_count = False, 0
        if self.position is not None and gap:
            resolved = (self.previous.time, b.time) in self.zero_trade_gaps
            self.gap_events.append(dict(entry_time=self.position.entry_time.isoformat(),
                previous_bar=self.previous.time.isoformat(), next_bar=b.time.isoformat(), resolved_zero_trade=resolved))
            if not resolved:
                self.close_position(b.open, b.time-MINUTE, 'DATA_GAP_NEXT_QUOTE')
        if not selected:
            self.cancel_limit(b.time-MINUTE, 'evaluation_boundary')
            if self.position is not None:
                self.close_position(b.open, b.time-MINUTE, 'EVALUATION_BOUNDARY')
        if selected:
            self.active_sessions.add(b.session)
            managed = self.fill_limit(b)
            self.manage(managed)
            equity = self.balance
            if self.position is not None:
                p = self.position
                charges = self.risk.commission_round_trip+self.risk.slippage_ticks_per_side*self.instrument.tick_size*self.instrument.point_value
                equity += ((b.close-p.entry)*p.signal.direction*self.instrument.point_value-charges)*p.quantity
            self.check_equity(equity)
            self.equity_curve.append((b.time.isoformat(), equity))
            if self.limit_order is not None and b.time >= self.limit_order.expiry:
                self.cancel_limit(self.limit_order.expiry, 'expired')
        self.on_bar(b)
        source = self.engine.on_bar(b)
        if source is not None and selected:
            self.signals.append(source)
            if self.limit_order is not None:
                self.rejections['source_cannot_replace_resting_order'] += 1
            self.place_limit(b)
        self.pending = None
        self.pending_features = None
        self.pending_history = tuple(self.engine.history)
        self.previous = b
        self.bars_processed += 1

    def finish(self):
        if self.limit_order is not None:
            self.cancel_limit(self.previous.time, 'data_end_unfilled_unresolved')
        return super().finish()

    def report(self):
        r = super().report()
        r['passive_pullback'] = dict(policy=POLICY, accepted_orders=len(self.orders), actual_fills=len(self.fills),
            unfilled_orders=len(self.orders)-len(self.fills),
            unresolved_pending_gaps=sum(not v['resolved_zero_trade'] for v in self.pending_gap_events),
            unresolved_pending_at_end=sum(v['status'] == 'data_end_unfilled_unresolved' for v in self.orders),
            contract_and_bracket_committed_at_source=True, limit_cannot_slip=True,
            fill_bar_favorable_extreme_censored=True, all_or_none_fill_assumption=True,
            intrabar_fill_time_exact=False, native_adapter=False, orders=False)
        return r
