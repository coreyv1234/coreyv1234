"""Causal, cost-aware 2R/3R research targets. No execution interface.

Recent range is a capacity heuristic, not a calibrated probability that a target
will be reached. Targets are frozen at entry; no future excursion is consulted.
"""
from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass

from .decisions import EntryContext
from .market import INSTRUMENTS, MINUTE, instrument_root


@dataclass(frozen=True)
class TargetDecision:
    accepted: bool
    reason: str
    target: float | None = None
    requested_net_r: float | None = None
    planned_net_reward: float | None = None
    actual_planned_net_r: float | None = None
    prior_range_60: float | None = None


class TargetPlanner:
    def __init__(self, mode):
        if mode not in {'net_1r', 'net_2r', 'net_3r', 'adaptive_2_3'}:
            raise ValueError('unknown target mode')
        self.mode = mode
        self.history = deque(maxlen=60)
        self.previous = None

    def on_bar(self, bar):
        if self.previous:
            if bar.time <= self.previous.time:
                raise ValueError('target history must advance')
            if (bar.time-self.previous.time != MINUTE or
                    bar.instrument != self.previous.instrument or
                    bar.session != self.previous.session):
                self.history.clear()
        self.history.append(bar)
        self.previous = bar

    @staticmethod
    def net_target(ctx: EntryContext, multiple):
        inst = INSTRUMENTS[instrument_root(ctx.signal.instrument)]
        # Entry slippage is already inside ctx.entry; planned risk includes
        # adverse stop slippage and round-trip fees. A target is a limit fill.
        distance = (multiple*ctx.planned_risk/ctx.quantity+ctx.fees_per_contract)/inst.point_value
        target = inst.price(ctx.entry+ctx.signal.direction*distance, up=ctx.signal.direction == 1)
        reward = (ctx.signal.direction*(target-ctx.entry)*inst.point_value
                  - ctx.fees_per_contract)*ctx.quantity
        return target, reward

    def __call__(self, ctx):
        if (ctx.signal.direction not in (-1, 1) or ctx.quantity < 1 or
                not all(math.isfinite(v) for v in [ctx.entry, ctx.planned_risk, ctx.fees_per_contract]) or
                ctx.planned_risk <= 0 or ctx.fees_per_contract < 0):
            return TargetDecision(False, 'target_invalid_entry_geometry')
        capacity = None
        if self.mode == 'adaptive_2_3':
            if (len(self.history) != 60 or self.previous.time != ctx.signal.time or
                    self.previous.instrument != ctx.signal.instrument or ctx.features is None):
                return TargetDecision(False, 'target_missing_past_context')
            capacity = max(b.high for b in self.history)-min(b.low for b in self.history)
            f = ctx.features
            values = [f.velocity_atr_per_minute, f.acceleration_atr_per_minute2, f.efficiency_20]
            if any(v is None or not math.isfinite(v) for v in values):
                return TargetDecision(False, 'target_missing_past_context')
            target2, _ = self.net_target(ctx, 2)
            target3, _ = self.net_target(ctx, 3)
            if abs(target2-ctx.entry) > capacity+1e-8:
                return TargetDecision(False, 'target_2r_exceeds_prior_range', prior_range_60=capacity)
            strong = (ctx.signal.direction*f.velocity_atr_per_minute > 0 and
                      ctx.signal.direction*f.acceleration_atr_per_minute2 >= 0 and
                      f.efficiency_20 >= .30)
            multiple = 3 if strong and abs(target3-ctx.entry) <= capacity+1e-8 else 2
            reason = 'target_3r_momentum_and_range' if multiple == 3 else 'target_2r_default'
        else:
            multiple = {'net_1r': 1, 'net_2r': 2, 'net_3r': 3}[self.mode]
            reason = 'target_fixed_net_'+str(multiple)+'r'
        target, reward = self.net_target(ctx, multiple)
        return TargetDecision(True, reason, target, multiple, reward, reward/ctx.planned_risk, capacity)
