@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL_SIM_BRIDGE.ps1" 
pause
