@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0START_SIM.ps1" -Status
pause
