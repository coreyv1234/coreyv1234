MGC flat candle-gap repair — Sim101 only

1. Stop the Python controller. Disable the NinjaTrader strategy.
2. Confirm actual Sim101 Positions are flat and Orders has no working orders.
3. Extract this ZIP into your existing MGC_Bot_With_Setup folder.
4. Run py .\Repair_MGC_Continuity.py and type CONTINUITY after those checks.
5. The existing private launcher starts automatically. After Startup file written,
   enable SovereignMgcResearchSimBridgeV3 on Sim101 with the existing bridge path.
No C# change or F5 compilation is needed. DoNotMerge and full ETH history remain.

Requires the earlier connection, chart-history and detailed Discord updates.
Only the Python controller and one new Python helper are installed. Original model,
native source, financial settings, persistent ledger and private webhook launcher stay.
The installer verifies payload/public package hashes and backs up changed public files.

Flat gaps: verify account/order/callback reconciliation; discard unsubmitted setup;
rebuild price context through latest completed candle; preserve native financial state,
prior submitted-source IDs, opening-range attempts, consumed setups and day decisions.
No missing candles are fabricated. No skipped candle or current resync candle is traded.
Wait for a NEW completed minute. Terminal and Discord report FLAT_RESYNC; details are
in the run folder's continuity_events.jsonl.

Gap during exposure, pending orders/commands or uncertain fills STILL HALTS and requests
flatten. Native heartbeat, quote freshness, loss reserves and safety closes remain.
The old heartbeat-lost message after stopping Python belongs to the old halted native
run; re-enabling from confirmed flat creates a new run. No unattended auto-restart.

The log alone cannot identify whether the jump was missing chart candles or processing
delay. Recovery records elapsed clock minutes and rows actually present for diagnosis.
This update is not a Windows/NinjaTrader fill certification or a profitability upgrade.
Entries remain 02:00–12:00 Chicago; a 20:14 UTC November9 join is 14:14 Chicago, after
the entry window. Existing strategy/no-trade conditions still apply.
