"""Recover a flat controller's market context without replaying trade decisions."""
from .mgc_sim_execution_v3 import BridgeError


def require_flat_resync(state, pending_commands=False, recent_entry_command=False):
    if state['account'] != 'Sim101' or state['phase'] != 'REALTIME':
        raise BridgeError('Minute gap recovery requires realtime Sim101')
    fields = ('quantity', 'direction', 'entry_working', 'orders_working', 'active_id',
              'blocked', 'account_signed_quantity', 'ledger_uncertain', 'pending_exit_callbacks')
    if any(state[k] for k in fields):
        raise BridgeError('Minute gap with exposure, working orders, halt or uncertain callbacks; reconcile a flat run')
    if state['entry_executed'] != state['exit_executed']:
        raise BridgeError('Minute gap with unreconciled execution quantities')
    if state['entry_reported_filled'] > state['entry_executed']:
        raise BridgeError('Minute gap with outstanding entry execution callbacks')
    if pending_commands or recent_entry_command:
        raise BridgeError('Minute gap with a pending or recently submitted command; reconcile a flat run')


def reseed_flat(previous, factory, bars, state, *, pending_commands=False, recent_entry_command=False):
    require_flat_resync(state, pending_commands, recent_entry_command)
    bars = list(bars)
    fresh = factory()
    # Keep decisions about attempts and prior commands. Only price context and
    # unsubmitted proposals are rebuilt; native cash/fills remain authoritative.
    for name in ('sent_sources', 'or_attempted', 'consumed_setups'):
        getattr(fresh, name).update(getattr(previous, name))
    fresh.day_decisions.update(previous.day_decisions)
    receipt = fresh.seed_for_startup(bars, state)
    receipt.update(event='FLAT_RESYNC', discarded_unsubmitted_setup=previous.limit_order is not None,
                   recovery_submitted_orders=False, wait_for_new_candle=True)
    return fresh, receipt
