"""Read-only explanation of native Last-event and completed-chart delivery."""
import pandas as pd


def analyze_delivery(frame):
    if frame.empty:
        return {'status':'WAIT_FOR_TRACE','orders_sent':False}
    frame=frame.copy()
    frame['receipt']=pd.to_datetime(frame.receipt_utc,utc=True,format='mixed')
    end=frame.receipt.iloc[-1]
    recent=frame.loc[frame.receipt>=end-pd.Timedelta(seconds=120)]
    first,last=recent.iloc[0],recent.iloc[-1]
    elapsed=(last.receipt-first.receipt).total_seconds()
    last_delta=int(last.last_events)-int(first.last_events)
    exported=recent.loc[recent.event=='EXPORTED'].copy()
    gaps=[]
    for (_,a),(_,b) in zip(exported.iloc[:-1].iterrows(),exported.iloc[1:].iterrows()):
        minutes=(pd.Timestamp(b.bar_utc)-pd.Timestamp(a.bar_utc)).total_seconds()/60
        if minutes>1:
            gaps.append({'previous':a.bar_utc,'next':b.bar_utc,'minutes':minutes,
                'actual_chart_index_advance':int(b.chart_index)-int(a.chart_index)})
    if (recent.event=='CLOCK_AHEAD_ERROR').any():status='CHART_CLOCK_AHEAD_ERROR'
    elif elapsed<60:status='NEED_AT_LEAST_60_SECONDS_OF_TRACE'
    elif last_delta==0:status='NO_LAST_TRADE_EVENTS_IN_TRACE_WINDOW'
    elif gaps:status='ACTUAL_CHART_TIMESTAMPS_SKIP_MINUTES'
    elif len(exported)<1:status='LAST_EVENTS_WITHOUT_NEW_CLOSED_CHART_BARS'
    else:status='CLOSED_BARS_AND_LAST_EVENTS_PRESENT'
    return {'status':status,'trace_window_seconds':round(elapsed,3),
        'last_trade_events_received':last_delta,'bid_events_received':int(last.bid_events)-int(first.bid_events),
        'ask_events_received':int(last.ask_events)-int(first.ask_events),
        'exported_bars_in_window':len(exported),'chart_time_gaps':gaps,
        'future_closed_candles_deferred':int((recent.event=='DEFERRED_FUTURE').sum()),
        'pending_closed_bars':int(last.pending_closed_bars),
        'last_trade_receipt_utc':str(last.last_trade_receipt_utc),
        'bid_age_seconds':float(last.bid_age_seconds),'ask_age_seconds':float(last.ask_age_seconds),
        'orders_sent':False,'limits':'Receipt counts diagnose delivery, not connection licensing, exchange provenance or profitable execution.'}
