"""Read-only feed/bar diagnosis. No orders, notifications or secrets accessed."""
import argparse
import json
from datetime import datetime,timezone
from pathlib import Path
from gc_research.mgc_bridge_io_v5 import read_complete_csv
from gc_research.mgc_feed_diagnostics_v10 import analyze_delivery
from gc_research.mgc_sim_execution_v3 import ExecutionConfig,BridgeError
from tools.run_mgc_research_sim_v4 import bridge_directory,load_native


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bridge',type=Path,default=bridge_directory())
    args=parser.parse_args()
    folder,state=load_native(args.bridge,ExecutionConfig())
    frame=read_complete_csv(folder/'bar_delivery.csv')
    report=analyze_delivery(frame)
    now=datetime.now(timezone.utc)
    report.update(account=state['account'],instrument=state['instrument'],
        phase=state['phase'],native_reason=state['reason'],blocked=bool(state['blocked']),
        latest_closed_bar_utc=state['last_bar_utc'].isoformat(),
        native_snapshot_age_seconds=round((now-state['updated_utc']).total_seconds(),3),
        quote_age_seconds=round((now-state['quote_utc']).total_seconds(),3),
        native_quantity=state['quantity'],entry_working=bool(state['entry_working']))
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    try:main()
    except (OSError,ValueError,BridgeError) as error:
        print(json.dumps({'read_error':str(error),'orders_sent':False}))
