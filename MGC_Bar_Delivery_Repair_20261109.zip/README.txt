MGC completed-bar delivery repair — native build20261109SIM10

Requires the prior flat-continuity repair. Sim101 only.
1. Stop Python. Disable SovereignMgcResearchSimBridgeV3. Confirm actual Sim101
   is flat with NO working orders. Do not install during an open trade.
2. Extract this ZIP into your existing MGC_Bot_With_Setup folder.
3. Run py .\Repair_MGC_Bar_Delivery.py. Type BARS after those checks.
4. The installer updates the existing native source in NinjaTrader's Strategies
   directory. Reopen SovereignMgcResearchSimBridgeV3 in NinjaScript Editor,
   accept reload if prompted, and press F5. There must be zero compile errors.
5. Return to the repair terminal and press Enter only AFTER compilation succeeds.
   Your existing private launcher starts. After Startup file written, enable the
   SAME strategy on Sim101. Bridge directory remains LocalAppData/SovereignMGC/ExecutionBridge.

Code correction: the prior bridge discarded a callback with Time[0] slightly ahead
of PC UTC, never retrying that candle. SIM10 queues CLOSED realtime callbacks up
to five seconds ahead and retries from the native timer only after wall time reaches
their timestamp. Historical future tails remain excluded. Larger clock errors halt.
Already completed actual chart bars are recovered by index if an export callback
was skipped. No missing or zero-volume candles are invented. Old trade signals
are not replayed; the prior flat-only resync and stale-command guards remain.

NEW TRACE: each run now has bar_delivery.csv. It records Last/Bid/Ask receipt counts,
closed-bar capture/export, deferred timestamps and chart indices. Polls every15seconds
also record periods without a bar callback. This separates exporter gaps from sparse
incoming Last-trade data. Quote-only activity does not prove trade data is arriving.

After at least two minutes of realtime operation, use a SECOND PowerShell terminal:
  Set-Location "C:\Users\corey\Downloads\MGC_Bot_With_Setup"
  .\.venv\Scripts\python.exe .\Diagnose_MGC_Feed.py
Paste its JSON output if resyncs continue. It is read-only; it sends no orders or Discord.

Strategy, sizing, stops, targets, sessions, persistent account ledger and Discord
settings are unchanged. No private webhook is bundled. The original native order,
execution, protection and ledger method bodies are unchanged. SDK compilation and
native realtime behavior cannot be certified in this Linux workspace: F5 on your
NinjaTrader installation remains required. This fixes an exporter defect; it cannot
create trades or candles that your connected data feed never supplies.
