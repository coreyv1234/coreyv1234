MGC order lifecycle repair — SIM19 — SIM101 ONLY

This fixes the uploaded normal-stop/callback timing failure and a separate
NinjaTrader platform connection-loss auto-disable. Trading model unchanged.

1. Protection coverage uses immutable OnOrderUpdate parameter snapshots instead
   of asynchronously changing Order objects. A stop entering trigger/fill state
   cannot falsely appear to have disappeared before its callbacks reconcile.
   Stop/target amendments retain only previously acknowledged coverage for at
   most3seconds; new/unaccepted or explicitly cancelled/rejected protection does
   not get counted. Real deficits are logged with per-order callback state.
2. Observed cumulative fills on owned native exits cause a bounded callback
   wait, never a synthetic fill, balance update or flat-position assumption.
   The ten-second callback deadline starts at first pending observation and
   cannot be extended by unrelated order updates. Genuine missing callbacks,
   account mismatch, order rejection and protection failure still block trading.
3. ConnectionLossHandling=KeepRunning is set in Defaults AND Configure so an
   old saved chart setting cannot retain the platform ten-second auto-restart.
   This leaves the bridge running to monitor recovery; it does not reconnect
   a dead provider or submit orders using stale data. Existing30second native
   feed-loss handling and reconciled-flat recovery remain active. Real-time
   error handling remains StopCancelClose; heartbeat/account/risk guards remain.
4. Normal stop exits reconcile and return to scanning rather than competing
   with an unnecessary emergency market order. This repairs continuation after
   a losing trade; it does not rewrite that loss into a win or change signals.

VALIDATION:
Actual production callback handlers, main checking loop and helper methods
executed with the recorded native callback sequence, a controlled UTC clock and
synthetic order/account API stubs. Original stop fills reconcile to the recorded
net loss, no emergency order is submitted, ledger retained and scanning resumes.
90partial-fill sequences and missing-protection/timeout/amendment checks pass.
These tests are NOT NinjaTrader SDK/runtime certification. F5 and subsequent
observed Sim101 operation remain required. No cloud orders or Discord messages.

INSTALL over SIM18:
Stop Python; disable the strategy; confirm Sim101 flat and no working orders.
Extract into existing MGC_Bot_With_Setup. Run:
  py .\Repair_MGC_Order_Lifecycle.py
Type ORDERS. Reopen SovereignMgcResearchSimBridgeV3 source in NinjaScript Editor,
accept reload and F5. Resolve every compile error. Return to terminal, Enter.
After Startup file written, enable SAME strategy on actual MGC one-minute chart,
Sim101 only. Startup must say Native SIM19; native build is20261113SIM19.
Connection must supply updating data; if provider remains disconnected/panicked,
reconnect it in NinjaTrader first. This repair cannot restore a failed service.

Account cash, highwater, daily opening balance, loss reserve, counts, fee and
model files are preserved. NO ledger reconciliation/reset is included. Existing
private launcher/webhook is untouched. Financial effects of losing trades remain.
The normal02:00–12:00Chicago entry window and15:55safety close stay unchanged;
starting after noon does not permit new entries that afternoon.
