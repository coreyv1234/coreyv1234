"""Mid-session Sim101 controller with required Discord startup delivery."""
import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import time

import pandas as pd

from gc_research.backtest import RiskConfig
from gc_research.execution_notifications import ExecutionNotifications
from gc_research.market import Bar,CT
from gc_research.mgc_day_precision import day_features
from gc_research.mgc_execution import BridgeError,ID,atomic_text,utc,validate_chart_rows
from gc_research.mgc_live_research_planner_v14 import LiveResearchPlannerV14 as LiveResearchPlanner
from gc_research.mgc_sim_discord_v4 import confirmed_notifications,NotificationHealth
from gc_research.mgc_live_signals import latest_source,normalized_minutes
from gc_research.mgc_sim_execution_v3 import ExecutionConfig,parse_state,healthy_state,protective_stop,write_command,command
from tools.run_mgc_range_execution import load_brain,verify_release,NativeJournalNotifications,write_startup
from gc_research.mgc_heartbeat_v11 import Heartbeat

from gc_research.mgc_bridge_io_v5 import read_bridge_text,read_complete_csv
from gc_research.mgc_chart_history_v14 import IncrementalChartHistory as ChartHistory
from gc_research.mgc_flat_resync_v9 import require_flat_resync,reseed_flat
from gc_research.mgc_snapshot_wait_v13 import transient_status_error,entry_awaiting_reconciliation
from gc_research.mgc_submission_watch_v16 import SubmissionWatch
from gc_research.mgc_feed_wait_v18 import awaiting_feed_recovery

from gc_research.mgc_discord_detail_v8 import make_notifications,WaitingHeartbeat,drain_notifications

BUILD='20261113SIM19'


class SimJournalNotifications(NativeJournalNotifications):
    def poll(self,account):
        if not self.path.exists():return
        rows=read_complete_csv(self.path).fillna('').to_dict('records')
        for row in rows[self.seen:]:
            if row['event'] in self.EVENTS:
                cash=50000.+float(row['cumulative_net'])
                self.notifications.publish(f"Sim101 | {row['event']} | qty {row['quantity']} | price {row['price']} | simulation ledger ${cash:.2f} | test PnL ${cash-48615.:.2f} (assumed fees) | {row['detail']}")
        self.seen=len(rows)


def bridge_directory():
    from tools.run_mgc_range_execution import default_bridge_directory
    import os
    local=os.environ.get('LOCALAPPDATA')
    return Path(local)/'SovereignMGC'/'ExecutionBridge' if local else default_bridge_directory().parent/'SovereignResearchSimV3'


def settings(path):
    value=json.loads(Path(path).read_text())
    if value.get('expected_account')!='Sim101' or value.get('account_mode')!='simulation':
        raise BridgeError('This release only supports Sim101')
    cfg=ExecutionConfig('Sim101','simulation',10)
    if (value.get('max_contracts')!=10 or value.get('initial_cash')!=48615
            or value.get('initial_session_cash')!=48615 or value.get('firm_trailing_threshold')!=48015
            or value.get('reconcile_at_startup') is not False):
        raise BridgeError('Use the reviewed600-cushion simulation settings; do not silently reconcile/reset a ledger')
    now=datetime.now(timezone.utc).astimezone(CT)
    from datetime import timedelta
    value['initial_session']=(now.date()+timedelta(days=int(now.hour>=17))).isoformat()
    return value,cfg


def as_bars(frame):
    return [Bar(t.to_pydatetime(),str(r.instrument),float(r.open),float(r.high),float(r.low),float(r.close),float(r.volume)) for t,r in frame.iterrows()]


def check_recent_history(current,session,holidays,overnight=False):
    from datetime import date,timedelta
    day=date.fromisoformat(session);required=[]
    while len(required)<4:
        day-=timedelta(days=1)
        if day.weekday()<5 and day.isoformat() not in holidays:required.append(day.isoformat())
    counts=current.groupby('session_date').size().to_dict()
    missing=[d for d in required if counts.get(d,0)<1000]
    if missing:raise BridgeError('Recent ETH history incomplete (need1000minutes per prior session): '+','.join(missing))
    if overnight:
        cutoff=pd.Timestamp(session+' 02:00:00',tz=CT).tz_convert('UTC')
        night=current.loc[(current.session_date==session)&(current.index<=cutoff)]
        if len(night)<480:raise BridgeError('Current pre02 overnight history incomplete; need480of540minute bars')


def load_native(bridge,cfg):
    run_id=read_bridge_text(bridge/'active_run.txt').strip()
    if not ID.fullmatch(run_id):raise BridgeError('Invalid native run ID')
    folder=bridge/('run_'+run_id)
    state=parse_state(read_bridge_text(folder/'state.txt'),cfg)
    if state['run_id']!=run_id:raise BridgeError('Run identity mismatch')
    if read_bridge_text(bridge/'active_run.txt').strip()!=run_id:
        raise BridgeError('Native run changed while reading snapshot')
    return folder,state


def status(root,bridge,config):
    _,cfg=settings(config)
    try:folder,state=load_native(bridge,cfg)
    except FileNotFoundError:
        print(json.dumps(dict(connected=False,reason='No current Sim bridge snapshot; start launcher, compile and enable the named bridge.',orders_sent=False)))
        return
    ready=True;reason='Quote/snapshot checks passed'
    try:healthy_state(state,datetime.now(timezone.utc),cfg)
    except BridgeError as e:ready=False;reason=str(e)
    events=read_complete_csv(folder/'executions.csv').fillna('').to_dict('records')
    created=[r for r in events if r['event']=='CREATED']
    build_ok=len(created)==1 and str(created[0]['detail']).startswith('build='+BUILD+'|')
    if not build_ok:ready=False;reason='Wrong native source build'
    print(json.dumps(dict(connected=True,quote_ready=ready,reason=reason,account=state['account'],
        policy=state['policy_id'],simulated_ledger_balance=50000+state['realized_net'],
        firm_floor=state['highwater']-2000,usable_reserved_room=50000+state['realized_net']-(state['highwater']-1950),
        quantity=state['quantity'],stop=state['stop'],target=state['target'],unlimited_simulation_stage=bool(state['goal_reached']),
        native_reason=state['reason'],native_build_verified=build_ok,
        entry_fill_callbacks=sum(r['event']=='ENTRY_FILL' for r in events),
        exit_fill_callbacks=sum(r['event']=='EXIT_FILL' for r in events),
        pending_exit_callbacks=state['pending_exit_callbacks'],ledger_uncertain=bool(state['ledger_uncertain']),
        actual_first_fill_utc=state['first_fill_utc'].isoformat(),account_signed_quantity=state['account_signed_quantity'],
        notification_health=json.loads((folder/'notification_status.json').read_text()) if (folder/'notification_status.json').exists() else {'enabled':False,'reason':'No current controller notification status'},
        orders_sent=False),indent=2))


def run(root,bridge,config,notifications):
    verify_release(root)
    value,cfg=settings(config);write_startup(bridge,value,cfg)
    print('Sim101 only | current red-context model | persisted simulation ledger; native fills authoritative | OnBarClose |02:00-12:00CT entries |15:55flat',flush=True)
    print('File-access fix enabled | bridge directory: '+str(bridge),flush=True)
    print('Native SIM19 | callback snapshots | platform keep-running | automatic reconciled-flat feed recovery | entry ack10s | partial-exit recovery | full bracket checks.',flush=True)
    print('Fast chart parsing enabled | immutable history checked | explicit entry/cancellation diagnostics.',flush=True)
    print('Flat status recovery enabled | no entries on stale state | bounded30second wait | fresh-state resync required.',flush=True)
    print('Startup file written. Enable SovereignMgcResearchSimBridgeV3 after compilation. Waiting for native REALTIME...',flush=True)
    last_wait=None;last_wait_print=0.
    waiting_notifications=WaitingHeartbeat(notifications)
    while True:
        try:
            folder,state=load_native(bridge,cfg)
            now=datetime.now(timezone.utc)
            try:
                healthy_state(state,now,cfg)
                break
            except BridgeError as error:
                why='run='+state['run_id']+' | phase='+state['phase']+' | blocked='+str(state['blocked'])+' | '+str(error)
                if state['reason']:why+=' | native reason='+state['reason']
        except FileNotFoundError:
            why='No current native snapshot at '+str(bridge)+'; enable the bridge on the chart.'
        waiting_notifications.tick(why)
        if why!=last_wait or time.monotonic()-last_wait_print>=5:
            print('WAITING: '+why,flush=True)
            last_wait=why;last_wait_print=time.monotonic()
        time.sleep(.5)
    created=[r for r in read_complete_csv(folder/'executions.csv').fillna('').to_dict('records') if r['event']=='CREATED']
    if len(created)!=1 or not str(created[0]['detail']).startswith('build='+BUILD+'|'):
        raise BridgeError('Wrong native source build; use only this release source')
    if any(state[k] for k in ('quantity','entry_working','orders_working','active_id','blocked')):
        raise BridgeError('Attach from a flat, reconciled Sim101 run')
    lock=folder/'controller.lock'
    with lock.open('x') as f:f.write('Sim101 current-model controller\n')
    heartbeat=None
    try:
        journal=make_notifications(folder,notifications)
        history=ChartHistory()
        brain=load_brain(root/'sovereign_recovered_math.py')
        models=json.loads((root/'data/tree_day_models.json').read_text())
        forests=json.loads((root/'data/forest_models.json').read_text())
        holidays=json.loads((root/'data/holidays.json').read_text())
        gaps=[tuple(utc(t) for t in g) for g in json.loads((root/'data/zero_trade_gaps.json').read_text())]
        risk=RiskConfig(starting_balance=48615.,risk_per_trade=800,max_contracts=10,max_trades_per_session=20,
            entry_start_ct=120,entry_end_ct=720,flatten_ct=955,daily_loss_limit=900,drawdown_reserve=50,
            max_drawdown=2000,account_trailing_mode='end_of_day',trailing_highwater_cap=52000,
            commission_round_trip=state['fee'],slippage_ticks_per_side=1)
        for attempt in range(3):
            active,fresh=load_native(bridge,cfg)
            if active!=folder:raise BridgeError('Native run changed during initialization')
            state=fresh
            frame=history.read(folder/'minutes.csv',state['instrument'],state['last_bar_utc'])
            symbol=state['instrument'];current=frame.loc[frame.instrument==symbol]
            if len(current)<1200 or len(current.session_date.unique())<5:
                raise BridgeError('Need at least1200actual-expiry minute bars across five sessions; load60chartdays with DoNotMerge')
            check_recent_history(current,state['session'],holidays)
            if frame.index[-1]!=state['last_bar_utc']:raise BridgeError('Native chart and warmup end differ')
            planner=LiveResearchPlanner(risk,{},models=models,features={},trade_models=forests,blocked_dates=holidays,zero_trade_gaps=gaps,goal_lock=False,entry_policy='confirmed')
            planner.daily_features=day_features(current)
            feature=planner.daily_features.get(state['session'])
            if feature is not None and utc(feature['available_at'])<=state['last_bar_utc']:
                check_recent_history(current,state['session'],holidays,overnight=True)
            startup=planner.seed_for_startup(as_bars(current.tail(241)),state)
            active,check=load_native(bridge,cfg)
            if active!=folder:raise BridgeError('Native run changed during seeding')
            stable_fields=('last_bar_utc','session','realized_net','session_open_cash','highwater','session_count','goal_reached')
            if all(check[k]==state[k] for k in stable_fields):break
        else:raise BridgeError('Could not establish a stable current closed-bar seed')
        if any(check[k] for k in ('blocked','quantity','entry_working','orders_working','active_id')):
            raise BridgeError('Account became active or halted during initialization')
        cursor_file=folder/'controller_cursor.json'
        if cursor_file.exists():raise BridgeError('Never replay a consumed native run; re-enable a new flat run')
        heartbeat=Heartbeat(folder,state['run_id'])
        cursor=state['last_bar_utc'];run_id=state['run_id'];cached_day=None
        resync_required=False;last_entry_sent=None;last_entry_issued=None
        snapshot_wait=SubmissionWatch()
        atomic_text(folder/'startup_context.json',json.dumps(startup,indent=2)+'\n')
        atomic_text(folder/'chart_history_source.json',json.dumps(history.receipt(),indent=2)+'\n')
        print('Live history source: current native chart only; research bars are not merged.',flush=True)
        print(json.dumps(dict(event='JOINED_SESSION',**startup)),flush=True)
        notification_health=NotificationHealth(folder,notifications)
        notification_health.update()
        journal.started(state,startup)
        atomic_text(cursor_file,json.dumps(dict(last_bar_utc=cursor.isoformat(),run_id=run_id)))
        print('Connected. Historical candles seeded; no historical orders submitted. Waiting for next closed minute.',flush=True)
        feed_waiting=False;last_feed_notice=None
        while True:
            heartbeat.progress=time.monotonic()
            heartbeat.mark('native_snapshot')
            read_failed=False
            try:active,fresh_state=load_native(bridge,cfg)
            except OSError as error:
                if not transient_status_error(error):raise
                # Use old state ONLY to permit a flat no-command wait, never
                # for signals, commands, position management or cash changes.
                active=folder;fresh_state=state;read_failed=True
            if active!=folder:raise BridgeError('Native run changed')
            state=fresh_state
            if awaiting_feed_recovery(state,datetime.now(timezone.utc)):
                heartbeat.mark('waiting_feed_recovery_no_orders')
                journal.poll(state);journal.tick(state,datetime.now(timezone.utc),planner)
                notification_health.update()
                feed_waiting=True;resync_required=True
                if last_feed_notice is None or time.monotonic()-last_feed_notice>=30:
                    print('WAITING_FEED_RECOVERY | native flatten/reconciliation remains in control; no new orders; controller stays connected.',flush=True)
                    last_feed_notice=time.monotonic()
                time.sleep(.25)
                continue
            if feed_waiting:
                require_flat_resync(state,any((folder/'commands').glob('*.cmd')),
                    entry_awaiting_reconciliation(state,last_entry_sent,last_entry_issued))
                resync_required=True;feed_waiting=False;last_feed_notice=None
                print('Feed restored and native account reconciled flat; rebuilding context without replaying missed trades.',flush=True)
            if state['blocked']:raise BridgeError('Native halt: '+state['reason'])
            recovery=snapshot_wait.inspect(state,datetime.now(timezone.utc),read_error=read_failed,
                pending_commands=any((folder/'commands').glob('*.cmd')),
                recent_entry=entry_awaiting_reconciliation(state,last_entry_sent,last_entry_issued),
                command_processed=bool(snapshot_wait.pending and (folder/'processed'/(snapshot_wait.pending['command_id']+'.cmd')).exists()))
            if recovery['action']=='WAIT_ENTRY_ACK':
                heartbeat.mark('awaiting_known_native_entry_ack_no_new_orders')
                journal.poll(state)
                if recovery['notice']:print('WAITING_ENTRY_ACK | '+json.dumps(recovery),flush=True)
                time.sleep(.25)
                continue
            if recovery['action'] in ('ENTRY_ACKNOWLEDGED','ENTRY_TERMINAL_FLAT'):
                print(json.dumps(recovery),flush=True)
            if recovery['action']=='WAIT':
                heartbeat.mark('waiting_native_snapshot_flat_no_orders')
                if recovery['notice']:
                    print('WAITING_NATIVE_SNAPSHOT_FLAT | '+json.dumps(recovery),flush=True)
                time.sleep(.25)
                continue
            if recovery['action']=='RECOVERED':
                resync_required=True
                print('Native snapshot recovered; rebuilding flat context before any fresh trade decision.',flush=True)
            heartbeat.mark('notification_journal')
            journal.poll(state)
            journal.tick(state,datetime.now(timezone.utc),planner)
            notification_health.update()
            if state['blocked']:raise BridgeError('Native halt: '+state['reason'])
            now=datetime.now(timezone.utc)
            if (now-state['updated_utc']).total_seconds()>5:
                # A slow ancillary task can age a previously fresh snapshot.
                # Validate flatness and wait on the next poll; never use it.
                snapshot_wait.inspect(state,now,pending_commands=any((folder/'commands').glob('*.cmd')),
                    recent_entry=entry_awaiting_reconciliation(state,last_entry_sent,last_entry_issued))
                continue
            stamp=state['last_bar_utc']
            if stamp<cursor:raise BridgeError('Native clock moved backwards')
            if (stamp==cursor and not resync_required and planner.limit_order is not None
                    and planner.confirmation_time==stamp):
                # Retry a temporarily unhealthy quote/snapshot within the SAME
                # original5second deadline; no candle/source is replayed here.
                attempt_time=datetime.now(timezone.utc);retry_row=None;retry_error=None
                try:retry_row=planner.retry_confirmed_entry(state,attempt_time,cfg)
                except BridgeError as error:retry_error=str(error)
                if retry_row is not None:
                    if (datetime.now(timezone.utc)-attempt_time).total_seconds()>1:raise BridgeError('Command preparation expired')
                    write_command(folder,retry_row)
                    last_entry_sent=time.monotonic();last_entry_issued=attempt_time
                    snapshot_wait.submitted(retry_row,state,attempt_time)
                    journal.command_sent(retry_row,planner.native_signal)
                retry_event=dict(event='ENTRY_RETRY',time=stamp.isoformat(),
                    checked_at_utc=attempt_time.isoformat(),decision=retry_row['kind'] if retry_row else 'NO_COMMAND',
                    entry_check=planner.last_entry_check,entry_health_error=retry_error,
                    last_proposal_cancel=planner.last_cancel,account='Sim101')
                with (folder/'decisions.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(retry_event)+'\n')
                if retry_row is not None or planner.limit_order is None:print(json.dumps(retry_event),flush=True)
            if stamp>cursor or resync_required:
                cycle_started=time.monotonic()
                heartbeat.mark('chart_csv_read')
                frame=history.read(folder/'minutes.csv',state['instrument'],state['last_bar_utc']);current=frame.loc[frame.instrument==symbol]
                if frame.index[-1]!=stamp:raise BridgeError('Closed-chart state mismatch')
                bar=as_bars(current.tail(1))[0]
                if resync_required or stamp-cursor!=pd.Timedelta(minutes=1):
                    previous_cursor=cursor
                    pending_commands=any((folder/'commands').glob('*.cmd'))
                    recent_entry=entry_awaiting_reconciliation(state,last_entry_sent,last_entry_issued)
                    require_flat_resync(state,pending_commands,recent_entry)
                    check_recent_history(current,state['session'],holidays)
                    heartbeat.mark('flat_resync_day_features')
                    features=day_features(current)
                    feature=features.get(state['session'])
                    if feature is not None and utc(feature['available_at'])<=stamp:
                        check_recent_history(current,state['session'],holidays,overnight=True)
                    def fresh_planner():
                        return LiveResearchPlanner(risk,{},models=models,features=features,trade_models=forests,
                            blocked_dates=holidays,zero_trade_gaps=gaps,goal_lock=False,entry_policy='confirmed')
                    replacement,receipt=reseed_flat(planner,fresh_planner,as_bars(current.tail(241)),state,
                        pending_commands=pending_commands,recent_entry_command=recent_entry)
                    active,check=load_native(bridge,cfg)
                    if active!=folder:raise BridgeError('Native run changed during flat recovery')
                    require_flat_resync(check,any((folder/'commands').glob('*.cmd')),recent_entry)
                    if check['instrument']!=symbol:raise BridgeError('Native expiry changed during flat recovery')
                    stable=('last_bar_utc','session','realized_net','session_open_cash','highwater','session_count',
                        'goal_reached','entry_executed','exit_executed','submitted_quantity','entry_reported_filled')
                    if any(check[k]!=state[k] for k in stable):
                        resync_required=True
                        print('Flat recovery waiting for a stable latest candle; no orders submitted.',flush=True)
                        time.sleep(.25)
                        continue
                    receipt.update(previous_cursor=previous_cursor.isoformat(),
                        elapsed_minutes=(stamp-previous_cursor).total_seconds()/60,
                        chart_rows_since_cursor=int((current.index>previous_cursor).sum()),
                        recovery_seconds=round(time.monotonic()-cycle_started,3))
                    planner=replacement;cursor=stamp;resync_required=False;cached_day=None
                    atomic_text(cursor_file,json.dumps(dict(last_bar_utc=stamp.isoformat(),run_id=run_id)))
                    atomic_text(folder/'chart_history_source.json',json.dumps(history.receipt(),indent=2)+'\n')
                    with (folder/'continuity_events.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(receipt)+'\n')
                    print(json.dumps(receipt),flush=True)
                    # Routine recoveries stay in the console/local log; no Discord spam.
                    continue
                cursor=stamp
                if cached_day!=state['session'] and stamp>=pd.Timestamp(state['session']+' 02:00:00',tz=CT).tz_convert('UTC'):
                    heartbeat.mark('day_features')
                    planner.daily_features=day_features(current)
                    if state['session'] in planner.daily_features and utc(planner.daily_features[state['session']]['available_at'])<=stamp:
                        check_recent_history(current,state['session'],holidays,overnight=True)
                        cached_day=state['session']
                heartbeat.mark('source_generation')
                sources=latest_source(brain,frame,stamp,symbol) if stamp.minute%5==0 else []
                # Source generation may be expensive; actual account/quote state
                # is refreshed before shared model observation or any command.
                heartbeat.mark('refresh_native_state')
                _,state=load_native(bridge,cfg);now=datetime.now(timezone.utc)
                if state['last_bar_utc']!=stamp:
                    require_flat_resync(state,any((folder/'commands').glob('*.cmd')),
                        entry_awaiting_reconciliation(state,last_entry_sent,last_entry_issued))
                    resync_required=True
                    print('Processing crossed a candle boundary while flat; resynchronizing without catch-up orders.',flush=True)
                    continue
                heartbeat.mark('planner_observe')
                planner.observe(bar,state,sources)
                row=None;entry_health_error=None
                planner.last_entry_check=None
                try:
                    heartbeat.mark('prepare_command')
                    healthy_state(state,now,cfg)
                    row=protective_stop(state,bar,now,cfg) if state['quantity'] else planner.prepare_entry(state,now,cfg)
                except BridgeError as e:
                    entry_health_error=str(e)
                    print('No command: '+str(e),flush=True)
                if row is not None:
                    if (datetime.now(timezone.utc)-now).total_seconds()>1:raise BridgeError('Command preparation expired')
                    write_command(folder,row)
                    if row['kind']=='ENTER':
                        last_entry_sent=time.monotonic();last_entry_issued=now
                        snapshot_wait.submitted(row,state,now)
                    journal.command_sent(row,planner.native_signal)
                atomic_text(cursor_file,json.dumps(dict(last_bar_utc=stamp.isoformat(),run_id=run_id)))
                decision=dict(event='CLOSED_MINUTE',time=stamp.isoformat(),sources=len(sources),
                    decision=row['kind'] if row else 'NO_COMMAND',account='Sim101',ledger_cash=50000+state['realized_net'],
                    proposal_waiting=planner.limit_order is not None,
                    family=planner.native_signal.family if row and row['kind']=='ENTER' else None,
                    day_gate=planner.day_decisions.get(state['session']),rejections=dict(planner.rejections),
                    native_model_id=state['active_id'],actual_first_fill_utc=state['first_fill_utc'].isoformat(),
                    native_quantity=state['quantity'],account_signed_quantity=state['account_signed_quantity'],
                    entry_executed=state['entry_executed'],exit_executed=state['exit_executed'],
                    pending_exit_callbacks=state['pending_exit_callbacks'],
                    processed_at_utc=datetime.now(timezone.utc).isoformat(),
                    processing_seconds=round(time.monotonic()-cycle_started,6),
                    entry_check=planner.last_entry_check,entry_health_error=entry_health_error,
                    last_proposal_cancel=planner.last_cancel,
                    proposal_family=planner.limit_order.signal.family if planner.limit_order else None)
                with (folder/'decisions.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(decision)+'\n')
                journal.decision(decision,state)
                print(json.dumps(decision),flush=True)
            heartbeat.mark('poll_sleep')
            time.sleep(.25)
    except BaseException:
        try:
            _,latest=load_native(bridge,cfg)
            if latest['run_id']==state['run_id']:
                ident=latest['active_id'] if ID.fullmatch(latest['active_id']) else '0'*32
                write_command(folder,command(latest,'FLATTEN',ident,datetime.now(timezone.utc)))
        except Exception:pass
        raise
    finally:
        if heartbeat is not None:heartbeat.close()
        lock.unlink(missing_ok=True)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    p.add_argument('--bridge',type=Path,default=bridge_directory())
    mode=p.add_mutually_exclusive_group();mode.add_argument('--status',action='store_true');mode.add_argument('--audit',action='store_true')
    p.add_argument('--discord',action='store_true',help='Discord is required by default for trading runs');a=p.parse_args()
    cfg=a.root/'sim_config.json'
    notifier=ExecutionNotifications()
    try:
        verify_release(a.root)
        notifier=confirmed_notifications(not (a.status or a.audit))
        if a.audit:
            from tools.audit_mgc_sim_run_v3 import audit,read_journal
            verify_release(a.root);settings(cfg)
            run_id=(a.bridge/'active_run.txt').read_text().strip()
            if not ID.fullmatch(run_id):raise BridgeError('Invalid native run identity')
            folder=a.bridge/('run_'+run_id)
            report=audit(read_journal(folder/'executions.csv'))
            (folder/'execution_audit.json').write_text(json.dumps(report,indent=2)+'\n')
            print(json.dumps(report,indent=2))
        elif a.status:status(a.root,a.bridge,cfg)
        else:run(a.root,a.bridge,cfg,notifier)
    except KeyboardInterrupt:
        notifier.publish('🛑 MGC CONTROLLER STOP REQUESTED | Sim101\nCheck NinjaTrader Orders/Positions for actual flatten completion. A stop notification does not confirm an exit fill.')
        print('Controller stopped. Check NinjaTrader Orders/Positions for native flatten completion.',flush=True)
    except (BridgeError,OSError,ValueError) as e:
        notifier.publish('🚨 MGC CONTROLLER STOPPED | Sim101 | '+type(e).__name__+'\nRead the local terminal and check NinjaTrader Orders/Positions. Flatten completion has not been certified.')
        print('Controller stopped: '+str(e),flush=True);raise SystemExit(1)
    finally:
        drain_notifications(notifier)
        notifier.close()


if __name__=='__main__':main()
