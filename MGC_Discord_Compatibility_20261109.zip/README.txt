MGC Discord compatibility update — Python notification module only

Cause: the detailed journal tracker accepted SIM3/SIM6 builds, but rejected the newer
SIM10/SIM11 CREATED records. The fallback continued trading independently, but its
tick() method did nothing, so hourly Discord reports never fired. This was a software
compatibility bug, not evidence that Discord was disconnected or that the bot stopped.

Repair: explicitly accept the same-wire SIM10/SIM11 journals, preserving accounting
and source reconciliation. Unknown/corrupt journals still cannot provide statistics;
their degraded fallback now sends basic hourly reports and a visible terminal warning.
If the notification queue is full at the hourly deadline, retry after60seconds.

Install from the existing MGC_Bot_With_Setup folder, after the SIM11 heartbeat repair:
1. Stop Python, disable strategy, confirm Sim101 flat with no working orders.
2. Extract this ZIP into that existing folder.
3. Run py .\Update_MGC_Notifications.py and type NOTIFY after those checks.
4. Your existing private launcher starts. No C# change or F5 is needed.
5. After Startup file written, enable the same strategy on Sim101.

Look for: Detailed Discord tracking active | hourly reports every60minutes from connection.
The connected report is immediate; first hourly report is60minutes after tracker
creation/connection, not at the top of the clock hour. Restarting resets that timer.
Actual fill/win/loss reports require native execution callbacks. No trades are inferred.

Only gc_research/mgc_discord_detail_v8.py changes. Native source, trading controller,
strategy, risk rules, financial ledger and private webhook launcher are preserved.
No real Discord messages are sent by cloud tests. Actual delivery is still best-effort;
see the native run folder's notification_status.json for sent/failed/dropped counters.
