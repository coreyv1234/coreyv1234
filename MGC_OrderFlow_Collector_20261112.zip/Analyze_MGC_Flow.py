"""Aggregate live recorder events and join only matching candle intervals.

Features use LOCAL RECEIPT time so a delayed print cannot be inserted into a
previous decision interval as though it was known then. Raw provider timestamps
remain in the original event CSV. Delta is quote-inferred, never exchange-attested.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path

import hashlib

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()
def instrument_root(symbol):
    return symbol.strip().upper().split()[0]

HEADER = ["time_utc", "instrument", "flow_capture_id", "flow_epoch", "flow_status",
          "flow_trade_count", "flow_trade_volume", "flow_ask_hit_volume_inferred",
          "flow_bid_hit_volume_inferred", "flow_unclassified_volume", "flow_classified_fraction",
          "flow_delta_inferred", "flow_cvd_classified_since_epoch_start",
          "flow_mean_quote_sample_spread_ticks", "flow_quote_updates", "flow_depth_updates",
          "flow_heartbeats", "flow_connection_changes", "flow_local_sequence_gaps"]


def utc(value: str) -> datetime:
    t = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if t.tzinfo is None or t.utcoffset() != timedelta():
        raise ValueError("timestamps must explicitly use UTC")
    return t.astimezone(timezone.utc)


def minute_end(t: datetime) -> datetime:
    return t.replace(second=0, microsecond=0) + timedelta(minutes=1)


def number(value: str, *, positive=False) -> float:
    n = float(value)
    if not math.isfinite(n) or n < 0 or (positive and n == 0):
        raise ValueError("invalid price/size")
    return n


def infer_trade(row: dict, max_quote_age_ms=1000) -> str:
    """Conservative quote test using snapshots captured before/at local callback."""
    try:
        received = utc(row["received_time_utc"])
        if not row.get("event_time_utc") or abs((received-utc(row["event_time_utc"])).total_seconds())>5:
            return "unknown"
        bid, ask, price = (number(row[k], positive=True) for k in ("bid", "ask", "price"))
        if bid >= ask:
            return "unknown"
        for k in ("bid_received_utc", "ask_received_utc"):
            age = (received-utc(row[k])).total_seconds()*1000
            if age < 0 or age > max_quote_age_ms:
                return "unknown"
        if price >= ask:
            return "ask_inferred"
        if price <= bid:
            return "bid_inferred"
    except (ValueError, KeyError, TypeError):
        pass
    return "unknown"


def aggregate(source: Path, *, max_quote_age_ms=1000):
    if not 0 < max_quote_age_ms <= 60000:
        raise ValueError("max quote age must be between 1 and 60000 ms")
    buckets, footprints, candles = {}, {}, {}
    counts, issues = Counter(), Counter()
    capture = symbol = None
    previous_sequence = 0
    previous_received = None
    epoch, cvd = 0, 0.
    bad_quote_snapshots = {}
    started = stopped = False
    with source.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        required = {"capture_id", "sequence", "event_time_utc", "received_time_utc", "instrument", "event_type",
                    "price", "size", "bid", "ask", "bid_received_utc", "ask_received_utc"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError("CSV is not a Sovereign GC/MGC flow recorder event file")
        for line, row in enumerate(reader, 2):
            try:
                current_symbol = row["instrument"].strip().upper()
                if instrument_root(current_symbol) not in {"GC", "MGC"} or current_symbol in {"GC", "MGC"}:
                    raise ValueError("actual GC or MGC expiry required")
                if capture is None:
                    capture, symbol = row["capture_id"], current_symbol
                    if not capture:
                        raise ValueError("capture_id is empty")
                if capture != row["capture_id"] or symbol != current_symbol:
                    raise ValueError("process each capture/expiry separately")
                seq = int(row["sequence"])
                if seq <= previous_sequence:
                    raise ValueError("duplicate or regressing local sequence")
                missing = seq-previous_sequence-1
                received = utc(row["received_time_utc"])
                clock_backwards = previous_received is not None and received < previous_received
                if clock_backwards:
                    raise ValueError("local receipt clock moved backward; isolate clock discontinuity before joining")
                kind = row["event_type"]
                counts[kind] += 1
                if missing or kind == "CONNECTION":
                    epoch += 1
                    cvd = 0.
                    bad_quote_snapshots.clear()
                key = minute_end(received)
                b = buckets.setdefault(key, {"time_utc": key.isoformat(), "instrument": symbol,
                    "flow_capture_id": capture, "epochs": set(), "flags": {"observed_only", "receipt_time", "feed_continuity_unverified"},
                    "flow_trade_count": 0, "flow_trade_volume": 0., "flow_ask_hit_volume_inferred": 0.,
                    "flow_bid_hit_volume_inferred": 0., "flow_unclassified_volume": 0.,
                    "flow_quote_updates": 0, "flow_depth_updates": 0, "flow_heartbeats": 0,
                    "flow_connection_changes": 0, "flow_local_sequence_gaps": 0,
                    "spreads": [], "cvd": None})
                b["epochs"].add(epoch)
                if missing:
                    b["flow_local_sequence_gaps"] += missing
                    b["flags"].add("sequence_gap")
                    issues["missing_local_sequence_rows"] += missing
                if kind in {"START", "STOP"}:
                    b["flags"].add("partial_capture_boundary")
                    started |= kind == "START"
                    stopped |= kind == "STOP"
                elif kind == "CONNECTION":
                    b["flow_connection_changes"] += 1
                    b["flags"].add("connection_change")
                elif kind == "HEARTBEAT":
                    b["flow_heartbeats"] += 1
                elif kind == "MONITOR_UNAVAILABLE":
                    b["flags"].add("connection_monitor_unavailable")
                    issues["connection_monitor_unavailable"] += 1
                elif kind == "MONITOR_READY":
                    pass
                elif kind == "BAR":
                    end = utc(row["bar_end_utc"])
                    if end.second or end.microsecond:
                        raise ValueError("candle end must align to a minute")
                    candle = {"time_utc": end.isoformat(), "instrument": symbol}
                    for k in ("open", "high", "low", "close", "volume"):
                        candle[k] = number(row["bar_"+k], positive=k!="volume")
                    if candle["low"]>min(candle["open"],candle["close"]) or candle["high"]<max(candle["open"],candle["close"]):
                        raise ValueError("invalid recorded candle")
                    for k in ("open","high","low","close"):
                        if not math.isclose(candle[k]/.1,round(candle[k]/.1),abs_tol=1e-7):
                            raise ValueError("recorded candle is off the tick grid")
                    if end in candles:
                        raise ValueError("duplicate completed candle")
                    candles[end] = candle
                elif kind in {"DEPTH_BID", "DEPTH_ASK"}:
                    b["flow_depth_updates"] += 1
                    b["flags"].add("depth_snapshot_unverified")
                elif kind in {"BID", "ASK"}:
                    b["flow_quote_updates"] += 1
                    side_key = "bid" if kind == "BID" else "ask"
                    try:
                        source_bad = not row["event_time_utc"] or abs((received-utc(row["event_time_utc"])).total_seconds())>5
                    except ValueError:
                        source_bad = True
                    if source_bad:
                        bad_quote_snapshots[side_key] = row[side_key+"_received_utc"]
                        b["flags"].add("quote_source_time_unverified")
                        issues["quote_source_time_unverified"] += 1
                    else:
                        bad_quote_snapshots.pop(side_key,None)
                    bad_context = any(row.get(k+"_received_utc") == v for k,v in bad_quote_snapshots.items())
                    try:
                        bid, ask = number(row["bid"], positive=True), number(row["ask"], positive=True)
                        if bid < ask and not bad_context:
                            b["spreads"].append((ask-bid)/.1)
                    except (ValueError, TypeError):
                        pass
                elif kind == "TRADE":
                    price, size = number(row["price"], positive=True), number(row["size"], positive=True)
                    if not math.isclose(size, round(size), abs_tol=1e-8):
                        raise ValueError("futures trade size must be whole contracts")
                    if not math.isclose(price/.1, round(price/.1), abs_tol=1e-7):
                        raise ValueError("trade is off the GC tick grid")
                    side = infer_trade(row, max_quote_age_ms)
                    if any(row.get(k+"_received_utc") == v for k,v in bad_quote_snapshots.items()):
                        side = "unknown"
                        b["flags"].add("trade_quote_source_time_unverified")
                        issues["trade_quote_source_time_unverified"] += 1
                    try:
                        source_time_bad = not row["event_time_utc"] or abs((received-utc(row["event_time_utc"])).total_seconds())>5
                    except ValueError:
                        source_time_bad = True
                    if source_time_bad:
                        b["flags"].add("trade_source_time_unverified")
                        issues["trade_source_time_unverified"] += 1
                    field = {"ask_inferred": "flow_ask_hit_volume_inferred", "bid_inferred": "flow_bid_hit_volume_inferred", "unknown": "flow_unclassified_volume"}[side]
                    b["flow_trade_count"] += 1
                    b["flow_trade_volume"] += size
                    b[field] += size
                    cvd += size if side == "ask_inferred" else -size if side == "bid_inferred" else 0
                    b["cvd"] = cvd
                    fp = footprints.setdefault((key, epoch, price), {"time_utc": key.isoformat(), "instrument": symbol,
                        "capture_id": capture, "epoch": epoch, "price": price,
                        "ask_volume_inferred": 0., "bid_volume_inferred": 0., "unclassified_volume": 0.})
                    fp[{"ask_inferred": "ask_volume_inferred", "bid_inferred": "bid_volume_inferred", "unknown": "unclassified_volume"}[side]] += size
                else:
                    raise ValueError(f"unsupported event type {kind!r}")
                previous_sequence, previous_received = seq, received
            except (ValueError, KeyError, TypeError) as exc:
                raise ValueError(f"event CSV line {line}: {exc}") from exc
    rows = []
    for _, b in sorted(buckets.items()):
        epochs, flags = b.pop("epochs"), b.pop("flags")
        spreads, cumulative = b.pop("spreads"), b.pop("cvd")
        b["flow_epoch"] = next(iter(epochs)) if len(epochs)==1 else "mixed"
        if len(epochs)>1:
            flags.add("mixed_epoch")
        if b["flow_unclassified_volume"]:
            flags.add("unclassified_trades")
        if not b["flow_trade_count"]:
            flags.add("no_trade_events_observed")
        classified = b["flow_ask_hit_volume_inferred"]+b["flow_bid_hit_volume_inferred"]
        b["flow_classified_fraction"] = classified/b["flow_trade_volume"] if b["flow_trade_volume"] else ""
        b["flow_delta_inferred"] = b["flow_ask_hit_volume_inferred"]-b["flow_bid_hit_volume_inferred"] if classified else ""
        b["flow_cvd_classified_since_epoch_start"] = cumulative if classified and len(epochs)==1 else ""
        b["flow_mean_quote_sample_spread_ticks"] = sum(spreads)/len(spreads) if spreads else ""
        b["flow_status"] = ";".join(sorted(flags))
        rows.append(b)
    if not rows:
        raise ValueError("event file is empty")
    status_path = Path(str(source)+".status.txt")
    status = "missing"
    if status_path.is_file():
        with status_path.open() as f:
            status = f.readline().strip()
    summary = {"capture_id": capture, "instrument": symbol, "event_counts": dict(counts),
        "quality_issues": dict(issues), "minute_rows": len(rows), "has_start": started, "has_stop": stopped,
        "status_sidecar": status, "has_bid_and_ask_events": bool(counts["BID"] and counts["ASK"]),
        "has_trade_events": bool(counts["TRADE"]), "has_depth_events": bool(counts["DEPTH_BID"] or counts["DEPTH_ASK"]),
        "connection_monitor_hook_reported": bool(counts["MONITOR_READY"]),
        "max_quote_age_ms": max_quote_age_ms, "feature_time_basis": "local_receipt_time",
        "captured_candles": len(candles),
        "meaning": "Observed callbacks only. Local sequence cannot prove no feed packet loss. Inferred side is not an exchange aggressor flag; depth counts do not certify a complete book."}
    return rows, [v for _,v in sorted(footprints.items())], summary, [v for _,v in sorted(candles.items())]


def join_bars(bars: Path, flow: Path, output: Path):
    with flow.open(newline="") as f:
        reader = csv.DictReader(f)
        if not set(HEADER).issubset(reader.fieldnames or []):
            raise ValueError("missing flow summary columns")
        mapping = {}
        for row in reader:
            key = (utc(row["time_utc"]), row["instrument"].strip().upper())
            if key in mapping:
                raise ValueError("multiple flow captures for the same minute; reconcile captures explicitly")
            mapping[key] = row
    fields = [k for k in HEADER if k not in {"time_utc", "instrument"}]
    created, total, matched = False, 0, 0
    try:
        with bars.open(newline="",encoding="utf-8-sig") as src, output.open("x",newline="") as dst:
            created = True
            reader = csv.DictReader(src)
            original = reader.fieldnames or []
            if not {"time_utc","instrument","open","high","low","close","volume"}.issubset(original):
                raise ValueError("canonical candle CSV required")
            if (set(fields)|{"flow_volume_difference_vs_candle"})&set(original):
                raise ValueError("candle file already has flow columns")
            writer = csv.DictWriter(dst,fieldnames=original+fields+["flow_volume_difference_vs_candle"])
            writer.writeheader()
            for row in reader:
                key = (utc(row["time_utc"]),row["instrument"].strip().upper())
                values = mapping.get(key)
                total += 1
                if values is None:
                    row.update({k:"" for k in fields})
                    row["flow_status"] = "missing"
                    row["flow_volume_difference_vs_candle"] = ""
                else:
                    matched += 1
                    row.update({k:values[k] for k in fields})
                    row["flow_volume_difference_vs_candle"] = float(values["flow_trade_volume"])-float(row["volume"])
                writer.writerow(row)
    except Exception:
        if created:
            output.unlink(missing_ok=True)
        raise
    return {"candle_rows":total,"matched_flow_minutes":matched,"missing_flow_minutes":total-matched,
            "meaning":"Matches require identical UTC minute end and actual expiry. Missing historical flow remains blank, never fabricated as zero. Receipt-time flow can differ from event-time candle volume."}


import csv
import math
from datetime import datetime, timezone

DEPTH_FIELDS = ['received_time_utc', 'instrument', 'capture_id', 'bid_levels_observed',
          'ask_levels_observed', 'bid_size_top5', 'ask_size_top5', 'imbalance_top5',
          'bid_age_ms', 'ask_age_ms', 'quality']


def depth_samples(source, output, max_age_ms=1000):
    if not 0 < max_age_ms <= 60000:
        raise ValueError('Invalid depth age limit')
    books = {'DEPTH_BID': [], 'DEPTH_ASK': []}
    seen = {key: None for key in books}
    previous = 0
    last_second = None
    emitted = invalid = usable = 0
    with source.open(newline='', encoding='utf-8-sig') as src, output.open('x', newline='') as dst:
        writer = csv.DictWriter(dst, fieldnames=DEPTH_FIELDS)
        writer.writeheader()
        for row in csv.DictReader(src):
            sequence = int(row['sequence'])
            kind = row['event_type']
            if sequence != previous + 1 or kind in ('START', 'CONNECTION'):
                books = {key: [] for key in books}
                seen = {key: None for key in books}
            previous = sequence
            if kind not in books:
                continue
            stamp = datetime.fromisoformat(row['received_time_utc'].replace('Z', '+00:00'))
            if stamp.tzinfo is None or stamp.utcoffset().total_seconds() != 0:
                raise ValueError('Depth receipts must be UTC')
            position = int(row['position'])
            operation = row['operation']
            book = books[kind]
            try:
                price, size = float(row['price']), float(row['size'])
                if (not math.isfinite(price) or not math.isfinite(size) or size < 0 or
                        not size.is_integer() or price <= 0 or
                        not math.isclose(price / .1, round(price / .1), abs_tol=1e-7) or position < 0):
                    raise ValueError()
                if operation == 'Insert' and position <= len(book):
                    book.insert(position, (price, size))
                elif operation == 'Update' and position <= len(book):
                    if position == len(book):
                        book.append((price, size))
                    else:
                        book[position] = (price, size)
                elif operation == 'Remove' and position < len(book):
                    book.pop(position)
                else:
                    raise ValueError()
                prices = [level[0] for level in book]
                expected = sorted(prices, reverse=kind == 'DEPTH_BID')
                if prices != expected or len(set(prices)) != len(prices):
                    raise ValueError()
                seen[kind] = stamp
            except (ValueError, IndexError):
                books[kind] = []
                seen[kind] = None
                invalid += 1
            second = stamp.replace(microsecond=0)
            if second == last_second:
                continue
            last_second = second
            bid, ask = books['DEPTH_BID'], books['DEPTH_ASK']
            bid_age = (stamp - seen['DEPTH_BID']).total_seconds() * 1000 if seen['DEPTH_BID'] else None
            ask_age = (stamp - seen['DEPTH_ASK']).total_seconds() * 1000 if seen['DEPTH_ASK'] else None
            enough = len(bid) >= 5 and len(ask) >= 5
            crossed = bool(bid and ask and bid[0][0] >= ask[0][0])
            fresh = all(age is not None and 0 <= age <= max_age_ms for age in (bid_age, ask_age))
            known = enough and fresh and not crossed
            bs = sum(size for _, size in bid[:5]) if known else ''
            ass = sum(size for _, size in ask[:5]) if known else ''
            imbalance = (bs - ass) / (bs + ass) if known and bs + ass > 0 else ''
            flags = ['observed_callbacks_only', 'full_book_unverified']
            if not enough:
                flags.append('insufficient_observed_levels')
            if not fresh:
                flags.append('stale_or_missing_depth_side')
            if crossed:
                flags.append('crossed_book')
            writer.writerow(dict(received_time_utc=stamp.astimezone(timezone.utc).isoformat(),
                                 instrument=row['instrument'], capture_id=row['capture_id'],
                                 bid_levels_observed=len(bid), ask_levels_observed=len(ask),
                                 bid_size_top5=bs, ask_size_top5=ass, imbalance_top5=imbalance,
                                 bid_age_ms=bid_age if bid_age is not None else '',
                                 ask_age_ms=ask_age if ask_age is not None else '', quality=';'.join(flags)))
            emitted += 1
            usable += int(known)
    return dict(depth_sample_rows=emitted, observed_top5_samples=usable, invalid_depth_updates=invalid,
                source='local callback order; no exchange sequence or full-book certification',
                strategy_inputs_changed=False)


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest="command",required=True)
    a=sub.add_parser("aggregate");a.add_argument("--events",type=Path,required=True);a.add_argument("--out",type=Path,required=True)
    a.add_argument("--max-quote-age-ms",type=int,default=1000)
    j=sub.add_parser("join");j.add_argument("--bars",type=Path,required=True);j.add_argument("--flow",type=Path,required=True);j.add_argument("--out",type=Path,required=True)
    args=p.parse_args(argv)
    try:
        if args.command=="aggregate":
            rows,footprints,summary,candles=aggregate(args.events,max_quote_age_ms=args.max_quote_age_ms)
            args.out.mkdir(parents=True,exist_ok=False)
            for filename,records,fields in [("flow_minutes.csv",rows,HEADER),("captured_candles.csv",candles,["time_utc","instrument","open","high","low","close","volume"]),("footprint_inferred.csv",footprints,list(footprints[0]) if footprints else ["time_utc","instrument","capture_id","epoch","price","ask_volume_inferred","bid_volume_inferred","unclassified_volume"])]:
                with (args.out/filename).open('w',newline='') as f:
                    writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(records)
            summary['depth'] = depth_samples(args.events, args.out/'depth_samples.csv', args.max_quote_age_ms)
            summary['strategy_inputs_changed'] = False
            summary["events_sha256"]=digest(args.events)
            summary["processor_sha256"]=digest(Path(__file__))
            summary["candle_join"] = join_bars(args.out/'captured_candles.csv', args.out/'flow_minutes.csv', args.out/'candles_with_flow.csv')
            (args.out/'report.json').write_text(json.dumps(summary,indent=2)+'\n')
        else:
            summary=join_bars(args.bars,args.flow,args.out)
        print(json.dumps(summary,indent=2))
        return 0
    except (ValueError,TypeError,KeyError,OSError) as exc:
        p.exit(2,f"ERROR: {exc}\n")


if __name__=="__main__":
    main()
