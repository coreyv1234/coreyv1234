MGC order-flow collector — separate research indicator; DOES NOT PLACE ORDERS

This adds data collection, not a new profit guarantee or an activated strategy.
Existing SIM18 signal/stop/target/risk logic and execution recovery stay unchanged.

CAPTURE:
Live MGC last-trade price/size, bid/ask prices/sizes and receipt timestamps;
optional level-II bid/ask updates with position, size and Insert/Update/Remove.
One-minute completed OHLCV bars are captured for alignment. Raw quotes/trades
are retained so classification can be reviewed, not blindly trusted.

ANALYSIS OUTPUTS:
flow_minutes.csv: quote-inferred buy/sell/unknown volume, estimated delta, CVD,
classified fraction, sequence/connection/quality markers.
footprint_inferred.csv: buy/sell/unknown volume at each price for each minute.
depth_samples.csv: observed top-five bid/ask volume and imbalance when both
observed sides are contiguous, ordered, uncrossed and sufficiently fresh.
captured_candles.csv and candles_with_flow.csv: matching captured OHLCV and flow.
report.json: availability, quality, counts and file hashes.

Aggressor side and delta are ESTIMATES from preceding fresh quotes, not exchange
aggressor flags. Inside-spread trades, stale/crossed quotes or unusable source
times remain UNKNOWN. No footprint values are invented for unobserved history.
Depth callbacks do not prove a complete exchange book. Reconnect/sequence gaps
invalidate the reconstructed ladder. No hidden orders or individual trader IDs.

REQUIRED DATA:
Use the actual MGC expiry and a real exchange-data connection. A Simulated Data
Feed produces simulated observations; the recorder cannot make those CME data.
Level-II depth requires that your existing provider/subscription supplies it.
No depth events means depth unavailable/unobserved, not zero resting liquidity.
Tick Replay/historical OHLCV cannot recreate historical Level-II depth.
No purchases, data subscriptions, account connections or orders are made here.

INSTALL:
1. Extract into its own MGC_OrderFlow_Collector folder.
2. At a flat/no-working-orders break, stop the Python controller and disable its
   NinjaTrader strategy before compilation. Save existing diagnostics as usual.
3. In this folder's terminal: py .\Install_MGC_Flow_Recorder.py
4. NinjaScript Editor -> F5, ZERO errors. This adds an indicator, not a replacement
   execution strategy. Restart your existing SIM18 bot through its usual launcher.
5. On the actual MGC one-minute chart: Indicators -> SovereignMgcFlowRecorderV2.
   Calculate On each tick. Enable depth capture True. Maximum capture MB 512.
   Tick Replay is not required for this REALTIME-only recorder.

FILES:
%LOCALAPPDATA%\SovereignMGC\flow
The Output window prints the exact CSV path. Its .csv.status.txt updates while
recording, including trade, quote, depth event counts and recorded bytes.
No data-source certification is implied by an active recorder heartbeat.

LIMITS:
Writer runs on a separate bounded queue. Disk failure, queue overflow or the
512MB per-capture cap stops THIS RECORDER and flags INCOMPLETE; it does not call
any order API or stop the trading controller. Recordings accumulate on disk;
the cap is per capture, not a total folder cap. Archive or delete old recordings
after saving any data you need. No automatic deletion or uploads occur.

AFTER CAPTURE:
Remove/disable ONLY the recorder indicator to finish its CSV (status CLOSED).
Analyze a completed capture using ordinary Python, no pip packages required:
py .\Analyze_MGC_Flow.py aggregate --events "C:\full\path\MGC_flow.csv" --out ".\flow_analysis_1"
Output directory must be new. Default quote/depth freshness is 1000ms; stale
observations remain flagged. Receipt-time volume may differ from event-time
candles because actual delivery timing is preserved rather than rewritten.
Send report.json and flow_minutes.csv first; raw recordings may be large.

NEXT STRATEGY STEP:
Validate actual feed provenance/coverage, then compare frozen baseline versus
order-flow candidates on matching chronological samples with costs. This package
does NOT feed untested fields into the current trained model or change the
historical $42,446 benchmark. Better input detail does not guarantee better P&L.

Validation includes classification/volume conservation, MGC contract isolation,
stale/missing depth, reconnect/gap invalidation and standalone output generation.
C# syntax checked; actual NinjaTrader SDK compilation/runtime requires your F5
and observed callbacks. No live orders or Discord messages sent from cloud.
