"""Copy only the independent recorder indicator into an installed NinjaTrader."""
import ctypes
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sys


def main():
    if sys.platform != 'win32':
        raise RuntimeError('Run this installer on your Windows NinjaTrader computer.')
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / 'MANIFEST.json').read_text())
    for name, digest in manifest.items():
        path = Path(name)
        if path.is_absolute() or '..' in path.parts:
            raise RuntimeError('Invalid package path')
        if hashlib.sha256((root / name).read_bytes()).hexdigest() != digest:
            raise RuntimeError('Package verification failed: ' + name)
    documents = ctypes.create_unicode_buffer(32768)
    if ctypes.windll.shell32.SHGetFolderPathW(None, 5, None, 0, documents) != 0:
        raise RuntimeError('Windows Documents location unavailable.')
    indicators = Path(documents.value) / 'NinjaTrader 8' / 'bin' / 'Custom' / 'Indicators'
    if not indicators.is_dir():
        raise RuntimeError('NinjaTrader Indicators folder not found: ' + str(indicators))
    source = root / 'SovereignMgcFlowRecorderV2.cs'
    target = indicators / source.name
    if target.exists() and target.read_bytes() != source.read_bytes():
        backup = root / ('previous_recorder_' + datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f') + '.cs.backup')
        shutil.copyfile(target, backup)
        print('Saved prior recorder source: ' + str(backup))
    shutil.copyfile(source, target)
    print('Recorder source installed: ' + str(target))
    print('No trading strategy, Python bot, account ledger or private webhook was changed.')
    print('Compile only while your trading strategy is disabled and Sim101 is flat/no working orders.')
    print('NinjaScript Editor -> F5. Resolve every error before restarting the bot.')
    print('On the actual MGC one-minute chart: Indicators -> SovereignMgcFlowRecorderV2.')
    print('Calculate: On each tick. Enable depth capture: True. Maximum capture MB: 512.')
    print(r'Files: %LOCALAPPDATA%\SovereignMGC\flow')


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, ValueError) as error:
        print('Recorder installation stopped: ' + str(error))
        raise SystemExit(1)
