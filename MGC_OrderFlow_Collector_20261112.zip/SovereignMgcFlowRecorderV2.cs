// Realtime-callback capture. Feed source must be verified separately. No orders.
// Compile and validate on the user's Windows NinjaTrader 8 installation.
using System;
using System.Collections.Concurrent;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;

namespace NinjaTrader.NinjaScript.Indicators
{
    public class SovereignMgcFlowRecorderV2 : Indicator
    {
        private readonly object gate = new object();
        private BlockingCollection<string> queue;
        private Thread worker;
        private Timer timer;
        private volatile bool recording, failed;
        private long sequence, tradeEvents, bidEvents, askEvents, depthEvents;
        private string stopReason = "";
        private string capture, symbol, path;
        private double bid, ask;
        private long bidSize, askSize;
        private DateTime bidReceived, askReceived;
        private System.Reflection.EventInfo connectionEvent;
        private Delegate connectionHandler;

        private string Q(string value)
        { return "\"" + (value ?? "").Replace("\"", "\"\"") + "\""; }
        private string N(double value)
        { return value.ToString("R", CultureInfo.InvariantCulture); }
        private string T(DateTime value)
        { return value == DateTime.MinValue ? "" : value.ToUniversalTime().ToString("O", CultureInfo.InvariantCulture); }
        private DateTime EventUtc(DateTime value)
        {
            if (value.Kind == DateTimeKind.Utc) return value;
            if (value.Kind == DateTimeKind.Local) return value.ToUniversalTime();
            TimeZoneInfo zone = NinjaTrader.Core.Globals.GeneralOptions.TimeZoneInfo;
            if (zone.IsAmbiguousTime(value) || zone.IsInvalidTime(value)) return DateTime.MinValue;
            return TimeZoneInfo.ConvertTimeToUtc(value, zone);
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "SovereignMgcFlowRecorderV2";
                Description = "Live MGC trades/quotes and optional depth, with capture quality markers.";
                Calculate = Calculate.OnEachTick;
                IsOverlay = true;
                DisplayInDataBox = false;
                IsSuspendedWhileInactive = false;
                BarsRequiredToPlot = 0;
                EnableDepthCapture = true;
                MaxCaptureMegabytes = 512;
            }
            else if (State == State.Realtime)
            {
                if (BarsPeriod.BarsPeriodType != BarsPeriodType.Minute || BarsPeriod.Value != 1)
                    throw new InvalidOperationException("Use a one-minute MGC chart.");
                if (Instrument.MasterInstrument.Name != "MGC" || Instrument.FullName.Trim() == "MGC")
                    throw new InvalidOperationException("Select an actual MGC contract expiry.");
                failed = false; sequence = tradeEvents = bidEvents = askEvents = depthEvents = 0;
                bid = ask = 0; bidSize = askSize = 0;
                bidReceived = askReceived = DateTime.MinValue; stopReason = "";
                symbol = Instrument.FullName;
                capture = Guid.NewGuid().ToString("N");
                string folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SovereignMGC", "flow");
                Directory.CreateDirectory(folder);
                string safe = symbol.Replace(" ", "_");
                foreach (char c in Path.GetInvalidFileNameChars()) safe = safe.Replace(c, '_');
                path = Path.Combine(folder, safe + "_flow_" + DateTime.UtcNow.ToString("yyyyMMdd_HHmmss") + "_" + capture + ".csv");
                queue = new BlockingCollection<string>(100000);
                recording = true;
                worker = new Thread(WriteRows);
                worker.IsBackground = true;
                worker.Start();
                Record("START", DateTime.MinValue, DateTime.UtcNow, 0, 0, "", -1,
                    "realtime_phase_capture; local_sequence_not_exchange_sequence; depth_initial_snapshot_unverified");
                HookConnectionEvents();
                timer = new Timer(delegate(object ignored) {
                    Record("HEARTBEAT", DateTime.MinValue, DateTime.UtcNow, 0, 0, "", -1, "recorder_alive_not_proof_of_feed_health");
                }, null, 1000, 1000);
                Print("SovereignMGC flow CSV: " + path);
            }
            else if (State == State.Terminated)
            {
                try { if (connectionEvent != null && connectionHandler != null) connectionEvent.RemoveEventHandler(null, connectionHandler); } catch { }
                if (timer != null) timer.Dispose();
                lock (gate)
                {
                    if (recording) Record("STOP", DateTime.MinValue, DateTime.UtcNow, 0, 0, "", -1, "capture_closed");
                    recording = false;
                    if (queue != null && !queue.IsAddingCompleted) queue.CompleteAdding();
                }
                if (worker != null && !worker.Join(10000)) Print("Flow writer is still draining; check its status file before copying.");
            }
        }

        private void Record(string type, DateTime eventTime, DateTime received, double price, long size, string operation, int position, string note,
            string barEnd = "", string barOpen = "", string barHigh = "", string barLow = "", string barClose = "", string barVolume = "")
        {
            lock (gate)
            {
                if (!recording || failed || queue == null) return;
                // Timestamp under the same lock as the local sequence. It is the
                // recorder observation time, not an exchange timestamp.
                received = DateTime.UtcNow;
                string row = string.Join(",", capture, (++sequence).ToString(CultureInfo.InvariantCulture), T(eventTime), T(received), Q(symbol), type,
                    type == "TRADE" || type == "BID" || type == "ASK" || type.StartsWith("DEPTH_") ? N(price) : "",
                    size.ToString(CultureInfo.InvariantCulture), bid > 0 ? N(bid) : "", ask > 0 ? N(ask) : "",
                    bid > 0 ? bidSize.ToString(CultureInfo.InvariantCulture) : "", ask > 0 ? askSize.ToString(CultureInfo.InvariantCulture) : "",
                    T(bidReceived), T(askReceived), Q(operation), position < 0 ? "" : position.ToString(CultureInfo.InvariantCulture), Q(note),
                    barEnd, barOpen, barHigh, barLow, barClose, barVolume);
                if (!queue.TryAdd(row))
                {
                    failed = true;
                    stopReason = "queue_overflow";
                    recording = false;
                    queue.CompleteAdding();
                    Print("FLOW CAPTURE STOPPED: queue overflow. The recording is incomplete.");
                }
            }
        }

        private void WriteRows()
        {
            long written = 0, bytes = 0;
            long cap = (long)MaxCaptureMegabytes*1024*1024;
            try
            {
                using (StreamWriter writer = new StreamWriter(new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.Read), new UTF8Encoding(false), 65536))
                {
                    writer.WriteLine("capture_id,sequence,event_time_utc,received_time_utc,instrument,event_type,price,size,bid,ask,bid_size,ask_size,bid_received_utc,ask_received_utc,operation,position,note,bar_end_utc,bar_open,bar_high,bar_low,bar_close,bar_volume");
                    DateTime flushed = DateTime.UtcNow;
                    while (!queue.IsCompleted)
                    {
                        string row;
                        if (queue.TryTake(out row, 1000))
                        {
                            int size = Encoding.UTF8.GetByteCount(row)+2;
                            if (bytes+size > cap)
                            {
                                lock (gate) { failed = true; recording = false; stopReason = "size_limit"; if (!queue.IsAddingCompleted) queue.CompleteAdding(); }
                                Print("MGC FLOW recording size limit reached. Trading strategy is separate and unchanged.");
                                break;
                            }
                            writer.WriteLine(row); written++; bytes += size;
                        }
                        if ((DateTime.UtcNow - flushed).TotalSeconds >= 1)
                        { writer.Flush(); flushed = DateTime.UtcNow; WriteStatus("RECORDING",written,bytes); }
                    }
                }
                WriteStatus(failed ? "INCOMPLETE" : "CLOSED",written,bytes);
            }
            catch (Exception)
            {
                failed = true;
                recording = false; stopReason = "writer_failed";
                try { WriteStatus("INCOMPLETE",written,bytes); } catch { }
                Print("FLOW CAPTURE STOPPED: writer failed. Check disk access and available space.");
            }
        }

        private void WriteStatus(string state,long written,long bytes)
        {
            // Status failure affects only this recorder, never the order bridge.
            string value = state+"\nupdated_utc="+T(DateTime.UtcNow)+"\nrows="+written+"\nbytes="+bytes+
                "\ntrade_events="+Interlocked.Read(ref tradeEvents)+"\nbid_events="+Interlocked.Read(ref bidEvents)+
                "\nask_events="+Interlocked.Read(ref askEvents)+"\ndepth_events="+Interlocked.Read(ref depthEvents)+
                "\ndepth_requested="+EnableDepthCapture+"\nfeed_source_unverified=true\nlocal_sequence_only=true\nstop_reason="+stopReason+"\n";
            File.WriteAllText(path+".status.txt",value);
        }

        protected override void OnBarUpdate()
        {
            if (State != State.Realtime || !recording || failed || BarsInProgress != 0 || CurrentBar < 1 || !IsFirstTickOfBar) return;
            DateTime end = EventUtc(Time[1]);
            if (end == DateTime.MinValue) return;
            Record("BAR", end, DateTime.UtcNow, 0, 0, "", -1, "completed_previous_one_minute_bar",
                T(end), N(Open[1]), N(High[1]), N(Low[1]), N(Close[1]), Volume[1].ToString(CultureInfo.InvariantCulture));
        }

        protected override void OnMarketData(MarketDataEventArgs e)
        {
            if (State != State.Realtime || !recording || failed) return;
            DateTime received = DateTime.UtcNow;
            lock (gate)
            {
                string type;
                if (e.MarketDataType == MarketDataType.Bid)
                { type = "BID"; Interlocked.Increment(ref bidEvents); bid = e.Price; bidSize = e.Volume; bidReceived = received; }
                else if (e.MarketDataType == MarketDataType.Ask)
                { type = "ASK"; Interlocked.Increment(ref askEvents); ask = e.Price; askSize = e.Volume; askReceived = received; }
                else if (e.MarketDataType == MarketDataType.Last) { type = "TRADE"; Interlocked.Increment(ref tradeEvents); }
                else return;
                DateTime stamp = EventUtc(e.Time);
                Record(type, stamp, received, e.Price, e.Volume, "", -1,
                    stamp == DateTime.MinValue ? "source_time_unusable" : "platform_event_time_not_attested_exchange_time");
            }
        }

        protected override void OnMarketDepth(MarketDepthEventArgs e)
        {
            if (State != State.Realtime || !recording || !EnableDepthCapture || failed) return;
            string type = e.MarketDataType == MarketDataType.Bid ? "DEPTH_BID" : e.MarketDataType == MarketDataType.Ask ? "DEPTH_ASK" : "";
            if (type.Length > 0)
            {
                Interlocked.Increment(ref depthEvents);
                Record(type, DateTime.MinValue, DateTime.UtcNow, e.Price, e.Volume,
                    e.Operation.ToString(), e.Position, "receipt_time_only; initial_depth_snapshot_unverified");
            }
        }

        private void HookConnectionEvents()
        {
            try
            {
                // Hook the public platform event without assuming a strategy-only override.
                connectionEvent = typeof(NinjaTrader.Cbi.Connection).GetEvent("ConnectionStatusUpdate", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
                if (connectionEvent == null) throw new InvalidOperationException();
                var method = GetType().GetMethod("HandleConnectionStatus", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                connectionHandler = Delegate.CreateDelegate(connectionEvent.EventHandlerType, this, method);
                connectionEvent.AddEventHandler(null, connectionHandler);
                Record("MONITOR_READY", DateTime.MinValue, DateTime.UtcNow, 0, 0, "", -1, "connection_event_hook_available");
            }
            catch
            {
                Record("MONITOR_UNAVAILABLE", DateTime.MinValue, DateTime.UtcNow, 0, 0, "", -1, "connection_monitor_unavailable; feed_continuity_not_attested");
                Print("Flow recorder: connection-status hook unavailable; the CSV is flagged accordingly.");
            }
        }

        private void HandleConnectionStatus(object sender, EventArgs update)
        {
            lock (gate)
            {
                if (!recording) return;
                bid = ask = 0; bidSize = askSize = 0;
                bidReceived = askReceived = DateTime.MinValue;
                // Read status metadata only, accommodating API-version property differences.
                string note = "connection_change; quotes_reset; depth_snapshot_invalidated";
                foreach (string key in new string[] { "PriceStatus", "Status" })
                {
                    var property = update.GetType().GetProperty(key);
                    if (property != null) note += "; " + key + "=" + Convert.ToString(property.GetValue(update, null), CultureInfo.InvariantCulture);
                }
                Record("CONNECTION", DateTime.MinValue, DateTime.UtcNow, 0, 0, "", -1, note);
            }
        }

        [NinjaScriptProperty]
        [Display(Name = "Enable depth capture", Order = 1, GroupName = "Capture")]
        public bool EnableDepthCapture { get; set; }

        [NinjaScriptProperty]
        [Range(16,4096)]
        [Display(Name = "Maximum capture MB", Order = 2, GroupName = "Capture")]
        public int MaxCaptureMegabytes { get; set; }
    }
}
