"""One coherent chart timeline for live warmup; never merge research bars."""
import hashlib
import pandas as pd
from .mgc_execution import BridgeError,validate_chart_rows
from .mgc_live_signals import normalized_minutes

COLUMNS=('time_utc','instrument','open','high','low','close','volume')


def fingerprint(frame):
    core=frame.loc[:,list(COLUMNS[1:])].copy()
    core['instrument']=core.instrument.astype(str)
    for name in COLUMNS[2:]:core[name]=core[name].astype(float)
    hashed=pd.util.hash_pandas_object(core,index=True).to_numpy(dtype='uint64')
    return hashlib.sha256(hashed.tobytes()).hexdigest()


class ChartHistory:
    def __init__(self):
        self.count=0;self.digest=None;self.symbol=None;self.first=None;self.last=None

    def accept(self,chart,symbol,through):
        missing=set(COLUMNS)-set(chart.columns)
        if missing:raise BridgeError('Chart columns missing: '+','.join(sorted(missing)))
        if chart.empty:raise BridgeError('Chart history is empty; research bars cannot replace it')
        chart=chart.loc[:,list(COLUMNS)].copy()
        validate_chart_rows(chart.to_dict('records'),symbol)
        frame=normalized_minutes(chart)
        through=pd.Timestamp(through)
        if frame.index[-1]!=through or (frame.index>through).any():
            raise BridgeError('Chart history must end at the native last completed candle')
        if self.symbol is not None and self.symbol!=symbol:
            raise BridgeError('Native chart expiry changed during this run')
        if self.count and (len(frame)<self.count or fingerprint(frame.iloc[:self.count])!=self.digest):
            raise BridgeError('Previously accepted chart candles changed or disappeared; stop and start a fresh flat run')
        digest=fingerprint(frame)
        self.count=len(frame);self.digest=digest;self.symbol=symbol;self.first=frame.index[0];self.last=frame.index[-1]
        return frame

    def receipt(self):
        return dict(source='current_native_chart_only',instrument=self.symbol,rows=self.count,
            first_bar_utc=self.first.isoformat() if self.first is not None else None,
            last_bar_utc=self.last.isoformat() if self.last is not None else None,
            accepted_prefix_sha256=self.digest,research_bars_merged=False,
            midrun_revisions_rejected=True,synthetic_gap_fills=False,
            historical_profit_report_revalidated=False,
            merge_policy='User must configure DoNotMerge; not independently certified by this receipt',
            flow='Chart OHLCV does not supply historical bid/ask/last order flow')
