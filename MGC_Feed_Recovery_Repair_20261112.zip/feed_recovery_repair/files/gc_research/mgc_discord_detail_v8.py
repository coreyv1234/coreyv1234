"""Detailed, read-only Sim101 notifications from native execution journals."""
import csv
import hashlib
from datetime import datetime,timedelta,timezone
from decimal import Decimal as D
import json
from pathlib import Path
import re
import time

from .market import CT
from .mgc_bridge_io_v5 import read_bridge_text
from .mgc_execution import atomic_text
from .mgc_sim_execution_v3 import healthy_state,ExecutionConfig,BridgeError

BUILDS=('build=20261106SIM3|','build=20261109SIM6|','build=20261109SIM10|','build=20261109SIM11|','build=20261111SIM16|','build=20261112SIM17|','build=20261112SIM18|')
ALERTS={'HALTED','FLATTEN_REQUEST','FLATTEN_FAILED','COMMAND_REJECTED','COMMAND_INVALID','DUPLICATE_EXECUTION','CONNECTION_STATUS','GOAL_REACHED','QUOTE_PAUSED','QUOTE_RECOVERED','FEED_RECOVERED'}


def decimal(value):return D(str(value))
def cents(value):return decimal(value).quantize(D('.01'))
def money(value):
    value=cents(value)
    return ('+$' if value>=0 else '-$')+format(abs(value),',.2f')
def price(value):return format(decimal(value),'.1f')
def meta(value):return dict(p.split('=',1) for p in str(value).split('|') if '=' in p)
def utc(value):return datetime.fromisoformat(str(value).replace('Z','+00:00'))
def session_of(value):
    local=utc(value).astimezone(CT)
    return (local.date()+timedelta(days=int(local.hour>=17))).isoformat()
def label(direction):return '🟢 LONG' if direction==1 else '🔴 SHORT' if direction==-1 else 'FLAT'
def read_rows(path):
    text=read_bridge_text(path)
    return list(csv.DictReader(text[:text.rfind('\n')+1].splitlines()))


def stats(closes,session=None):
    rows=[r for r in closes if session is None or r['session']==session]
    pnls=[cents(r['pnl']) for r in rows];wins=sum(p>0 for p in pnls);losses=sum(p<0 for p in pnls)
    flats=len(pnls)-wins-losses;profit=sum((p for p in pnls if p>0),D(0));loss=-sum((p for p in pnls if p<0),D(0))
    streak=0
    if pnls and pnls[-1]!=0:
        sign=1 if pnls[-1]>0 else -1
        for p in reversed(pnls):
            if p==0 or (1 if p>0 else -1)!=sign:break
            streak+=sign
    return dict(trades=len(rows),wins=wins,losses=losses,flats=flats,
        win_rate=100*wins/(wins+losses) if wins+losses else 0.,
        net=float(sum(pnls,D(0))),pf=float(profit/loss) if loss else None,streak=streak)


def stat_text(s):
    pf=f"{s['pf']:.2f}" if s['pf'] is not None else 'n/a (no losing trades)'
    return f"{s['wins']}W/{s['losses']}L/{s['flats']}F | WR {s['win_rate']:.1f}% (decided trades) | net {money(s['net'])} | PF {pf} | streak {s['streak']:+d}"


class JournalBook:
    """Reconstruct notifications only. Never supplies account state or orders."""
    def __init__(self,key,rows):
        created=[r for r in rows if r['event']=='CREATED']
        if len(created)!=1 or not created[0]['detail'].startswith(BUILDS):raise ValueError('Unsupported native notification journal')
        self.build=meta(created[0]['detail']).get('build','');self.key=key;self.fee=decimal(created[0]['price']);self.cash=50000+decimal(created[0]['cumulative_net'])
        self.groups={};self.orders={};self.executions=set();self.closes=[];self.invalid_closes=0
        self.anomalies=0;self.seen=0

    def protection(self,model):
        stop=target=0
        for order in self.orders.values():
            if order['from']!='MGCR_'+model or order['state'] not in ('Accepted','Working','PartFilled'):continue
            if order['name']=='Stop loss':stop+=order['remaining']
            if order['name']=='Profit target':target+=order['remaining']
        return stop,target

    def consume(self,row):
        event=row['event'];model=row['model_id'];info=meta(row['detail'])
        q=int(row['quantity']);p=decimal(row['price']);cash=50000+decimal(row['cumulative_net']);out={}
        before=self.cash;self.cash=cash
        if event=='ENTRY_REQUEST':
            self.groups[model]=dict(direction=int(info['direction']),submitted=q,entered=0,exited=0,open=0,
                average=D(0),entry_value=D(0),exit_value=D(0),net=D(0),fees=D(0),first=None,last=None,
                stop=decimal(info.get('stop',0)),initial_stop=decimal(info.get('stop',0)),target=decimal(info.get('target',0)),risk=decimal(info.get('risk',0)),
                invalid=False,last_exit_order='',coverage_announced=0)
            out['request']=self.groups[model]
        elif event=='ORDER' and info.get('order'):
            filled=max(int(info.get('filled',0)),self.orders.get(info['order'],{}).get('filled',0))
            self.orders[info['order']]=dict(name=row['detail'].split('|',1)[0],state=info.get('state',''),
                remaining=max(0,q-filled),filled=filled,**{'from':info.get('from','')})
        elif event=='STOP_REQUEST' and model in self.groups:
            self.groups[model]['stop']=p
        elif event in ('ENTRY_FILL','EXIT_FILL'):
            group=self.groups.get(model)
            if group is None:self.anomalies+=1;return dict(warning='Fill without a matching request; performance tracking incomplete')
            identity=(info.get('order'),info.get('exec'))
            if not all(identity) or identity in self.executions:
                group['invalid']=True;self.anomalies+=1
                return dict(warning='Missing/duplicate execution identity; this trade will not enter win/loss statistics')
            self.executions.add(identity)
            d=int(info.get('direction',0))
            if d!=group['direction'] or q<=0:
                group['invalid']=True;self.anomalies+=1;return dict(warning='Execution side/size mismatch')
            if event=='ENTRY_FILL':
                if group['exited']:group['invalid']=True;self.anomalies+=1
                group['average']=(group['average']*group['open']+p*q)/(group['open']+q)
                group['open']+=q;group['entered']+=q;group['entry_value']+=p*q
                group['first']=group['first'] or info.get('fill_utc',row['time_utc'])
                expected=-self.fee*q/2
                if group['entered']>group['submitted']:group['invalid']=True
            else:
                if q>group['open']:
                    group['invalid']=True;self.anomalies+=1;return dict(warning='Exit exceeds tracked position')
                expected=(d*(p-group['average'])*10-self.fee/2)*q
                group['open']-=q;group['exited']+=q;group['exit_value']+=p*q
                group['last']=info.get('fill_utc',row['time_utc']);group['last_exit_order']=info.get('order','')
            if abs((cash-before)-expected)>D('.00001'):group['invalid']=True;self.anomalies+=1
            group['net']+=expected;group['fees']+=self.fee*q/2
            out['fill']=group
        elif event=='TRADE_CLOSED':
            group=self.groups.pop(model,None)
            if group is None:self.anomalies+=1;return dict(warning='Close without matching tracked request')
            entry_ack=max([o['filled'] for o in self.orders.values() if o['name']=='MGCR_'+model] or [0])
            exit_ack=sum(o['filled'] for o in self.orders.values() if o['from']=='MGCR_'+model)
            if entry_ack>group['entered'] or exit_ack>group['exited']:
                self.invalid_closes+=1;return dict(warning='Close has acknowledged fills without execution callbacks; excluded from performance statistics')
            if group['entered']==0:return dict(unfilled=True)
            if group['invalid'] or group['open'] or group['entered']!=group['exited']:
                self.invalid_closes+=1;return dict(warning='Trade closed with unreconciled callbacks; excluded from win/loss statistics')
            pnl=cents(group['net']);outcome='✅ WIN' if pnl>0 else '❌ LOSS' if pnl<0 else '➖ FLAT'
            exit_order=self.orders.get(group['last_exit_order'],{}).get('name','Native exit (reason unavailable)')
            held=max(0.,(utc(group['last'])-utc(group['first'])).total_seconds()) if group['first'] and group['last'] else None
            closed=dict(id=self.key+':'+model,model_id=model,session=session_of(row['time_utc']),closed_utc=row['time_utc'],
                pnl=float(pnl),fees=float(group['fees']),direction=group['direction'],quantity=group['entered'],
                entry=float(group['entry_value']/group['entered']),exit=float(group['exit_value']/group['exited']),
                outcome=outcome,reason=exit_order,held_seconds=held)
            self.closes.append(closed);out['closed']=closed
        group=self.groups.get(model)
        if group and group['open']>0 and group['coverage_announced']!=group['open']:
            sl,tp=self.protection(model)
            if sl>=group['open'] and tp>=group['open']:
                group['coverage_announced']=group['open'];out['protection']=(sl,tp,group['open'])
        return out


class DetailedNotifications:
    def __init__(self,folder,notifications,clock=time.monotonic):
        self.folder=Path(folder);self.path=self.folder/'executions.csv';self.notifications=notifications;self.clock=clock
        self.sources={};self.archived=[];self.restore_errors=0;self.errors=0;self.last_error=None
        self.noon_sent=set();self.summary_sent=set();self.stage=None;self.rejections={}
        self.next_hour=clock()+3600
        current_rows=read_rows(self.path)
        seen_journals={hashlib.sha256(json.dumps(current_rows,sort_keys=True).encode()).digest()}
        for previous in sorted(self.folder.parent.glob('run_*')):
            if previous==self.folder or not re.fullmatch(r'run_[a-f0-9]{32}',previous.name):continue
            path=previous/'executions.csv'
            if not path.is_file():continue
            try:
                rows=read_rows(path)
                identity=hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).digest()
                if identity in seen_journals:continue
                seen_journals.add(identity)
                book=JournalBook(previous.name,rows)
                for row in rows:book.consume(row)
                self.archived.extend(book.closes)
                self.restore_errors+=book.invalid_closes+book.anomalies+sum(g['entered']>0 for g in book.groups.values())
            except Exception:self.restore_errors+=1
        self.archived.sort(key=lambda r:utc(r['closed_utc']))
        rows=current_rows;self.book=JournalBook(self.folder.name,rows)
        for row in rows:self.book.consume(row)
        self.seen=len(rows)
        source_path=self.folder/'notification_sources.jsonl'
        if source_path.exists():
            try:
                for line in source_path.read_text().splitlines():
                    source=json.loads(line);self.sources[source['model_id']]=source
            except Exception:self.errors+=1

    def send(self,text):return self.notifications.publish(text)

    def closes(self):
        unique={r['id']:r for r in self.archived+self.book.closes}
        return sorted(unique.values(),key=lambda r:utc(r['closed_utc']))

    def source_name(self,model):return self.sources.get(model,{}).get('family','family unavailable in older journal').replace('_',' ')

    def command_sent(self,row,signal):
        if row['kind']!='ENTER':return
        try:
            source=dict(model_id=row['model_id'],family=signal.family,instrument=signal.instrument)
            self.sources[row['model_id']]=source
            with (self.folder/'notification_sources.jsonl').open('a',encoding='utf-8') as stream:stream.write(json.dumps(source)+'\n')
            self.send(f"🧠 MGC SETUP ACCEPTED | Sim101 | {label(int(row['direction']))} | {signal.family.replace('_',' ')}\n"
                f"{signal.instrument} | Qty {row['quantity']} | Expected entry {price(row['expected_entry'])}\n"
                f"SL {price(row['stop'])} | Target {price(row['target'])} | Planned risk ${float(row['planned_risk']):,.2f}\n"
                'Entry command sent. This is a request, not an execution fill.')
        except Exception:self.error('Could not record setup notification')

    def error(self,message):
        self.errors+=1
        if message!=self.last_error:
            self.send('⚠️ MGC NOTIFICATION TRACKING | Sim101 | '+message+'\nNative order/risk handling is independent. Check local logs.')
            self.last_error=message

    def poll(self,state):
        try:
            rows=read_rows(self.path)
            if len(rows)<self.seen:self.error('Native journal shrank; performance tracking paused');return
            for row in rows[self.seen:]:
                self.seen+=1
                try:
                    result=self.book.consume(row);event=row['event'];model=row['model_id'];cash=50000+decimal(row['cumulative_net'])
                    if result.get('warning'):self.error(result['warning'])
                    if 'fill' in result:
                        g=result['fill'];name='🔥 ENTRY FILLED' if event=='ENTRY_FILL' else '💰 EXIT FILLED'
                        initial_risk=max(D(0),(g['direction']*(g['average']-g['initial_stop'])*10+self.book.fee+1)*g['open'])
                        self.send(f"{name} | Sim101 | {label(g['direction'])} | {self.source_name(model)}\n"
                            f"{state['instrument']} | Fill qty {row['quantity']} @ {price(row['price'])} | Tracked remaining {g['open']}\n"
                            f"Avg entry {price(g['average'])} | Remaining initial-risk estimate ${float(initial_risk):,.2f}\n"
                            f"SL requested {price(g['stop'])} | Target requested {price(g['target'])}\n"
                            f"Simulation ledger ${float(cash):,.2f} | Fees assumed ${float(self.book.fee):.2f}/contract round turn.\n"
                            'Fill callback recorded; bracket coverage is reported separately.')
                    if 'protection' in result:
                        sl,tp,q=result['protection']
                        self.send(f'🔐 MGC BRACKETS REPORTED | Sim101\nStop coverage {sl}/{q} | Target coverage {tp}/{q}\nBased on native Accepted/Working callbacks; inspect Orders/Positions for actual protection.')
                    if 'closed' in result:
                        c=result['closed'];all_stats=stats(self.closes());day=stats(self.closes(),c['session'])
                        day_cash=money(cash-decimal(state['session_open_cash'])) if state['session']==c['session'] else 'unavailable during session transition'
                        self.send(f"🏁 MGC TRADE CLOSED | {c['outcome']} | Sim101 | {label(c['direction'])}\n"
                            f"{self.source_name(model)} | Qty {c['quantity']} | Entry {price(c['entry'])} | Exit {price(c['exit'])}\n"
                            f"Reason {c['reason']} | Net {money(c['pnl'])} | Assumed fees ${c['fees']:.2f} | Hold {c['held_seconds']:.1f}s\n"
                            f"Simulation ledger ${float(cash):,.2f} | Session cash P&L {day_cash}\n"
                            f"Session closed trades: {day['trades']} | {day['wins']}W/{day['losses']}L/{day['flats']}F\n"
                            f"Tracked: {stat_text(all_stats)}\nScope: recorded local Sim101 bridge closes; not the historical backtest.")
                        self.persist(state)
                    if result.get('unfilled'):self.send('⏹️ MGC ORDER CLOSED UNFILLED | Sim101 | Not counted as a win, loss or flat trade.')
                    if event=='STOP_REQUEST':
                        self.send(f"🛡️ MGC STOP UPDATE REQUESTED | Sim101\nQty {row['quantity']} | New stop {price(row['price'])}\nEffective after the triggering closed candle; native order acceptance remains separate.")
                    if (event=='HALTED' and self.book.build=='20261112SIM18'
                            and row['detail']=='Active MGC market-data stream silent for more than thirty seconds'):
                        self.send('📡 MGC FEED PAUSED | Sim101\nAll market-data updates stopped for over30seconds. Native safety close/reconciliation is active. Python remains running and watching for fresh data; new orders are blocked until fully reconciled flat.')
                    elif event in ALERTS:
                        self.send(f"{'🚨' if event in ('HALTED','FLATTEN_FAILED','COMMAND_INVALID') else '📣'} MGC {event.replace('_',' ')} | Sim101\n"
                            f"{row['detail'][:600]}\nSimulation ledger ${float(cash):,.2f} | Check native Orders/Positions for execution state.")
                except Exception:self.error('A native notification record could not be reconciled')
        except Exception:self.error('Native journal read unavailable; notifications will retry on the next loop')

    def persist(self,state):
        try:
            result=dict(scope='local_native_sim101_closed_trades',session=state['session'],all=stats(self.closes()),
                current_session=stats(self.closes(),state['session']),incomplete_records=self.restore_errors+self.errors+self.book.invalid_closes+self.book.anomalies)
            atomic_text(self.folder/'notification_performance.json',json.dumps(result,indent=2)+'\n')
        except Exception:self.error('Performance summary file could not be written')

    def status_text(self,state,now,planner=None):
        cash=50000+decimal(state['realized_net']);opening=decimal(state['session_open_cash']);firm=decimal(state['highwater'])-2000
        reserved=max(firm+50,opening-850);q=int(state['quantity']);d=int(state['direction'])
        try:healthy_state(state,now,ExecutionConfig());ready='READY'
        except BridgeError as error:ready=str(error)
        if (self.book.build=='20261112SIM18' and state.get('blocked')
                and state.get('reason')=='Active MGC market-data stream silent for more than thirty seconds'):
            ready='WAITING FOR FEED RECOVERY; controller running; entries blocked'
        elif state.get('reason'):ready+=' | '+state['reason'][:180]
        local=now.astimezone(CT);minute=local.hour*60+local.minute
        entry_window=local.weekday()<5 and 120<=minute<720
        position=f"{label(d)} {q} @ {price(state['average_entry'])}" if q else 'FLAT'
        if q:
            quote=decimal(state['bid'] if d==1 else state['ask'])
            open_net=(d*(quote-decimal(state['average_entry']))*10-self.book.fee/2-1)*q
            position+=f" | liquidation estimate {money(open_net)} (remaining exit costs included)"
        gate=getattr(planner,'day_decisions',{}).get(state['session'],{})
        pending=getattr(planner,'limit_order',None)
        pending_name=pending.signal.family.replace('_',' ') if pending else 'NONE'
        sl,tp=self.book.protection(state['active_id']) if state['active_id'] else (0,0)
        day=stats(self.closes(),state['session']);all_stats=stats(self.closes())
        return (f"{local.strftime('%Y-%m-%d %H:%M:%S %Z')} | Sim101 | {state['instrument']}\n"
            f"State: {ready} | Entry window {'OPEN' if entry_window else 'CLOSED'} | Day filter {gate.get('accepted','not evaluated')}\n"
            f"Position: {position}\nSL requested {price(state['stop']) if q else 'n/a'} | Target requested {price(state['target']) if q else 'n/a'} | Reported SL/TP coverage {sl}/{tp}\n"
            f"Ledger ${float(cash):,.2f} | Session cash P&L {money(cash-opening)} | From $48,615 {money(cash-48615)}\n"
            f"Firm floor ${float(firm):,.2f} | Cash cushion ${float(cash-firm):,.2f} | Reserved cash room ${float(max(D(0),cash-reserved)):,.2f}\n"
            f"Session: {day['trades']} closes | {day['wins']}W/{day['losses']}L/{day['flats']}F | Closed net {money(day['net'])} | Submitted entries {state['session_count']}/20\n"
            f"Tracked: {stat_text(all_stats)}\nPending setup: {pending_name} | Quote age {(now-state['quote_utc']).total_seconds():.1f}s | Bar age {(now-state['last_bar_utc']).total_seconds():.1f}s\n"
            f"SIM stage {'uncapped' if state['goal_reached'] else '$1,200 daily profit budget'} | To $53,000 ${float(max(D(0),53000-cash)):,.2f}\n"
            f"Discord sent/failed/dropped: {self.notifications.sent}/{self.notifications.failed}/{self.notifications.dropped} | Tracking issues {self.restore_errors+self.errors+self.book.invalid_closes+self.book.anomalies}\n"
            'Simulation ledger with assumed fees; chart provider/protection execution unverified.')

    def started(self,state,startup):
        self.send('🚀 MGC BOT CONNECTED | SIM101\n'+self.status_text(state,datetime.now(timezone.utc))+
            f"\nMid-session join; early opening-range skipped={startup['opening_range_skipped']}. No historical trades replayed.")
        self.persist(state)

    def tick(self,state,now,planner=None):
        try:
            if self.clock()>=self.next_hour:
                accepted=self.send('📡 MGC HOURLY HEARTBEAT\n'+self.status_text(state,now,planner))
                self.next_hour=self.clock()+(60 if accepted is False else 3600)
                self.persist(state)
            local=now.astimezone(CT);minute=local.hour*60+local.minute;session=state['session']
            if local.date().isoformat()==session and local.weekday()<5:
                if minute>=720 and session not in self.noon_sent:
                    self.noon_sent.add(session)
                    self.send('⏰ MGC NEW ENTRIES CLOSED AT NOON | SIM101\nExisting positions retain native management until the 15:55 safety close.\n'+self.status_text(state,now,planner))
                if minute>=955 and not state['quantity'] and not state['orders_working'] and session not in self.summary_sent:
                    self.summary_sent.add(session)
                    self.send('📊 MGC SESSION SUMMARY | SIM101\n'+self.status_text(state,now,planner));self.persist(state)
        except Exception:self.error('Hourly/session notification could not be formatted')

    def decision(self,decision,state):
        try:
            current=decision.get('rejections',{});new={k:v-self.rejections.get(k,0) for k,v in current.items() if v>self.rejections.get(k,0)}
            self.rejections=dict(current)
            if decision.get('sources') and decision.get('decision')=='NO_COMMAND':
                waiting='waiting for confirmation' if decision.get('proposal_waiting') else 'no eligible entry command'
                descriptions={'insufficient_risk_budget':'risk room below one contract',
                    'trade_model_nonpositive_or_missing_context':'setup/context not approved by model',
                    'source_cannot_replace_resting_order':'existing setup already pending',
                    'actual_quote_risk_or_profit_room':'quote exceeds risk or profit room',
                    'actual_quote_invalidates_bracket':'quote passed planned stop/target'}
                reasons=', '.join(f'{descriptions.get(k,k.replace("_"," "))}: {v}' for k,v in list(new.items())[:4]) or 'see local decision log/day filter'
                self.send(f"👀 MGC SETUP CHECK | Sim101\n{decision['sources']} source candidates | {waiting}\nNew rejection counters: {reasons}\nNo entry fill is implied.")
        except Exception:self.error('Decision notification could not be formatted')


def drain_notifications(notifications,timeout=2.):
    deadline=time.monotonic()+timeout
    while notifications.sender is not None and notifications.queue.unfinished_tasks and time.monotonic()<deadline:
        time.sleep(.02)


class UnavailableNotifications:
    def __init__(self,notifications):
        self.notifications=notifications
        self.heartbeat=WaitingHeartbeat(notifications)
        self.notifications.publish('⚠️ MGC NOTIFICATION TRACKING UNAVAILABLE | Sim101\nLocal journal reconstruction failed. Native order/risk handling continues independently; check local logs. Win/loss statistics are unavailable.')
    def poll(self,state):pass
    def tick(self,state,now,planner=None):
        self.heartbeat.tick('Detailed execution-journal tracking unavailable; check local notification logs. '+
            'Native reason: '+str(state.get('reason',''))+'. Position/win-loss statistics are unavailable.',tracking_degraded=True)
    def command_sent(self,row,signal):pass
    def decision(self,decision,state):pass
    def started(self,state,startup):
        self.notifications.publish('🚀 MGC CONTROLLER CONNECTED | Sim101 | Detailed notification tracking unavailable; inspect local execution logs.')


def make_notifications(folder,notifications):
    try:
        service=DetailedNotifications(folder,notifications)
        print('Detailed Discord tracking active | hourly reports every60minutes from connection.',flush=True)
        return service
    except Exception as error:
        print('Detailed Discord tracking unavailable ('+type(error).__name__+'); basic hourly reports remain active.',flush=True)
        return UnavailableNotifications(notifications)


class WaitingHeartbeat:
    def __init__(self,notifications,clock=time.monotonic):
        self.notifications=notifications;self.clock=clock;self.next_hour=clock()+3600
    def tick(self,reason,tracking_degraded=False):
        if self.clock()>=self.next_hour:
            accepted=self.notifications.publish('📡 MGC HOURLY HEARTBEAT | SIM101 | '+
                ('TRACKING DEGRADED' if tracking_degraded else 'WAITING FOR STARTUP')+
                '\n'+str(reason)[:1200]+'\nThis notification does not certify entry readiness, positions or fills.')
            self.next_hour=self.clock()+(60 if accepted is False else 3600)
