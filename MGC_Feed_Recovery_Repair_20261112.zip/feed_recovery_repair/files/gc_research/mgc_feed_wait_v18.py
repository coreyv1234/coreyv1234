"""Keep the controller alive for the specific recoverable native data fault."""
from .mgc_execution import BridgeError

FEED_TIMEOUT_REASON = 'Active MGC market-data stream silent for more than thirty seconds'


def awaiting_feed_recovery(state, now):
    if not state['blocked']:
        return False
    if state['reason'] != FEED_TIMEOUT_REASON:
        raise BridgeError('Native halt: ' + state['reason'])
    if state['ledger_uncertain']:
        raise BridgeError('Feed interruption with uncertain ledger; reconcile manually')
    age = (now - state['updated_utc']).total_seconds()
    if not 0 <= age <= 5:
        raise BridgeError('Native status unavailable during feed recovery; reconcile manually')
    # This is NOT permission to trade, infer a fill, cancel protection, or use
    # an old flat snapshot. Native callbacks and the native close remain active.
    return True
