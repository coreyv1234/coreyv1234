MGC automatic feed recovery — SIM18 — SIM101 ONLY

Includes SIM17: working brackets stay active during brief quote pauses. One
unchanged bid or ask does not force a close while LAST/other quote events arrive.
Fresh bid/ask and the original deadlines remain required for new orders.

If ALL market-data callbacks disappear for over30seconds, native safety closing
remains active. NEW: Python stays alive, polls native status and delivers hourly
heartbeats instead of exiting just because this specific data fault occurred.

Native may recover ONLY that data fault, with an intact heartbeat and journal,
known account, no uncertainty/foreign activity/failed close/daily block, actual
account flat, all orders terminal, all execution callbacks reconciled, original
trade identity closed, loss reserve intact, fresh valid bid/ask stable3seconds,
and a freshly closed chart minute. Any other fault cancels automatic recovery.
Python then independently checks flat reconciliation, rebuilds context from
actual chart candles and waits for the next closed minute. It never places
catch-up trades or reuses a consumed source. Initial entry and stop freshness,
risk limits, trade counts, session ledger and native exit handling are unchanged.

Discord distinguishes FEED PAUSED / FEED RECOVERED from controller shutdown.
Hourly, fills, bracket coverage, wins/losses and other fault alerts remain.
The installer saves a local MGC_Feed_Incident_*.zip containing whitelisted recent
execution diagnostics. It sends/uploads nothing and excludes private config.

INSTALL over either SIM16 or SIM17; SIM17 need not be installed first:
Stop Python; disable strategy; confirm Sim101 flat and no working orders.
Extract into existing MGC_Bot_With_Setup. Run py .\Repair_MGC_Feed_Recovery.py.
Type RECOVER. Reopen strategy source, accept reload, F5 with zero compile errors.
Press Enter in repair terminal. Enable SAME SovereignMgcResearchSimBridgeV3
on Sim101 after Startup file written. Startup must say Native SIM18.
No private launcher/webhook, ledger, balance, floor or strategy settings changed.

Standalone tests execute extracted production C# methods and Python mocked-feed
tests. They are not NinjaTrader SDK/runtime certification or profit guarantees.
Actual native Orders/Positions remain authoritative during protection/closing.
