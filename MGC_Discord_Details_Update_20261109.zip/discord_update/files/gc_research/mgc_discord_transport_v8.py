"""Paced best-effort Discord delivery; never runs on the trading thread."""
import json
import queue
import time
import urllib.error
import urllib.request
from .execution_notifications import ExecutionNotifications
from .notifications import DiscordNotifier,NotificationError


class ReliableDiscordNotifier(DiscordNotifier):
    def __init__(self,webhook):
        super().__init__(webhook);self.retries=0

    def send(self,message):
        if not isinstance(message,str) or not message or len(message)>2000:
            raise ValueError('Discord message must contain 1–2000 characters')
        payload=json.dumps({'content':message,'allowed_mentions':{'parse':[]}}).encode()
        for attempt in range(3):
            request=urllib.request.Request(self._webhook,data=payload,method='POST',
                headers={'Content-Type':'application/json','User-Agent':'SovereignMgcSim/1.0'})
            wait=1.
            try:
                with urllib.request.urlopen(request,timeout=10) as response:
                    if not 200<=response.status<300:raise NotificationError('Discord returned an unexpected response; details omitted')
                return
            except urllib.error.HTTPError as error:
                status=error.code
                if status==429:
                    try:wait=float(json.loads(error.read(4096)).get('retry_after',1))
                    except Exception:wait=1.
                elif not 500<=status<600:
                    raise NotificationError('Discord delivery rejected (HTTP '+str(status)+'); webhook details omitted') from None
            except (urllib.error.URLError,TimeoutError,OSError):pass
            if attempt==2:raise NotificationError('Discord delivery failed after three attempts; webhook details omitted') from None
            self.retries+=1
            time.sleep(max(.1,min(10.,wait)))


class RateLimitedExecutionNotifications(ExecutionNotifications):
    def _work(self):
        next_send=0.
        while not self.stopping.is_set():
            try:message=self.queue.get(timeout=.1)
            except queue.Empty:continue
            try:
                delay=max(0,next_send-time.monotonic())
                if delay and self.stopping.wait(delay):
                    self.dropped+=1;continue
                self.sender.send(message);self.sent+=1
            except Exception:self.failed+=1
            finally:
                next_send=time.monotonic()+.45
                self.queue.task_done()
