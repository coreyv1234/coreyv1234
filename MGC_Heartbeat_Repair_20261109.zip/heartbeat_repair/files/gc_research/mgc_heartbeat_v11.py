"""Ephemeral liveness writes with a fixed main-loop deadline and local diagnostics."""
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import threading
import time


def write_liveness(path,body,retry_seconds=.25):
    """Atomic visibility without a per-second disk durability/fsync requirement."""
    path=Path(path)
    temporary=path.with_name(path.name+'.tmp.'+str(os.getpid()))
    until=time.monotonic()+retry_seconds
    try:
        while True:
            try:
                with temporary.open('w',encoding='utf-8',newline='') as stream:
                    stream.write(body)
                os.replace(temporary,path)
                return
            except OSError as error:
                transient=(isinstance(error,PermissionError) or getattr(error,'winerror',None) in (5,32,33))
                if not transient or time.monotonic()>=until:raise
                time.sleep(min(.025,max(0.,until-time.monotonic())))
    finally:
        try:temporary.unlink(missing_ok=True)
        except OSError:pass


class Heartbeat:
    def __init__(self,folder,run_id):
        self.folder=Path(folder);self.run_id=run_id
        self.progress=time.monotonic();self.stage='initializing';self.stage_since=self.progress
        self.stop=threading.Event();self.successful_writes=0;self.write_errors=0
        self.last_error=None;self.last_success=None
        self.thread=threading.Thread(target=self.work,daemon=True,name='mgc-heartbeat')
        self.thread.start()

    def mark(self,stage):
        # Diagnostics must never refresh the main-loop liveness deadline.
        self.stage=stage;self.stage_since=time.monotonic()

    def snapshot(self):
        now=time.monotonic()
        return dict(run_id=self.run_id,pid=os.getpid(),updated_utc=datetime.now(timezone.utc).isoformat(),
            main_loop_age_seconds=round(now-self.progress,3),stage=self.stage,
            stage_age_seconds=round(now-self.stage_since,3),main_loop_deadline_seconds=10,
            heartbeat_write_allowed=now-self.progress<10,successful_writes=self.successful_writes,
            write_errors=self.write_errors,last_error=self.last_error,last_success_utc=self.last_success,
            stopped=self.stop.is_set(),native_timeout_seconds=15)

    def beat(self):
        if time.monotonic()-self.progress<10:
            stamp=datetime.now(timezone.utc).isoformat()
            try:
                write_liveness(self.folder/'heartbeat.txt',self.run_id+';'+stamp+'\n')
                self.successful_writes+=1;self.last_success=stamp
            except OSError as error:
                self.write_errors+=1
                self.last_error=dict(type=type(error).__name__,errno=error.errno,winerror=getattr(error,'winerror',None))
        try:write_liveness(self.folder/'controller_health.json',json.dumps(self.snapshot(),indent=2)+'\n')
        except OSError:pass

    def work(self):
        while not self.stop.is_set():
            self.beat()
            self.stop.wait(1)

    def close(self):
        self.stop.set();self.thread.join(timeout=2)
        if not self.thread.is_alive():
            try:write_liveness(self.folder/'controller_health.json',json.dumps(self.snapshot(),indent=2)+'\n')
            except OSError:pass
            try:(self.folder/'heartbeat.txt').unlink(missing_ok=True)
            except OSError:pass
