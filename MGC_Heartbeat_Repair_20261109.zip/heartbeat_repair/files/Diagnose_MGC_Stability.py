"""Read-only heartbeat/loop diagnostics; sends no orders or notifications."""
from datetime import datetime,timezone
import json
from gc_research.mgc_bridge_io_v5 import read_bridge_text,read_complete_csv
from gc_research.mgc_sim_execution_v3 import ExecutionConfig,BridgeError
from tools.run_mgc_research_sim_v4 import bridge_directory,load_native


def main():
    folder,state=load_native(bridge_directory(),ExecutionConfig())
    now=datetime.now(timezone.utc)
    health_path=folder/'controller_health.json'
    health=json.loads(read_bridge_text(health_path)) if health_path.exists() else {'missing':True}
    trace_path=folder/'heartbeat_diagnostics.csv'
    trace=read_complete_csv(trace_path).tail(8).to_dict('records') if trace_path.exists() else []
    print(json.dumps(dict(account=state['account'],run_id=state['run_id'],native_reason=state['reason'],
        blocked=bool(state['blocked']),native_quantity=state['quantity'],orders_working=state['orders_working'],
        native_snapshot_age_seconds=round((now-state['updated_utc']).total_seconds(),3),
        last_closed_bar_utc=state['last_bar_utc'].isoformat(),controller_health=health,
        native_heartbeat_trace=trace,orders_sent=False),indent=2))


if __name__=='__main__':
    try:main()
    except (OSError,ValueError,BridgeError) as error:
        print(json.dumps({'read_error':str(error),'orders_sent':False}))
