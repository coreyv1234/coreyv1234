MGC heartbeat stability repair — native20261109SIM11

The supplied log shows20 consecutive closed minutes21:40–21:59UTC followed by
Native halt: Python heartbeat lost. The earlier candle-delivery failure did not
recur in that interval. The log alone does not prove a file race vs a true stall.

Install only from confirmed flat Sim101 with no working orders:
1. Stop Python and disable SovereignMgcResearchSimBridgeV3.
2. Extract this ZIP into the existing MGC_Bot_With_Setup directory.
3. Run py .\Repair_MGC_Heartbeat.py and type HEARTBEAT after the flat/order checks.
4. The existing NinjaTrader source is updated. Reopen it, accept reload if prompted,
   press F5 and resolve every compilation error. Only then press Enter in terminal.
5. The existing private launcher starts; enable the same strategy on Sim101 only
   after Startup file written. The LocalAppData bridge path is unchanged.

Requires the previous SIM10 bar-delivery update. No trading strategy, risk limit,
account ledger or private Discord launcher is changed. No secrets are included.

Correction: native heartbeat reads now share read/write/delete access so atomic
Python replacement does not collide with a non-delete-sharing reader. A transient
I/O/access error may reuse a previously validated same-run heartbeat ONLY until
that ORIGINAL heartbeat timestamp expires at15seconds. Failed reads never refresh
the timestamp. Invalid run/schema/content, stale/future content, and genuine
timeouts still halt. This does not auto-clear any prior halt or auto-restart.

Python uses bounded(.25s) sharing retries for its ephemeral heartbeat publication,
without forcing a durable fsync everysecond. Durable command/journal publication
is untouched. The main-loop progress deadline remains10seconds. Updating diagnostic
stages does NOT count as main-loop progress. A stuck loop stops heartbeat writes.

Diagnostics: controller_health.json records successful heartbeat writes, sanitized
write errors, last successful UTC and loop-stage/age. Native heartbeat_diagnostics.csv
records valid, transient-read-retry, invalid and expired states. These files remain
local in the existing run directory. If another stop occurs, do not reinstall first:
  .\.venv\Scripts\python.exe .\Diagnose_MGC_Stability.py
Run from the bot folder and paste the JSON output. It is read-only and sends no orders.

Tests run in Linux with mocked native snapshots and actual Python file/thread I/O.
C# syntax and source guard parity are checked; NinjaTrader SDK compilation and
Windows live runtime cannot be certified here. F5 and a new realtime observation
are required. A Python freeze, disk outage, sleep, or stopped process can still
correctly trip the watchdog. Do not disable the protection to mask those faults.
