Mute routine flat-resync Discord notifications only.
Stop Python, disable strategy and verify actual Sim101 flat/no working orders.
Extract ZIP into existing MGC_Bot_With_Setup folder. Run:
  py .\Update_MGC_Quiet_Resync.py
Type QUIET after those checks. No F5/recompile. Existing launcher starts; enable
same strategy after Startup file written. Requires previous fast-entry update.
Only the routine flat-resync Discord publish call is removed. Console and local
resync logs stay. Hourly reports, trade/fill/win/loss and controller-stop alerts stay.
Every other controller AST node is identical. Native source, strategy, financial
ledger, private launcher and webhook unchanged. No cloud Discord messages sent.
This mutes notification noise; it does not repair underlying status delays or
prove uninterrupted entry readiness. A0.0minute clock advance means same-candle
reseed; snapshot_age_seconds still reports the actual stale-status interval.
