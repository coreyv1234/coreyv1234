"""Apply the shipped, bounded bridge-read fix to an existing extracted bot."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tempfile
from datetime import datetime


def digest(body):return hashlib.sha256(body).hexdigest()


def apply(folder):
    folder=Path(folder);payload=folder/'file_access_fix'
    metadata=json.loads((payload/'PATCH.json').read_text())
    manifest_path=folder/'MANIFEST.json'
    manifest=json.loads(manifest_path.read_text())
    for name,expected in manifest.items():
        relative=Path(name)
        if relative.is_absolute() or '..' in relative.parts:raise RuntimeError('Unsafe manifest path')
        if digest((folder/relative).read_bytes())!=expected:
            raise RuntimeError('Existing package has changed: '+name+'. No files were modified.')
    changes=metadata['files']
    for name,info in changes.items():
        relative=Path(name)
        if relative.is_absolute() or '..' in relative.parts:raise RuntimeError('Unsafe patch path')
        if digest((payload/'files'/relative).read_bytes())!=info['new_sha256']:raise RuntimeError('Patch payload hash mismatch')
    if all((folder/n).is_file() and digest((folder/n).read_bytes())==info['new_sha256'] for n,info in changes.items()):
        print('File-access fix already applied. The ledger was not reset.');return
    for name,info in changes.items():
        path=folder/name
        actual=digest(path.read_bytes()) if path.exists() else None
        if actual!=info['old_sha256']:
            raise RuntimeError('Unsupported existing version: '+name+'. No files were modified.')
    backup=Path(tempfile.mkdtemp(prefix='file_access_',dir=str(folder)))
    shutil.copyfile(manifest_path,backup/'MANIFEST.json')
    for name in changes:
        target=folder/name
        if target.exists():
            saved=backup/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(target,saved)
    # Complete staged writes; update the integrity manifest last. An interrupted
    # update fails the existing release verifier rather than running mixed code.
    for name,info in changes.items():
        target=folder/name;target.parent.mkdir(parents=True,exist_ok=True)
        temporary=target.with_name(target.name+'.fix_tmp')
        temporary.write_bytes((payload/'files'/name).read_bytes());temporary.replace(target)
        manifest[name]=info['new_sha256']
    temporary=manifest_path.with_name('MANIFEST.json.fix_tmp')
    temporary.write_text(json.dumps(manifest,indent=2)+'\n');temporary.replace(manifest_path)
    print('File-access fix installed. Trading model, native source and account ledger were not changed.')
    print('Set the NinjaTrader strategy Bridge directory to:')
    print(r'C:\Users\corey\AppData\Local\SovereignMGC\ExecutionBridge')
    print('Then run py Start_MGC_Private.py before enabling the strategy on flat Sim101.')


def main():
    folder=Path(__file__).resolve().parent
    if not (folder/'RunSim101.py').is_file():raise RuntimeError('Extract this fix into the existing bot folder beside RunSim101.py.')
    print('Disable the NinjaTrader strategy and confirm Sim101 is flat with no working orders.')
    if input('Type FIX after doing that: ').strip()!='FIX':raise RuntimeError('Canceled; no files changed.')
    apply(folder)


if __name__=='__main__':
    try:main()
    except (OSError,ValueError,RuntimeError) as error:
        print('Fix stopped: '+str(error));raise SystemExit(1)
