"""Short bounded retries for live bridge reads; no stale snapshot fallback."""
import errno
import io
import os
from pathlib import Path
import time
import pandas as pd


def _read_once(path,encoding):
    if os.name!='nt':return Path(path).read_text(encoding=encoding)
    # Allow NinjaTrader/OneDrive to replace an open snapshot. Python's ordinary
    # CRT file open does not explicitly request FILE_SHARE_DELETE.
    import ctypes
    from ctypes import wintypes
    import msvcrt
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.CreateFileW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,
        wintypes.LPVOID,wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE]
    kernel.CreateFileW.restype=wintypes.HANDLE
    kernel.CloseHandle.argtypes=[wintypes.HANDLE]
    kernel.CloseHandle.restype=wintypes.BOOL
    handle=kernel.CreateFileW(str(Path(path).resolve()),0x80000000,0x1|0x2|0x4,None,3,0x80,None)
    if handle==ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    try:fd=msvcrt.open_osfhandle(handle,os.O_RDONLY|os.O_BINARY)
    except BaseException:
        kernel.CloseHandle(handle)
        raise
    # The descriptor now owns the native handle and closes it exactly once.
    with os.fdopen(fd,'rb') as stream:return stream.read().decode(encoding)


def read_bridge_text(path,encoding='utf-8-sig',timeout=.8):
    if not 0<=timeout<=1:raise ValueError('Bridge retry budget must be at most one second')
    deadline=time.monotonic()+timeout
    while True:
        try:return _read_once(path,encoding)
        except OSError as error:
            transient=(isinstance(error,(PermissionError,FileNotFoundError)) or
                error.errno in (errno.EACCES,errno.ENOENT) or getattr(error,'winerror',None) in (5,32,33))
            if not transient or time.monotonic()>=deadline:raise
            time.sleep(min(.04,max(0,deadline-time.monotonic())))


def read_complete_csv(path):
    text=read_bridge_text(path)
    # A partial trailing append is never treated as a complete event/bar.
    return pd.read_csv(io.StringIO(text[:text.rfind('\n')+1]))
