param([switch]$Status,[switch]$Audit,[switch]$Discord=$true,[string]$Bridge="")
$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($Bridge)) {
    $Bridge=Join-Path $env:LOCALAPPDATA 'SovereignMGC\ExecutionBridge'
}
$python=Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (!(Test-Path $python)) {
    & py -3.12 -m venv (Join-Path $PSScriptRoot '.venv')
    if ($LASTEXITCODE -ne 0) { throw 'Install 64-bit Python3.12 from python.org, including the Python launcher, then retry.' }
}
$requirements=Join-Path $PSScriptRoot 'requirements.txt'
$expected=(Get-FileHash $requirements -Algorithm SHA256).Hash
$ready=Join-Path $PSScriptRoot '.venv\sim-deps-ready'
if (!(Test-Path $ready) -or (Get-Content $ready -Raw).Trim() -ne $expected) {
    & $python -m pip install -r $requirements
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed; read the pip output.' }
    Set-Content -LiteralPath $ready -Value $expected
}
$priorWebhook=$env:DISCORD_WEBHOOK_URL
try {
    if ($Discord -and !$Status -and !$Audit -and [string]::IsNullOrWhiteSpace($env:DISCORD_WEBHOOK_URL)) {
        $hidden=Read-Host 'Discord webhook URL (hidden; required for startup)' -AsSecureString
        $address=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($hidden)
        try { $env:DISCORD_WEBHOOK_URL=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($address) }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($address) }
    }
    $arguments=@((Join-Path $PSScriptRoot 'RunSim101.py'))
    if ($Status) { $arguments+='--status' }
    if ($Audit) { $arguments+='--audit' }
    if ($Discord -and !$Status -and !$Audit) { $arguments+='--discord' }
    if (![string]::IsNullOrWhiteSpace($Bridge)) { $arguments+=@('--bridge',$Bridge) }
    & $python @arguments
    if ($LASTEXITCODE -ne 0) { throw 'Controller stopped. Check console plus NinjaTrader Orders/Positions; do not assume flatten completed.' }
}
finally { $env:DISCORD_WEBHOOK_URL=$priorWebhook }
