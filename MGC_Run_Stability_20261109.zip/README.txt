MGC flat status recovery + Discord compatibility — Python-only update

Requires native SIM11 heartbeat repair. Includes the previous Discord compatibility
update; it is not necessary to run that older updater separately.

Observed diagnostic: Python exited at02:32UTC on Native snapshot stopped; its final
main-loop age was0.86s and successful heartbeat writes continued until shutdown.
At04:09UTC native status was fresh again. The5822s heartbeat age is the aftermath of
Python exiting, not proof of the original failure. The evidence supports a temporary
status interruption; it does not establish why the native snapshot paused.

NEW BEHAVIOR: if state is unreadable or older than5seconds while last known reconciled
flat, with no pending/recent/unreconciled entry command, wait without any orders for
up to30seconds. Continue checking native status and publishing controller liveness.
On recovery require the same native run and a fresh reconciled flat snapshot, discard
unsubmitted setups, rebuild context and wait for a NEW candle. Never replay old orders.
Exposure, working orders, uncertain fills, a native halt, future clocks, and persistent
loss of status still stop. Fresh-entry snapshot3s/quotes5s checks remain unchanged.
No financial limit, strategy, native source, heartbeat deadline or ledger changes.

Also restores detailed notifications for SIM10/SIM11 journals, and retries transient
publication errors in the ancillary notification-health file without terminating the
controller. This auxiliary status file never supplies trading or account authority.

INSTALL:
1. Stop Python, disable strategy, confirm actual Sim101 is flat with no working orders.
2. Extract this ZIP into your existing MGC_Bot_With_Setup directory.
3. Run py .\Repair_MGC_Run_Stability.py and type STABILITY after those checks.
4. No F5/recompile needed. The existing private launcher starts automatically.
5. Enable the same SovereignMgcResearchSimBridgeV3 on Sim101 after Startup file written.
   Existing LocalAppData bridge directory and DoNotMerge remain.

Look for Flat status recovery enabled and Detailed Discord tracking active. Temporary
flat interruptions print WAITING_NATIVE_SNAPSHOT_FLAT, then a recovery/FLAT_RESYNC.
The resync itself cannot submit entries. Discord connected report is immediate, hourly
reports are due60minutes after connection. Delivery still depends on Discord/network.

If stopped again, preserve the current run and execute from the bot folder:
  .\.venv\Scripts\python.exe .\Diagnose_MGC_Stability.py
This is not an auto-rearm or permission to trade stale state. Native compilation was
already required by SIM11; no native code changes here. Windows uptime, fills and
unattended profitability are not certified by Linux regression tests.
