"""Bounded no-trade wait for interrupted native status when last known flat."""
import time
from datetime import timedelta
from .mgc_flat_resync_v9 import require_flat_resync
from .mgc_sim_execution_v3 import BridgeError


class FlatSnapshotWait:
    def __init__(self,clock=time.monotonic):
        self.clock=clock;self.started=None;self.last_notice=None;self.recoveries=0

    def inspect(self,state,now,*,read_error=False,pending_commands=False,recent_entry=False):
        age=(now-state['updated_utc']).total_seconds()
        if age<0:raise BridgeError('Native snapshot is future-dated; reconcile clock')
        interrupted=read_error or age>5
        if interrupted or self.started is not None:
            # Never continue from a remembered flat state after submitting an
            # entry; an unacknowledged order can already have filled natively.
            require_flat_resync(state,pending_commands,recent_entry)
        if interrupted:
            if self.started is None:self.started=self.clock()
            elapsed=self.clock()-self.started
            if elapsed>=30:raise BridgeError('Native status unavailable for30seconds while flat; no entries submitted; reconcile native publication')
            notice=self.last_notice is None or self.clock()-self.last_notice>=5
            if notice:self.last_notice=self.clock()
            return dict(action='WAIT',notice=notice,snapshot_age_seconds=round(age,3),
                        wait_seconds=round(elapsed,3),read_error=bool(read_error),orders_allowed=False)
        recovered=self.started is not None
        elapsed=self.clock()-self.started if recovered else 0.
        if recovered:self.recoveries+=1
        self.started=None;self.last_notice=None
        return dict(action='RECOVERED' if recovered else 'READY',
                    wait_seconds=round(elapsed,3),snapshot_age_seconds=round(age,3),orders_allowed=not recovered)


def transient_status_error(error):
    return isinstance(error,(PermissionError,FileNotFoundError)) or getattr(error,'winerror',None) in (5,32,33)


def entry_awaiting_reconciliation(state,last_entry_sent,last_entry_issued,clock=time.monotonic):
    if last_entry_sent is None:return False
    if clock()-last_entry_sent<15:return True
    # A stale flat snapshot from before submission is never evidence that an
    # old submitted entry is flat, even after a long controller scheduling pause.
    return last_entry_issued is None or state['updated_utc']<=last_entry_issued+timedelta(seconds=3)
