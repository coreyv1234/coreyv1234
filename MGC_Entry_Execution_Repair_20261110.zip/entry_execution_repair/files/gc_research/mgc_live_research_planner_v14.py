"""Same entry decisions with explicit cancellation/entry-gate diagnostics."""
from .mgc_live_research_planner_v4 import LiveResearchPlannerV4
from .mgc_sim_execution_v3 import BridgeError


class LiveResearchPlannerV14(LiveResearchPlannerV4):
    def __init__(self,*args,**kwargs):
        self.last_cancel=None;self.last_entry_check=None
        super().__init__(*args,**kwargs)

    def cancel_limit(self,stamp,reason):
        if self.limit_order is not None:
            self.last_cancel=dict(time=stamp.isoformat(),reason=reason,order_id=self.limit_order.order_id,
                family=self.limit_order.signal.family)
        return super().cancel_limit(stamp,reason)

    def prepare_entry(self,state,now,config):
        before=self.limit_order
        detail=dict(checked_at_utc=now.isoformat(),reason='no_pending_proposal',
            snapshot_age_seconds=(now-state['updated_utc']).total_seconds(),
            quote_age_seconds=(now-state['quote_utc']).total_seconds(),
            bid=state['bid'],ask=state['ask'],confirmation_time=self.confirmation_time.isoformat() if self.confirmation_time else None)
        if before is not None:
            detail.update(family=before.signal.family,order_id=before.order_id,quantity=before.quantity,
                stop=before.stop,target=before.target,
                confirmation_age_seconds=(now-self.confirmation_time).total_seconds() if self.confirmation_time else None)
        try:row=super().prepare_entry(state,now,config)
        except BridgeError as error:
            detail.update(reason='entry_health_check_failed',health_error=str(error));self.last_entry_check=detail
            raise
        if row is not None:detail['reason']='entry_command_prepared'
        elif before is not None:
            detail['reason']=self.last_cancel['reason'] if self.last_cancel and self.last_cancel['order_id']==before.order_id else 'awaiting_confirmation_or_native_busy'
        self.last_entry_check=detail
        return row

    def retry_confirmed_entry(self,state,now,config):
        if self.limit_order is None or self.confirmation_time!=state['last_bar_utc']:return None
        if (now-self.confirmation_time).total_seconds()>5:
            self.cancel_limit(now,'submission_deadline_missed')
            self.last_entry_check=dict(reason='submission_deadline_missed',checked_at_utc=now.isoformat(),
                confirmation_time=self.confirmation_time.isoformat(),
                confirmation_age_seconds=(now-self.confirmation_time).total_seconds())
            return None
        return self.prepare_entry(state,now,config)
