"""Append-only chart parsing with full immutable-prefix verification each read."""
import hashlib
import io
import pandas as pd
from .mgc_chart_history_v7 import ChartHistory,COLUMNS
from .mgc_execution import BridgeError,validate_chart_rows
from .mgc_live_signals import normalized_minutes
from .mgc_bridge_io_v5 import read_bridge_text


class IncrementalChartHistory(ChartHistory):
    def __init__(self):
        super().__init__();self.frame=None;self.characters=0;self.parsed_rows=0

    def read(self,path,symbol,through):
        return self.accept_text(read_bridge_text(path),symbol,through)

    def accept_text(self,text,symbol,through):
        through=pd.Timestamp(through)
        if self.symbol is not None and self.symbol!=symbol:raise BridgeError('Native chart expiry changed during this run')
        if self.last is not None and through<self.last:raise BridgeError('Chart clock moved backwards')
        complete=text[:text.rfind('\n')+1]
        if not complete:raise BridgeError('No complete chart CSV header')
        header=complete[:complete.find('\n')+1]
        if header.strip()!=','.join(COLUMNS):raise BridgeError('Unexpected native chart CSV schema')
        if self.characters:
            if len(complete)<self.characters or hashlib.sha256(complete[:self.characters].encode('utf-8')).hexdigest()!=self.digest:
                raise BridgeError('Previously accepted chart candles changed or disappeared; stop and start a fresh flat run')
            start=self.characters
        else:start=len(header)
        lines=complete[start:].splitlines(keepends=True)
        selected=None
        if lines:
            new=pd.read_csv(io.StringIO(header+''.join(lines)))
            if len(new)!=len(lines):raise BridgeError('Native chart must contain exactly one record per line')
            validate_chart_rows(new.to_dict('records'),symbol)
            new=normalized_minutes(new)
            if self.last is not None and new.index[0]<=self.last:raise BridgeError('Duplicate or reversed appended chart candle')
            selected=new.loc[new.index<=through]
        else:selected=pd.DataFrame()
        if len(selected):
            result=selected if self.frame is None else pd.concat([self.frame,selected])
        else:result=self.frame
        if result is None or result.empty or result.index[-1]!=through:
            raise BridgeError('Chart history must end at the native last completed candle')
        consumed=start+sum(map(len,lines[:len(selected)]))
        self.parsed_rows+=len(lines)
        self.characters=consumed;self.digest=hashlib.sha256(complete[:consumed].encode('utf-8')).hexdigest()
        self.frame=result;self.count=len(result);self.symbol=symbol;self.first=result.index[0];self.last=result.index[-1]
        return result

    def receipt(self):
        return super().receipt()|dict(parser='append_only_with_full_raw_prefix_sha256',
            accepted_characters=self.characters,parsed_rows=self.parsed_rows)
