"""One repair command; trading logic and private launcher are preserved."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def sha(body):return hashlib.sha256(body).hexdigest()


def apply(root):
    root=Path(root);payload=root/'entry_execution_repair'
    spec=json.loads((payload/'PATCH.json').read_text())
    manifest_path=root/'MANIFEST.json'
    manifest=json.loads(manifest_path.read_text())
    for name,expected in spec.get('required_public_files',{}).items():
        if sha((root/name).read_bytes())!=expected:raise RuntimeError('Install the SIM11 heartbeat repair before this notification update.')
    for name,digest in manifest.items():
        relative=Path(name)
        if relative.is_absolute() or '..' in relative.parts:raise RuntimeError('Unsafe manifest path')
        if sha((root/name).read_bytes())!=digest:raise RuntimeError('Existing public package file changed: '+name+'; no repair applied.')
    for name,item in spec['files'].items():
        relative=Path(name)
        if relative.is_absolute() or '..' in relative.parts:raise RuntimeError('Unsafe repair path')
        body=(payload/'files'/name).read_bytes()
        if sha(body)!=item['new_sha256']:raise RuntimeError('Repair payload verification failed')
        current=sha((root/name).read_bytes()) if (root/name).exists() else None
        if current not in item['allowed_old_sha256']+[item['new_sha256']]:
            raise RuntimeError('Unsupported existing version: '+name+'; no repair applied.')
    if all((root/n).exists() and sha((root/n).read_bytes())==v['new_sha256'] for n,v in spec['files'].items()):
        print('Fast entry execution update already installed.');return
    backup=Path(tempfile.mkdtemp(prefix='entry_execution_backup_',dir=str(root)))
    shutil.copyfile(manifest_path,backup/'MANIFEST.json')
    for name in spec['files']:
        if (root/name).exists():
            saved=backup/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,saved)
    for name,item in spec['files'].items():
        target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
        temporary=target.with_name(target.name+'.repair_tmp')
        temporary.write_bytes((payload/'files'/name).read_bytes());temporary.replace(target)
        manifest[name]=item['new_sha256']
    temporary=manifest_path.with_name('MANIFEST.json.repair_tmp')
    temporary.write_text(json.dumps(manifest,indent=2)+'\n');temporary.replace(manifest_path)
    print('Fast entry execution installed. Original5second deadline, model gates, native source, risk limits, ledger and webhook settings are preserved.')


def main():
    root=Path(__file__).resolve().parent
    if not (root/'RunSim101.py').is_file():raise RuntimeError('Run this repair from the existing extracted bot folder.')
    if sys.platform!='win32':raise RuntimeError('Run this repair on your Windows NinjaTrader computer.')
    print('Stop the old Python controller. Disable the strategy and confirm Sim101 is flat with no working orders.')
    print('This update speeds closed-chart processing and records explicit entry-check reasons. Wait until any open trade has finished before installing.')
    if input('Type EXECUTION after completing those checks: ').strip()!='EXECUTION':raise RuntimeError('Canceled; no changes applied.')
    apply(root)
    private=root/'Start_MGC_Private.py'
    if not private.is_file():raise RuntimeError('Your existing Start_MGC_Private.py is missing. No webhook was changed or added.')
    print('No C# change or F5 compilation is needed. Enable the strategy after Python writes its startup file.')
    result=subprocess.run([sys.executable,str(private)],cwd=root)
    raise SystemExit(result.returncode)


if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:
        print('Stopped. Check actual NinjaTrader Orders/Positions.');raise SystemExit(1)
    except (OSError,RuntimeError,ValueError,subprocess.CalledProcessError) as error:
        print('Discord update stopped: '+str(error));raise SystemExit(1)
