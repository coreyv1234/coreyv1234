MGC entry execution update — Python only, native SIM11 unchanged

Evidence: the user's confirmed02:17 Chicago candle exported at08:17:00.1092863UTC.
The source confirmed under actual chart OHLCV but live logs recorded no command.
Old logs omitted the final gate/cancellation reason, so this does not prove the exact
past cancellation cause. This update removes observed avoidable processing overhead
and makes future entry decisions auditable. It does not force unconfirmed trades.

Changes:
- Parse only new complete chart CSV records. Hash the ENTIRE previously accepted raw
  prefix every read to detect revisions/truncation. Same exact chart OHLCV values,
  actual expiry, validation, no future rows or invented candles. Full warmup once.
- Before02:00 do not rebuild unavailable current-day features on every minute.
  Build them at their original availability; model weights/scores remain unchanged.
- Write the durable consumed-cursor receipt after command preparation/submission,
  removing that disk flush from the time-critical entry-preparation path.
- Recheck a confirmed unsubmitted setup after a temporary quote/snapshot rejection,
  using fresh native state only within the ORIGINAL5second deadline. Once submitted,
  the proposal is removed; native/source duplicate guards remain. No replays/catchup.
- Record processed_at_utc, processing_seconds, entry_check, entry_health_error,
  proposal_family and last_proposal_cancel in decisions.jsonl. Retry attempts have
  event ENTRY_RETRY. No command/fill is invented for these diagnostics.

Tests: actual user chart prefix with123,616warmup rows; five successive appends match
the former parser exactly, about0.020s vs1.547s mean on cloud CPU. Windows timings
still require the new processing_seconds logs. All183 frozen benchmark entry commands
match original quantity, stop, target, risk and expected entry under modeled quotes.
This verifies command preparation, not Windows native submission, fills or profitability.

INSTALL: Stop Python, disable strategy and confirm actual Sim101 flat/no working orders.
Extract ZIP into existing MGC_Bot_With_Setup folder, then run:
  py .\Repair_MGC_Entry_Execution.py
Type EXECUTION only after the flat/order checks. Existing private launcher starts.
No C# change or F5 needed. After Startup file written enable the same
SovereignMgcResearchSimBridgeV3 on Sim101, with existing LocalAppData bridge path.

Works from SIM11 or the later flat-status update. Includes that flat-only bounded
recovery and Discord compatibility. Strategy, model thresholds, five-second deadline,
quote/snapshot checks, sizing limits, financial ledger and private webhook unchanged.
The02:20 unconfirmed pullback and negative-scored06:10/06:55 setups remain ineligible.
Do not expect additional trades solely from those unchanged strategy conditions.
